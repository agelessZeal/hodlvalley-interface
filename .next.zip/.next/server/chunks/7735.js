exports.id = 7735;
exports.ids = [7735];
exports.modules = {

/***/ 9108:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "P": function() { return /* binding */ OVERLAY_READY; },
/* harmony export */   "o": function() { return /* binding */ FortmaticConnector; }
/* harmony export */ });
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6766);
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _web3_react_fortmatic_connector__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1698);
/* harmony import */ var _web3_react_fortmatic_connector__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_web3_react_fortmatic_connector__WEBPACK_IMPORTED_MODULE_1__);


const OVERLAY_READY = 'OVERLAY_READY';
const CHAIN_ID_NETWORK_ARGUMENT = {
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET]: undefined,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.ROPSTEN]: 'ropsten',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.RINKEBY]: 'rinkeby',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.KOVAN]: 'kovan'
};
class FortmaticConnector extends _web3_react_fortmatic_connector__WEBPACK_IMPORTED_MODULE_1__.FortmaticConnector {
  async activate() {
    if (!this.fortmatic) {
      const {
        default: Fortmatic
      } = await Promise.resolve(/* import() */).then(__webpack_require__.t.bind(__webpack_require__, 8099, 23));
      const {
        apiKey,
        chainId
      } = this;

      if (chainId in CHAIN_ID_NETWORK_ARGUMENT) {
        this.fortmatic = new Fortmatic(apiKey, CHAIN_ID_NETWORK_ARGUMENT[chainId]);
      } else {
        throw new Error(`Unsupported network ID: ${chainId}`);
      }
    }

    const provider = this.fortmatic.getProvider();
    const pollForOverlayReady = new Promise(resolve => {
      const interval = setInterval(() => {
        if (provider.overlayReady) {
          clearInterval(interval);
          this.emit(OVERLAY_READY);
          resolve();
        }
      }, 200);
    });
    const [account] = await Promise.all([provider.enable().then(accounts => accounts[0]), pollForOverlayReady]);
    return {
      provider: this.fortmatic.getProvider(),
      chainId: this.chainId,
      account
    };
  }

}

/***/ }),

/***/ 1378:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Oh": function() { return /* binding */ binance; },
  "pp": function() { return /* binding */ fortmatic; },
  "nM": function() { return /* binding */ getNetworkLibrary; },
  "Lj": function() { return /* binding */ injected; },
  "L5": function() { return /* binding */ network; },
  "yO": function() { return /* binding */ portis; },
  "ux": function() { return /* binding */ torus; },
  "Lw": function() { return /* binding */ walletconnect; },
  "H5": function() { return /* binding */ walletlink; }
});

// EXTERNAL MODULE: external "@ethersproject/providers"
var providers_ = __webpack_require__(6497);
// EXTERNAL MODULE: external "@binance-chain/bsc-connector"
var bsc_connector_ = __webpack_require__(8688);
// EXTERNAL MODULE: external "@sushiswap/sdk"
var sdk_ = __webpack_require__(6766);
// EXTERNAL MODULE: ./src/connectors/Fortmatic.ts
var Fortmatic = __webpack_require__(9108);
// EXTERNAL MODULE: external "@web3-react/injected-connector"
var injected_connector_ = __webpack_require__(7290);
// EXTERNAL MODULE: external "@web3-react/abstract-connector"
var abstract_connector_ = __webpack_require__(5008);
// EXTERNAL MODULE: external "tiny-invariant"
var external_tiny_invariant_ = __webpack_require__(4050);
var external_tiny_invariant_default = /*#__PURE__*/__webpack_require__.n(external_tiny_invariant_);
;// CONCATENATED MODULE: ./src/connectors/NetworkConnector.ts
function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




class RequestError extends Error {
  constructor(message, code, data) {
    super(message);
    this.code = code;
    this.data = data;
  }

}

class MiniRpcProvider {
  constructor(chainId, url, batchWaitTimeMs) {
    _defineProperty(this, "isMetaMask", false);

    _defineProperty(this, "chainId", void 0);

    _defineProperty(this, "url", void 0);

    _defineProperty(this, "host", void 0);

    _defineProperty(this, "path", void 0);

    _defineProperty(this, "batchWaitTimeMs", void 0);

    _defineProperty(this, "nextId", 1);

    _defineProperty(this, "batchTimeoutId", null);

    _defineProperty(this, "batch", []);

    _defineProperty(this, "clearBatch", async () => {
      console.debug('Clearing batch', this.batch);
      const batch = this.batch;
      this.batch = [];
      this.batchTimeoutId = null;
      let response;

      try {
        response = await fetch(this.url, {
          method: 'POST',
          headers: {
            'content-type': 'application/json',
            accept: 'application/json'
          },
          body: JSON.stringify(batch.map(item => item.request))
        });
      } catch (error) {
        batch.forEach(({
          reject
        }) => reject(new Error('Failed to send batch call')));
        return;
      }

      if (!response.ok) {
        batch.forEach(({
          reject
        }) => reject(new RequestError(`${response.status}: ${response.statusText}`, -32000)));
        return;
      }

      let json;

      try {
        json = await response.json();
      } catch (error) {
        batch.forEach(({
          reject
        }) => reject(new Error('Failed to parse JSON response')));
        return;
      }

      const byKey = batch.reduce((memo, current) => {
        memo[current.request.id] = current;
        return memo;
      }, {});

      for (const result of json) {
        const {
          resolve,
          reject,
          request: {
            method
          }
        } = byKey[result.id];

        if (resolve && reject) {
          if ('error' in result) {
            var _result$error, _result$error2, _result$error3;

            reject(new RequestError(result === null || result === void 0 ? void 0 : (_result$error = result.error) === null || _result$error === void 0 ? void 0 : _result$error.message, result === null || result === void 0 ? void 0 : (_result$error2 = result.error) === null || _result$error2 === void 0 ? void 0 : _result$error2.code, result === null || result === void 0 ? void 0 : (_result$error3 = result.error) === null || _result$error3 === void 0 ? void 0 : _result$error3.data));
          } else if ('result' in result) {
            resolve(result.result);
          } else {
            reject(new RequestError(`Received unexpected JSON-RPC response to ${method} request.`, -32000, result));
          }
        }
      }
    });

    _defineProperty(this, "sendAsync", (request, callback) => {
      this.request(request.method, request.params).then(result => callback(null, {
        jsonrpc: '2.0',
        id: request.id,
        result
      })).catch(error => callback(error, null));
    });

    _defineProperty(this, "request", async (method, params) => {
      var _this$batchTimeoutId;

      if (typeof method !== 'string') {
        return this.request(method.method, method.params);
      }

      if (method === 'eth_chainId') {
        return `0x${this.chainId.toString(16)}`;
      }

      const promise = new Promise((resolve, reject) => {
        this.batch.push({
          request: {
            jsonrpc: '2.0',
            id: this.nextId++,
            method,
            params
          },
          resolve,
          reject
        });
      });
      this.batchTimeoutId = (_this$batchTimeoutId = this.batchTimeoutId) !== null && _this$batchTimeoutId !== void 0 ? _this$batchTimeoutId : setTimeout(this.clearBatch, this.batchWaitTimeMs);
      return promise;
    });

    this.chainId = chainId;
    this.url = url;
    const parsed = new URL(url);
    this.host = parsed.host;
    this.path = parsed.pathname; // how long to wait to batch calls

    this.batchWaitTimeMs = batchWaitTimeMs !== null && batchWaitTimeMs !== void 0 ? batchWaitTimeMs : 50;
  }

}

class NetworkConnector extends abstract_connector_.AbstractConnector {
  constructor({
    urls,
    defaultChainId
  }) {
    external_tiny_invariant_default()(defaultChainId || Object.keys(urls).length === 1, 'defaultChainId is a required argument with >1 url');
    super({
      supportedChainIds: Object.keys(urls).map(k => Number(k))
    });

    _defineProperty(this, "providers", void 0);

    _defineProperty(this, "currentChainId", void 0);

    this.currentChainId = defaultChainId || Number(Object.keys(urls)[0]);
    this.providers = Object.keys(urls).reduce((accumulator, chainId) => {
      accumulator[Number(chainId)] = new MiniRpcProvider(Number(chainId), urls[Number(chainId)]);
      return accumulator;
    }, {});
  }

  get provider() {
    return this.providers[this.currentChainId];
  }

  async activate() {
    return {
      provider: this.providers[this.currentChainId],
      chainId: this.currentChainId,
      account: null
    };
  }

  async getProvider() {
    return this.providers[this.currentChainId];
  }

  async getChainId() {
    return this.currentChainId;
  }

  async getAccount() {
    return null;
  }

  deactivate() {
    return;
  }

}
// EXTERNAL MODULE: external "@web3-react/portis-connector"
var portis_connector_ = __webpack_require__(5228);
// EXTERNAL MODULE: external "@web3-react/torus-connector"
var torus_connector_ = __webpack_require__(3097);
// EXTERNAL MODULE: external "@web3-react/walletconnect-connector"
var walletconnect_connector_ = __webpack_require__(9650);
// EXTERNAL MODULE: external "@web3-react/walletlink-connector"
var walletlink_connector_ = __webpack_require__(7690);
;// CONCATENATED MODULE: ./src/connectors/index.ts
var _process$env$NEXT_PUB, _process$env$NEXT_PUB2;











const RPC = {
  [sdk_.ChainId.MAINNET]: 'https://eth-mainnet.alchemyapi.io/v2/q1gSNoSMEzJms47Qn93f9-9Xg5clkmEC',
  [sdk_.ChainId.ROPSTEN]: 'https://eth-ropsten.alchemyapi.io/v2/cidKix2Xr-snU3f6f6Zjq_rYdalKKHmW',
  [sdk_.ChainId.RINKEBY]: 'https://eth-rinkeby.alchemyapi.io/v2/XVLwDlhGP6ApBXFz_lfv0aZ6VmurWhYD',
  [sdk_.ChainId["GÖRLI"]]: 'https://eth-goerli.alchemyapi.io/v2/Dkk5d02QjttYEoGmhZnJG37rKt8Yl3Im',
  [sdk_.ChainId.KOVAN]: 'https://eth-kovan.alchemyapi.io/v2/6OVAa_B_rypWWl9HqtiYK26IRxXiYqER',
  [sdk_.ChainId.FANTOM]: 'https://rpcapi.fantom.network',
  [sdk_.ChainId.FANTOM_TESTNET]: 'https://rpc.testnet.fantom.network',
  [sdk_.ChainId.MATIC]: 'https://rpc-mainnet.maticvigil.com',
  // [ChainId.MATIC]:
  //     'https://apis.ankr.com/e22bfa5f5a124b9aa1f911b742f6adfe/c06bb163c3c2a10a4028959f4d82836d/polygon/full/main',
  [sdk_.ChainId.MATIC_TESTNET]: 'https://rpc-mumbai.matic.today',
  [sdk_.ChainId.XDAI]: 'https://rpc.xdaichain.com',
  [sdk_.ChainId.BSC]: 'https://bsc-dataseed.binance.org/',
  [sdk_.ChainId.BSC_TESTNET]: 'https://data-seed-prebsc-2-s3.binance.org:8545',
  [sdk_.ChainId.MOONBEAM_TESTNET]: 'https://rpc.testnet.moonbeam.network',
  [sdk_.ChainId.AVALANCHE]: 'https://api.avax.network/ext/bc/C/rpc',
  [sdk_.ChainId.AVALANCHE_TESTNET]: 'https://api.avax-test.network/ext/bc/C/rpc',
  [sdk_.ChainId.HECO]: 'https://http-mainnet.hecochain.com',
  [sdk_.ChainId.HECO_TESTNET]: 'https://http-testnet.hecochain.com',
  [sdk_.ChainId.HARMONY]: 'https://api.harmony.one',
  [sdk_.ChainId.HARMONY_TESTNET]: 'https://api.s0.b.hmny.io',
  [sdk_.ChainId.OKEX]: 'https://exchainrpc.okex.org',
  [sdk_.ChainId.OKEX_TESTNET]: 'https://exchaintestrpc.okex.org',
  [sdk_.ChainId.ARBITRUM]: 'https://arb1.arbitrum.io/rpc'
};
const network = new NetworkConnector({
  defaultChainId: 1,
  urls: RPC
});
let networkLibrary;
function getNetworkLibrary() {
  var _networkLibrary;

  return networkLibrary = (_networkLibrary = networkLibrary) !== null && _networkLibrary !== void 0 ? _networkLibrary : new providers_.Web3Provider(network.provider);
}
const injected = new injected_connector_.InjectedConnector({
  supportedChainIds: [1, // mainnet
  3, // ropsten
  4, // rinkeby
  5, // goreli
  42, // kovan
  250, // fantom
  4002, // fantom testnet
  137, // matic
  80001, // matic testnet
  100, // xdai
  56, // binance smart chain
  97, // binance smart chain testnet
  1287, // moonbase
  43114, // avalanche
  43113, // fuji
  128, // heco
  256, // heco testnet
  1666600000, // harmony
  1666700000, // harmony testnet
  66, // okex testnet
  65, // okex testnet
  42161, // arbitrum
  42220 // celo
  ]
}); // mainnet only

const walletconnect = new walletconnect_connector_.WalletConnectConnector({
  rpc: RPC,
  bridge: 'https://bridge.walletconnect.org',
  qrcode: true,
  pollingInterval: 15000
}); // mainnet only

const fortmatic = new Fortmatic/* FortmaticConnector */.o({
  apiKey: (_process$env$NEXT_PUB = process.env.NEXT_PUBLIC_FORTMATIC_API_KEY) !== null && _process$env$NEXT_PUB !== void 0 ? _process$env$NEXT_PUB : '',
  chainId: 1
}); // mainnet only

const portis = new portis_connector_.PortisConnector({
  dAppId: (_process$env$NEXT_PUB2 = process.env.NEXT_PUBLIC_PORTIS_ID) !== null && _process$env$NEXT_PUB2 !== void 0 ? _process$env$NEXT_PUB2 : '',
  networks: [1]
}); // mainnet only

const walletlink = new walletlink_connector_.WalletLinkConnector({
  url: RPC[sdk_.ChainId.MAINNET],
  appName: 'SushiSwap',
  appLogoUrl: 'https://raw.githubusercontent.com/sushiswap/art/master/sushi/logo-256x256.png'
}); // mainnet only

const torus = new torus_connector_.TorusConnector({
  chainId: 1
}); // binance only

const binance = new bsc_connector_.BscConnector({
  supportedChainIds: [56]
});

/***/ }),

/***/ 697:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "k_": function() { return /* binding */ ARCHER_ROUTER_ADDRESS; },
/* harmony export */   "uu": function() { return /* binding */ MINICHEF_ADDRESS; },
/* harmony export */   "C1": function() { return /* binding */ MASTERCHEF_V2_ADDRESS; },
/* harmony export */   "oA": function() { return /* binding */ ZAPPER_ADDRESS; },
/* harmony export */   "sO": function() { return /* binding */ MERKLE_DISTRIBUTOR_ADDRESS; },
/* harmony export */   "Ph": function() { return /* binding */ MULTICALL2_ADDRESS; }
/* harmony export */ });
/* unused harmony export TIMELOCK_ADDRESS */
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6766);
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__);

const TIMELOCK_ADDRESS = '0x1a9C8182C09F50C8318d769245beA52c32BE35BC';
const ARCHER_ROUTER_ADDRESS = {
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET]: '0x9917C083FF9FbD29Df1367FBF7F2388A9a202431'
};
const MINICHEF_ADDRESS = {
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC]: '0x0769fd68dFb93167989C6f7254cd0D766Fb2841F',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.XDAI]: '0xdDCbf776dF3dE60163066A5ddDF2277cB445E0F3',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HARMONY]: '0x67dA5f2FfaDDfF067AB9d5F025F8810634d84287',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.RINKEBY]: '0x6DfC412f2D659Bcf4E89d9D61a917132F8899321'
};
const MASTERCHEF_V2_ADDRESS = {
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET]: '0xEF0881eC094552b2e128Cf945EF17a6752B4Ec5d'
};
const ZAPPER_ADDRESS = {
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET]: '0xcff6eF0B9916682B37D80c19cFF8949bc1886bC2',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.ROPSTEN]: '0xcff6eF0B9916682B37D80c19cFF8949bc1886bC2'
}; // TODO: specify merkle distributor for mainnet

const MERKLE_DISTRIBUTOR_ADDRESS = {
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET]: '0xcBE6B83e77cdc011Cc18F6f0Df8444E5783ed982',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.ROPSTEN]: '0x84d1f7202e0e7dac211617017ca72a2cb5e2b955'
};
const MULTICALL2_ADDRESS = {
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET]: '0x5BA1e12693Dc8F9c48aAD8770482f4739bEeD696',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.ROPSTEN]: '0x5BA1e12693Dc8F9c48aAD8770482f4739bEeD696',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.RINKEBY]: '0x5BA1e12693Dc8F9c48aAD8770482f4739bEeD696',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId["GÖRLI"]]: '0x5BA1e12693Dc8F9c48aAD8770482f4739bEeD696',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.KOVAN]: '0x5BA1e12693Dc8F9c48aAD8770482f4739bEeD696',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.ARBITRUM]: '0xadF885960B47eA2CD9B55E6DAc6B42b7Cb2806dB',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.ARBITRUM_TESTNET]: '0xa501c031958F579dB7676fF1CE78AD305794d579',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.CELO]: '0x9aac9048fC8139667D6a2597B902865bfdc225d3',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.FANTOM]: '0x22D4cF72C45F8198CfbF4B568dBdB5A85e8DC0B5',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.FANTOM_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC]: '0x02817C1e3543c2d908a590F5dB6bc97f933dB4BD',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.XDAI]: '0x67dA5f2FfaDDfF067AB9d5F025F8810634d84287',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.BSC]: '0xa9193376D09C7f31283C54e56D013fCF370Cd9D9',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.BSC_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MOONBEAM_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.AVALANCHE]: '0xdDCbf776dF3dE60163066A5ddDF2277cB445E0F3',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.AVALANCHE_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HECO]: '0xdDCbf776dF3dE60163066A5ddDF2277cB445E0F3',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HECO_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HARMONY]: '0xdDCbf776dF3dE60163066A5ddDF2277cB445E0F3',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HARMONY_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.OKEX]: '0xF4d73326C13a4Fc5FD7A064217e12780e9Bd62c3',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.OKEX_TESTNET]: ''
};

/***/ }),

/***/ 8809:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "H": function() { return /* binding */ SupportedChainId; }
/* harmony export */ });
let SupportedChainId;

(function (SupportedChainId) {
  SupportedChainId[SupportedChainId["MAINNET"] = 1] = "MAINNET";
  SupportedChainId[SupportedChainId["ROPSTEN"] = 3] = "ROPSTEN";
  SupportedChainId[SupportedChainId["RINKEBY"] = 4] = "RINKEBY";
  SupportedChainId[SupportedChainId["G\xD6RLI"] = 5] = "G\xD6RLI";
  SupportedChainId[SupportedChainId["KOVAN"] = 42] = "KOVAN";
  SupportedChainId[SupportedChainId["MATIC"] = 137] = "MATIC";
  SupportedChainId[SupportedChainId["MATIC_TESTNET"] = 80001] = "MATIC_TESTNET";
  SupportedChainId[SupportedChainId["FANTOM"] = 250] = "FANTOM";
  SupportedChainId[SupportedChainId["FANTOM_TESTNET"] = 4002] = "FANTOM_TESTNET";
  SupportedChainId[SupportedChainId["XDAI"] = 100] = "XDAI";
  SupportedChainId[SupportedChainId["BSC"] = 56] = "BSC";
  SupportedChainId[SupportedChainId["BSC_TESTNET"] = 97] = "BSC_TESTNET";
  SupportedChainId[SupportedChainId["ARBITRUM"] = 42161] = "ARBITRUM";
  SupportedChainId[SupportedChainId["ARBITRUM_TESTNET"] = 79377087078960] = "ARBITRUM_TESTNET";
  SupportedChainId[SupportedChainId["MOONBEAM_TESTNET"] = 1287] = "MOONBEAM_TESTNET";
  SupportedChainId[SupportedChainId["AVALANCHE"] = 43114] = "AVALANCHE";
  SupportedChainId[SupportedChainId["AVALANCHE_TESTNET"] = 43113] = "AVALANCHE_TESTNET";
  SupportedChainId[SupportedChainId["HECO"] = 128] = "HECO";
  SupportedChainId[SupportedChainId["HECO_TESTNET"] = 256] = "HECO_TESTNET";
  SupportedChainId[SupportedChainId["HARMONY"] = 1666600000] = "HARMONY";
  SupportedChainId[SupportedChainId["HARMONY_TESTNET"] = 1666700000] = "HARMONY_TESTNET";
  SupportedChainId[SupportedChainId["OKEX"] = 66] = "OKEX";
  SupportedChainId[SupportedChainId["OKEX_TESTNET"] = 65] = "OKEX_TESTNET";
  SupportedChainId[SupportedChainId["CELO"] = 42220] = "CELO";
})(SupportedChainId || (SupportedChainId = {}));

/***/ }),

/***/ 8532:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ev": function() { return /* binding */ POOL_DENY; },
/* harmony export */   "HB": function() { return /* binding */ ARCHER_RELAY_URI; },
/* harmony export */   "j2": function() { return /* binding */ ARCHER_GAS_URI; },
/* harmony export */   "gN": function() { return /* binding */ MERKLE_ROOT; },
/* harmony export */   "Vp": function() { return /* binding */ SUPPORTED_WALLETS; },
/* harmony export */   "AQ": function() { return /* binding */ NetworkContextName; },
/* harmony export */   "gv": function() { return /* binding */ INITIAL_ALLOWED_SLIPPAGE; },
/* harmony export */   "PY": function() { return /* binding */ DEFAULT_DEADLINE_FROM_NOW; },
/* harmony export */   "Rg": function() { return /* binding */ DEFAULT_ARCHER_GAS_ESTIMATE; },
/* harmony export */   "lW": function() { return /* binding */ DEFAULT_ARCHER_GAS_PRICES; },
/* harmony export */   "wP": function() { return /* binding */ DEFAULT_ARCHER_ETH_TIP; },
/* harmony export */   "iV": function() { return /* binding */ BIG_INT_ZERO; },
/* harmony export */   "IS": function() { return /* binding */ ONE_BIPS; },
/* harmony export */   "Bz": function() { return /* binding */ ALLOWED_PRICE_IMPACT_LOW; },
/* harmony export */   "p9": function() { return /* binding */ ALLOWED_PRICE_IMPACT_MEDIUM; },
/* harmony export */   "Uf": function() { return /* binding */ ALLOWED_PRICE_IMPACT_HIGH; },
/* harmony export */   "EV": function() { return /* binding */ PRICE_IMPACT_WITHOUT_FEE_CONFIRM_MIN; },
/* harmony export */   "lN": function() { return /* binding */ BLOCKED_PRICE_IMPACT_NON_EXPERT; },
/* harmony export */   "Ru": function() { return /* binding */ BETTER_TRADE_LESS_HOPS_THRESHOLD; },
/* harmony export */   "qN": function() { return /* binding */ ZERO_PERCENT; },
/* harmony export */   "yC": function() { return /* binding */ ONE_HUNDRED_PERCENT; },
/* harmony export */   "fi": function() { return /* binding */ ANALYTICS_URL; },
/* harmony export */   "rW": function() { return /* binding */ EIP_1559_ACTIVATION_BLOCK; },
/* harmony export */   "xu": function() { return /* reexport safe */ _routing__WEBPACK_IMPORTED_MODULE_3__.xu; },
/* harmony export */   "Q8": function() { return /* reexport safe */ _routing__WEBPACK_IMPORTED_MODULE_3__.Q8; },
/* harmony export */   "k_": function() { return /* reexport safe */ _addresses__WEBPACK_IMPORTED_MODULE_4__.k_; },
/* harmony export */   "C1": function() { return /* reexport safe */ _addresses__WEBPACK_IMPORTED_MODULE_4__.C1; },
/* harmony export */   "sO": function() { return /* reexport safe */ _addresses__WEBPACK_IMPORTED_MODULE_4__.sO; },
/* harmony export */   "uu": function() { return /* reexport safe */ _addresses__WEBPACK_IMPORTED_MODULE_4__.uu; },
/* harmony export */   "WD": function() { return /* reexport safe */ _tokens__WEBPACK_IMPORTED_MODULE_5__.PY; },
/* harmony export */   "hs": function() { return /* reexport safe */ _tokens__WEBPACK_IMPORTED_MODULE_5__.hs; },
/* harmony export */   "LL": function() { return /* reexport safe */ _tokens__WEBPACK_IMPORTED_MODULE_5__.LL; }
/* harmony export */ });
/* unused harmony exports RPC, AVERAGE_BLOCK_TIME_IN_SECS, BIG_INT_SECONDS_IN_WEEK, BIPS_BASE, MIN_ETH, BLOCKED_ADDRESSES, BASE_SWAPPER */
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6766);
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _connectors__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1378);
/* harmony import */ var ethers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4879);
/* harmony import */ var ethers__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(ethers__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _routing__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3418);
/* harmony import */ var _addresses__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(697);
/* harmony import */ var _tokens__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6540);



const RPC = {
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET]: 'https://eth-mainnet.alchemyapi.io/v2/ltE1K7mQs9E05usI4J6IO706waF9jYi_',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.ROPSTEN]: 'https://eth-ropsten.alchemyapi.io/v2/cidKix2Xr-snU3f6f6Zjq_rYdalKKHmW',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.RINKEBY]: 'https://eth-rinkeby.alchemyapi.io/v2/57WF1sNPcsnDzFsbg3Kv4QNMn6ZLT8q7',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId["GÖRLI"]]: 'https://eth-goerli.alchemyapi.io/v2/Dkk5d02QjttYEoGmhZnJG37rKt8Yl3Im',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.KOVAN]: 'https://eth-kovan.alchemyapi.io/v2/6OVAa_B_rypWWl9HqtiYK26IRxXiYqER',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.FANTOM]: 'https://rpcapi.fantom.network',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.FANTOM_TESTNET]: 'https://rpc.testnet.fantom.network',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC]: 'https://rpc-mainnet.maticvigil.com',
  // [ChainId.MATIC]:
  //     'https://apis.ankr.com/e22bfa5f5a124b9aa1f911b742f6adfe/c06bb163c3c2a10a4028959f4d82836d/polygon/full/main',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC_TESTNET]: 'https://rpc-mumbai.matic.today',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.XDAI]: 'https://rpc.xdaichain.com',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.BSC]: 'https://bsc-dataseed.binance.org/',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.BSC_TESTNET]: 'https://data-seed-prebsc-2-s3.binance.org:8545',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MOONBEAM_TESTNET]: 'https://rpc.testnet.moonbeam.network',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.AVALANCHE]: 'https://api.avax.network/ext/bc/C/rpc',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.AVALANCHE_TESTNET]: 'https://api.avax-test.network/ext/bc/C/rpc',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HECO]: 'https://http-mainnet.hecochain.com',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HECO_TESTNET]: 'https://http-testnet.hecochain.com',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HARMONY]: 'https://api.harmony.one',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HARMONY_TESTNET]: 'https://api.s0.b.hmny.io',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.OKEX]: 'https://exchainrpc.okex.org',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.OKEX_TESTNET]: 'https://exchaintestrpc.okex.org',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.ARBITRUM]: 'https://arb1.arbitrum.io/rpc'
};
const POOL_DENY = ['14', '29', '45', '30']; // Block time here is slightly higher (~1s) than average in order to avoid ongoing proposals past the displayed time

const AVERAGE_BLOCK_TIME_IN_SECS = 13;
const ARCHER_RELAY_URI = {
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET]: 'https://api.archerdao.io/v1/transaction'
};
const ARCHER_GAS_URI = {
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET]: 'https://api.archerdao.io/v1/gas'
}; // export const COMMON_CONTRACT_NAMES: { [address: string]: string } = {
//     // [UNI_ADDRESS]: 'UNI',
//     [TIMELOCK_ADDRESS]: 'Timelock',
// }
// TODO: update weekly with new constant

const MERKLE_ROOT = //'https://raw.githubusercontent.com/sushiswap/sushi-vesting/master/merkle/week-13/merkle-10959148-11550728.json'
//'https://raw.githubusercontent.com/sushiswap/sushi-vesting/master/merkle/week-14/merkle-10959148-11596364.json'
'https://raw.githubusercontent.com/sushiswap/sushi-vesting/master/merkle/week-15/merkle-10959148-11641996.json'; // /**
//  * Some tokens can only be swapped via certain pairs, so we override the list of bases that are considered for these
//  * tokens.
//  */
// export const CUSTOM_BASES: {
//     [chainId in ChainId]?: { [tokenAddress: string]: Token[] }
// } = {
//     [ChainId.MAINNET]: {
//         [AMPL.address]: [DAI, WETH[ChainId.MAINNET]],
//         [DUCK.address]: [USDP, WETH[ChainId.MAINNET]],
//         [BAB.address]: [BAC, WETH[ChainId.MAINNET]],
//         [HBTC.address]: [CREAM, WETH[ChainId.MAINNET]],
//         [FRAX.address]: [FXS, WETH[ChainId.MAINNET]],
//         [IBETH.address]: [ALPHA, WETH[ChainId.MAINNET]],
//         [PONT.address]: [PWING, WETH[ChainId.MAINNET]],
//         [UMA_CALL.address]: [UMA, WETH[ChainId.MAINNET]],
//         [PLAY.address]: [DOUGH, WETH[ChainId.MAINNET]],
//         [XSUSHI_CALL.address]: [XSUSHI, WETH[ChainId.MAINNET]],
//     },
// }

const SUPPORTED_WALLETS = {
  INJECTED: {
    connector: _connectors__WEBPACK_IMPORTED_MODULE_1__/* .injected */ .Lj,
    name: 'Injected',
    iconName: 'injected.svg',
    description: 'Injected web3 provider.',
    href: null,
    color: '#010101',
    primary: true
  },
  METAMASK: {
    connector: _connectors__WEBPACK_IMPORTED_MODULE_1__/* .injected */ .Lj,
    name: 'MetaMask',
    iconName: 'metamask.png',
    description: 'Easy-to-use browser extension.',
    href: null,
    color: '#E8831D'
  },
  WALLET_CONNECT: {
    connector: _connectors__WEBPACK_IMPORTED_MODULE_1__/* .walletconnect */ .Lw,
    name: 'WalletConnect',
    iconName: 'wallet-connect.svg',
    description: 'Connect to Trust Wallet, Rainbow Wallet and more...',
    href: null,
    color: '#4196FC',
    mobile: true
  },
  LATTICE: {
    connector: async () => {
      const LatticeConnector = (await Promise.resolve(/* import() */).then(__webpack_require__.t.bind(__webpack_require__, 4248, 23))).LatticeConnector;
      return new LatticeConnector({
        chainId: 1,
        url: RPC[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET],
        appName: 'SushiSwap'
      });
    },
    name: 'Lattice',
    iconName: 'lattice.png',
    description: 'Connect to GridPlus Wallet.',
    href: null,
    color: '#40a9ff',
    mobile: true
  },
  WALLET_LINK: {
    connector: _connectors__WEBPACK_IMPORTED_MODULE_1__/* .walletlink */ .H5,
    name: 'Coinbase Wallet',
    iconName: 'coinbase.svg',
    description: 'Use Coinbase Wallet app on mobile device',
    href: null,
    color: '#315CF5'
  },
  COINBASE_LINK: {
    name: 'Open in Coinbase Wallet',
    iconName: 'coinbase.svg',
    description: 'Open in Coinbase Wallet app.',
    href: 'https://go.cb-w.com',
    color: '#315CF5',
    mobile: true,
    mobileOnly: true
  },
  FORTMATIC: {
    connector: _connectors__WEBPACK_IMPORTED_MODULE_1__/* .fortmatic */ .pp,
    name: 'Fortmatic',
    iconName: 'fortmatic.png',
    description: 'Login using Fortmatic hosted wallet',
    href: null,
    color: '#6748FF',
    mobile: true
  },
  Portis: {
    connector: _connectors__WEBPACK_IMPORTED_MODULE_1__/* .portis */ .yO,
    name: 'Portis',
    iconName: 'portis.png',
    description: 'Login using Portis hosted wallet',
    href: null,
    color: '#4A6C9B',
    mobile: true
  },
  Torus: {
    connector: _connectors__WEBPACK_IMPORTED_MODULE_1__/* .torus */ .ux,
    name: 'Torus',
    iconName: 'torus.png',
    description: 'Login using Torus hosted wallet',
    href: null,
    color: '#315CF5',
    mobile: true
  },
  Binance: {
    connector: _connectors__WEBPACK_IMPORTED_MODULE_1__/* .binance */ .Oh,
    name: 'Binance',
    iconName: 'bsc.jpg',
    description: 'Login using Binance hosted wallet',
    href: null,
    color: '#F0B90B',
    mobile: true
  }
};
const NetworkContextName = 'NETWORK'; // default allowed slippage, in bips

const INITIAL_ALLOWED_SLIPPAGE = 50; // 30 minutes, denominated in seconds

const DEFAULT_DEADLINE_FROM_NOW = 60 * 30; // default archer gas estimate, 250k wei

const DEFAULT_ARCHER_GAS_ESTIMATE = ethers__WEBPACK_IMPORTED_MODULE_2__.BigNumber.from(250000); // default gas prices to use if all other sources unavailable

const DEFAULT_ARCHER_GAS_PRICES = [ethers__WEBPACK_IMPORTED_MODULE_2__.BigNumber.from(60000000000), ethers__WEBPACK_IMPORTED_MODULE_2__.BigNumber.from(70000000000), ethers__WEBPACK_IMPORTED_MODULE_2__.BigNumber.from(100000000000), ethers__WEBPACK_IMPORTED_MODULE_2__.BigNumber.from(140000000000), ethers__WEBPACK_IMPORTED_MODULE_2__.BigNumber.from(300000000000), ethers__WEBPACK_IMPORTED_MODULE_2__.BigNumber.from(800000000000), ethers__WEBPACK_IMPORTED_MODULE_2__.BigNumber.from(2000000000000)]; // default miner tip, equal to median gas price * default gas estimate

const DEFAULT_ARCHER_ETH_TIP = _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(DEFAULT_ARCHER_GAS_ESTIMATE.mul(DEFAULT_ARCHER_GAS_PRICES[4]).toString()); // used for rewards deadlines

const BIG_INT_SECONDS_IN_WEEK = _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(60 * 60 * 24 * 7);
const BIG_INT_ZERO = _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(0); // one basis point

const ONE_BIPS = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Percent(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(1), _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(10000));
const BIPS_BASE = _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(10000); // used for warning states

const ALLOWED_PRICE_IMPACT_LOW = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Percent(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(100), BIPS_BASE); // 1%

const ALLOWED_PRICE_IMPACT_MEDIUM = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Percent(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(300), BIPS_BASE); // 3%

const ALLOWED_PRICE_IMPACT_HIGH = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Percent(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(500), BIPS_BASE); // 5%
// if the price slippage exceeds this number, force the user to type 'confirm' to execute

const PRICE_IMPACT_WITHOUT_FEE_CONFIRM_MIN = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Percent(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(1000), BIPS_BASE); // 10%
// for non expert mode disable swaps above this

const BLOCKED_PRICE_IMPACT_NON_EXPERT = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Percent(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(1500), BIPS_BASE); // 15%
// used to ensure the user doesn't send so much ETH so they end up with <.01

const MIN_ETH = _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.exponentiate(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(10), _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(16)); // .01 ETH

const BETTER_TRADE_LESS_HOPS_THRESHOLD = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Percent(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(50), _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(10000));
const ZERO_PERCENT = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Percent('0');
const ONE_HUNDRED_PERCENT = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Percent('1'); // SDN OFAC addresses

const BLOCKED_ADDRESSES = (/* unused pure expression or super */ null && (['0x7F367cC41522cE07553e823bf3be79A889DEbe1B', '0xd882cFc20F52f2599D84b8e8D58C7FB62cfE344b', '0x901bb9583b24D97e995513C6778dc6888AB6870e', '0xA7e5d5A720f06526557c513402f2e6B5fA20b008'])); // BentoBox Swappers

const BASE_SWAPPER = {
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET]: '0x0',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.ROPSTEN]: '0xe4E2540D421e56b0B786d40c5F5268891288c6fb'
}; // Boring Helper
// export const BORING_HELPER_ADDRESS = '0x11Ca5375AdAfd6205E41131A4409f182677996E6'

const ANALYTICS_URL = {
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET]: 'https://analytics.sushi.com',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC]: 'https://analytics-polygon.sushi.com',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.FANTOM]: 'https://analytics-ftm.sushi.com',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.BSC]: 'https://analytics-bsc.sushi.com',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.XDAI]: 'https://analytics-xdai.sushi.com',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HARMONY]: 'https://analytics-harmony.sushi.com',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.ARBITRUM]: undefined
};
const EIP_1559_ACTIVATION_BLOCK = {
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.ROPSTEN]: 10499401,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId["GÖRLI"]]: 5062605,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.RINKEBY]: 8897988
};




/***/ }),

/***/ 5635:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "L0": function() { return /* binding */ MINIMUM_TARGET_UTILIZATION; },
/* harmony export */   "Ey": function() { return /* binding */ MAXIMUM_TARGET_UTILIZATION; },
/* harmony export */   "h7": function() { return /* binding */ FULL_UTILIZATION_MINUS_MAX; },
/* harmony export */   "x3": function() { return /* binding */ STARTING_INTEREST_PER_YEAR; },
/* harmony export */   "a3": function() { return /* binding */ MINIMUM_INTEREST_PER_YEAR; },
/* harmony export */   "eD": function() { return /* binding */ MAXIMUM_INTEREST_PER_YEAR; },
/* harmony export */   "ch": function() { return /* binding */ INTEREST_ELASTICITY; },
/* harmony export */   "v5": function() { return /* binding */ FACTOR_PRECISION; },
/* harmony export */   "rO": function() { return /* binding */ PROTOCOL_FEE; },
/* harmony export */   "LY": function() { return /* binding */ PROTOCOL_FEE_DIVISOR; },
/* harmony export */   "OI": function() { return /* binding */ BENTOBOX_ADDRESS; },
/* harmony export */   "MO": function() { return /* binding */ KASHI_ADDRESS; },
/* harmony export */   "B9": function() { return /* binding */ SUSHISWAP_MULTISWAPPER_ADDRESS; },
/* harmony export */   "XX": function() { return /* binding */ SUSHISWAP_MULTI_EXACT_SWAPPER_ADDRESS; },
/* harmony export */   "oZ": function() { return /* binding */ SUSHISWAP_TWAP_0_ORACLE_ADDRESS; },
/* harmony export */   "qn": function() { return /* binding */ SUSHISWAP_TWAP_1_ORACLE_ADDRESS; },
/* harmony export */   "uA": function() { return /* binding */ CHAINLINK_ORACLE_ADDRESS; },
/* harmony export */   "pq": function() { return /* binding */ BORING_HELPER_ADDRESS; }
/* harmony export */ });
/* unused harmony exports ACTION_ADD_ASSET, ACTION_REPAY, ACTION_REMOVE_ASSET, ACTION_REMOVE_COLLATERAL, ACTION_BORROW, ACTION_GET_REPAY_SHARE, ACTION_GET_REPAY_PART, ACTION_ACCRUE, ACTION_ADD_COLLATERAL, ACTION_UPDATE_EXCHANGE_RATE, ACTION_BENTO_DEPOSIT, ACTION_BENTO_WITHDRAW, ACTION_BENTO_TRANSFER, ACTION_BENTO_TRANSFER_MULTIPLE, ACTION_BENTO_SETAPPROVAL, ACTION_CALL, UTILIZATION_PRECISION, FULL_UTILIZATION, SUSHISWAP_SWAPPER_ADDRESS, PEGGED_ORACLE_ADDRESS */
/* harmony import */ var _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1446);
/* harmony import */ var _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6766);
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__);

 // Functions that need accrue to be called

const ACTION_ADD_ASSET = 1;
const ACTION_REPAY = 2;
const ACTION_REMOVE_ASSET = 3;
const ACTION_REMOVE_COLLATERAL = 4;
const ACTION_BORROW = 5;
const ACTION_GET_REPAY_SHARE = 6;
const ACTION_GET_REPAY_PART = 7;
const ACTION_ACCRUE = 8; // Functions that don't need accrue to be called

const ACTION_ADD_COLLATERAL = 10;
const ACTION_UPDATE_EXCHANGE_RATE = 11; // Function on BentoBox

const ACTION_BENTO_DEPOSIT = 20;
const ACTION_BENTO_WITHDRAW = 21;
const ACTION_BENTO_TRANSFER = 22;
const ACTION_BENTO_TRANSFER_MULTIPLE = 23;
const ACTION_BENTO_SETAPPROVAL = 24; // Any external call (except to BentoBox)

const ACTION_CALL = 30;
const MINIMUM_TARGET_UTILIZATION = _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0__.BigNumber.from('700000000000000000'); // 70%

const MAXIMUM_TARGET_UTILIZATION = _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0__.BigNumber.from('800000000000000000'); // 80%

const UTILIZATION_PRECISION = _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0__.BigNumber.from('1000000000000000000');
const FULL_UTILIZATION = _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0__.BigNumber.from('1000000000000000000');
const FULL_UTILIZATION_MINUS_MAX = FULL_UTILIZATION.sub(MAXIMUM_TARGET_UTILIZATION);
const STARTING_INTEREST_PER_YEAR = _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0__.BigNumber.from(317097920).mul(_ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0__.BigNumber.from(60)).mul(_ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0__.BigNumber.from(60)).mul(_ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0__.BigNumber.from(24)).mul(_ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0__.BigNumber.from(365)); // approx 1% APR

const MINIMUM_INTEREST_PER_YEAR = _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0__.BigNumber.from(79274480).mul(_ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0__.BigNumber.from(60)).mul(_ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0__.BigNumber.from(60)).mul(_ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0__.BigNumber.from(24)).mul(_ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0__.BigNumber.from(365)); // approx 0.25% APR

const MAXIMUM_INTEREST_PER_YEAR = _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0__.BigNumber.from(317097920000).mul(_ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0__.BigNumber.from(60)).mul(_ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0__.BigNumber.from(60)).mul(_ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0__.BigNumber.from(24)).mul(_ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0__.BigNumber.from(365)); // approx 1000% APR

const INTEREST_ELASTICITY = _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0__.BigNumber.from('28800000000000000000000000000000000000000'); // Half or double in 28800 seconds (8 hours) if linear

const FACTOR_PRECISION = _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0__.BigNumber.from('1000000000000000000');
const PROTOCOL_FEE = _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0__.BigNumber.from('10000'); // 10%

const PROTOCOL_FEE_DIVISOR = _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0__.BigNumber.from('100000'); // export const BENTOBOX_ADDRESS = '0xF5BCE5077908a1b7370B9ae04AdC565EBd643966'

const BENTOBOX_ADDRESS = {
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MAINNET]: '0xF5BCE5077908a1b7370B9ae04AdC565EBd643966',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.ROPSTEN]: '0xF5BCE5077908a1b7370B9ae04AdC565EBd643966',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.RINKEBY]: '0xF5BCE5077908a1b7370B9ae04AdC565EBd643966',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId["GÖRLI"]]: '0xF5BCE5077908a1b7370B9ae04AdC565EBd643966',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.KOVAN]: '0xF5BCE5077908a1b7370B9ae04AdC565EBd643966',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.FANTOM]: '0xF5BCE5077908a1b7370B9ae04AdC565EBd643966',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.FANTOM_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MATIC]: '0x0319000133d3AdA02600f0875d2cf03D442C3367',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MATIC_TESTNET]: '0xF5BCE5077908a1b7370B9ae04AdC565EBd643966',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.XDAI]: '0xE2d7F5dd869Fc7c126D21b13a9080e75a4bDb324',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.BSC]: '0xF5BCE5077908a1b7370B9ae04AdC565EBd643966',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.BSC_TESTNET]: '0xF5BCE5077908a1b7370B9ae04AdC565EBd643966',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.ARBITRUM]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.ARBITRUM_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MOONBEAM_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.AVALANCHE]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.AVALANCHE_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HECO]: '0xF5BCE5077908a1b7370B9ae04AdC565EBd643966',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HECO_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HARMONY]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HARMONY_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.OKEX]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.OKEX_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.CELO]: ''
};
const KASHI_ADDRESS = {
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MAINNET]: '0x2cBA6Ab6574646Badc84F0544d05059e57a5dc42',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.ROPSTEN]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.RINKEBY]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId["GÖRLI"]]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.KOVAN]: '0x2cBA6Ab6574646Badc84F0544d05059e57a5dc42',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.FANTOM]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.FANTOM_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MATIC]: '0xB527C5295c4Bc348cBb3a2E96B2494fD292075a7',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MATIC_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.XDAI]: '0x7a6DA9903d0a481F40b8336c1463487BC8C0407e',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.BSC]: '0x2cBA6Ab6574646Badc84F0544d05059e57a5dc42',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.BSC_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.ARBITRUM]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.ARBITRUM_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MOONBEAM_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.AVALANCHE]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.AVALANCHE_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HECO]: '0x2cBA6Ab6574646Badc84F0544d05059e57a5dc42',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HECO_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HARMONY]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HARMONY_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.OKEX]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.OKEX_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.CELO]: ''
}; // export const KASHI_ADDRESS = '0x2cBA6Ab6574646Badc84F0544d05059e57a5dc42'

const SUSHISWAP_SWAPPER_ADDRESS = {
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MAINNET]: '0x1766733112408b95239aD1951925567CB1203084',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.ROPSTEN]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.RINKEBY]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId["GÖRLI"]]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.KOVAN]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.FANTOM]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.FANTOM_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MATIC]: '0xe9589382130Ded5DF2397E2fD7A3E9b41DD2701D',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MATIC_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.XDAI]: '0xE02BDb31C353CE95A1D74F81C93eEa70Bf7371B9',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.BSC]: '0x1766733112408b95239aD1951925567CB1203084',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.BSC_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.ARBITRUM]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.ARBITRUM_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MOONBEAM_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.AVALANCHE]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.AVALANCHE_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HECO]: '0x1766733112408b95239aD1951925567CB1203084',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HECO_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HARMONY]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HARMONY_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.OKEX]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.OKEX_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.CELO]: ''
};
const SUSHISWAP_MULTISWAPPER_ADDRESS = {
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MAINNET]: '0x545820d5Cc05248da112419fEfb18522c63C8e12',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.ROPSTEN]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.RINKEBY]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId["GÖRLI"]]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.KOVAN]: '0xc0c1649b2c67f1a9f5ff1dd618188165e2555bcf',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.FANTOM]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.FANTOM_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MATIC]: '0x73BE093B84c773fe8eE0f76DDc0829E45c215415',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MATIC_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.XDAI]: '0x735f0FbEb3b6389986BcaAf073Af07D2F8be2b93',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.BSC]: '0x86c655cAc122e9A2fd9Ae1f79Df27b30E357968c',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.BSC_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.ARBITRUM]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.ARBITRUM_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MOONBEAM_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.AVALANCHE]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.AVALANCHE_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HECO]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HECO_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HARMONY]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HARMONY_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.OKEX]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.OKEX_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.CELO]: ''
};
const SUSHISWAP_MULTI_EXACT_SWAPPER_ADDRESS = {
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MAINNET]: '0xB527C5295c4Bc348cBb3a2E96B2494fD292075a7',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.ROPSTEN]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.RINKEBY]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId["GÖRLI"]]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.KOVAN]: '0x75AE0Aa596D39b20addC921DeB5EE3c96279dABE',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.FANTOM]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.FANTOM_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MATIC]: '0xDB6C4EDd9545d3b815dA85E6429B699c418886f9',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MATIC_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.XDAI]: '0x07b6e34EeCF38B02e83b6B4702699717e298967E',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.BSC]: '0x1B16149Edaf1EFa6ADE6aEEF33e63C6e08c9bB1B',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.BSC_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.ARBITRUM]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.ARBITRUM_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MOONBEAM_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.AVALANCHE]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.AVALANCHE_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HECO]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HECO_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HARMONY]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HARMONY_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.OKEX]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.OKEX_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.CELO]: ''
};
const PEGGED_ORACLE_ADDRESS = '0x6cbfbB38498Df0E1e7A4506593cDB02db9001564';
const SUSHISWAP_TWAP_0_ORACLE_ADDRESS = '0x66F03B0d30838A3fee971928627ea6F59B236065';
const SUSHISWAP_TWAP_1_ORACLE_ADDRESS = '0x0D51b575591F8f74a2763Ade75D3CDCf6789266f';
const CHAINLINK_ORACLE_ADDRESS = '0x00632CFe43d8F9f8E6cD0d39Ffa3D4fa7ec73CFB';
const BORING_HELPER_ADDRESS = {
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MAINNET]: '0x11Ca5375AdAfd6205E41131A4409f182677996E6',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.ROPSTEN]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.RINKEBY]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId["GÖRLI"]]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.KOVAN]: '0x11Ca5375AdAfd6205E41131A4409f182677996E6',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.FANTOM]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.FANTOM_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MATIC]: '0xA77a7fD5a16237B85E0FAd02C51f459D18AE93Cd',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MATIC_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.XDAI]: '0x97e4a0fb71243A83A6FbaEF7Cf73617594e4cF2F',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.BSC]: '0x11Ca5375AdAfd6205E41131A4409f182677996E6',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.BSC_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.ARBITRUM]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.ARBITRUM_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MOONBEAM_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.AVALANCHE]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.AVALANCHE_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HECO]: '0x11Ca5375AdAfd6205E41131A4409f182677996E6',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HECO_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HARMONY]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HARMONY_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.OKEX]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.OKEX_TESTNET]: '',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.CELO]: ''
};

/***/ }),

/***/ 3418:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "lM": function() { return /* binding */ BASES_TO_CHECK_TRADES_AGAINST; },
/* harmony export */   "ck": function() { return /* binding */ ADDITIONAL_BASES; },
/* harmony export */   "IP": function() { return /* binding */ CUSTOM_BASES; },
/* harmony export */   "gP": function() { return /* binding */ COMMON_BASES; },
/* harmony export */   "xu": function() { return /* binding */ BASES_TO_TRACK_LIQUIDITY_FOR; },
/* harmony export */   "Q8": function() { return /* binding */ PINNED_PAIRS; }
/* harmony export */ });
/* harmony import */ var _tokens__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6540);
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6766);
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

 // a list of tokens by chain


// List of all mirror's assets addresses.
// Last pulled from : https://whitelist.mirror.finance/eth/tokenlists.json
// TODO: Generate this programmatically ?
const MIRROR_ADDITIONAL_BASES = {
  [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .UST.address */ .bi.address]: [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MIR */ .Td],
  [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MIR.address */ .Td.address]: [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .UST */ .bi],
  '0xd36932143F6eBDEDD872D5Fb0651f4B72Fd15a84': [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MIR */ .Td, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .UST */ .bi],
  // mAAPL
  '0x59A921Db27Dd6d4d974745B7FfC5c33932653442': [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MIR */ .Td, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .UST */ .bi],
  // mGOOGL
  '0x21cA39943E91d704678F5D00b6616650F066fD63': [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MIR */ .Td, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .UST */ .bi],
  // mTSLA
  '0xC8d674114bac90148d11D3C1d33C61835a0F9DCD': [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MIR */ .Td, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .UST */ .bi],
  // mNFLX
  '0x13B02c8dE71680e71F0820c996E4bE43c2F57d15': [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MIR */ .Td, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .UST */ .bi],
  // mQQQ
  '0xEdb0414627E6f1e3F082DE65cD4F9C693D78CCA9': [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MIR */ .Td, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .UST */ .bi],
  // mTWTR
  '0x41BbEDd7286dAab5910a1f15d12CBda839852BD7': [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MIR */ .Td, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .UST */ .bi],
  // mMSFT
  '0x0cae9e4d663793c2a2A0b211c1Cf4bBca2B9cAa7': [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MIR */ .Td, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .UST */ .bi],
  // mAMZN
  '0x56aA298a19C93c6801FDde870fA63EF75Cc0aF72': [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MIR */ .Td, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .UST */ .bi],
  // mBABA
  '0x1d350417d9787E000cc1b95d70E9536DcD91F373': [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MIR */ .Td, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .UST */ .bi],
  // mIAU
  '0x9d1555d8cB3C846Bb4f7D5B1B1080872c3166676': [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MIR */ .Td, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .UST */ .bi],
  // mSLV
  '0x31c63146a635EB7465e5853020b39713AC356991': [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MIR */ .Td, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .UST */ .bi],
  // mUSO
  '0xf72FCd9DCF0190923Fadd44811E240Ef4533fc86': [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MIR */ .Td, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .UST */ .bi] // mVIXY

}; // TODO: SDK should have two maps, WETH map and WNATIVE map.

const WRAPPED_NATIVE_ONLY = {
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MAINNET]: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MAINNET]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.ROPSTEN]: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.ROPSTEN]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.RINKEBY]: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.RINKEBY]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId["GÖRLI"]]: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId["GÖRLI"]]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.KOVAN]: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.KOVAN]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.FANTOM]: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.FANTOM]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.FANTOM_TESTNET]: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.FANTOM_TESTNET]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MATIC]: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MATIC]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MATIC_TESTNET]: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MATIC_TESTNET]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.XDAI]: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.XDAI]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.BSC]: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.BSC]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.BSC_TESTNET]: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.BSC_TESTNET]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.ARBITRUM]: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.ARBITRUM]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.ARBITRUM_TESTNET]: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.ARBITRUM_TESTNET]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MOONBEAM_TESTNET]: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MOONBEAM_TESTNET]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.AVALANCHE]: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.AVALANCHE]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.AVALANCHE_TESTNET]: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.AVALANCHE_TESTNET]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HECO]: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HECO]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HECO_TESTNET]: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HECO_TESTNET]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HARMONY]: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HARMONY]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HARMONY_TESTNET]: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HARMONY_TESTNET]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.OKEX]: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.OKEX]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.OKEX_TESTNET]: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.OKEX_TESTNET]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.CELO]: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.CELO]]
}; // used to construct intermediary pairs for trading

const BASES_TO_CHECK_TRADES_AGAINST = _objectSpread(_objectSpread({}, WRAPPED_NATIVE_ONLY), {}, {
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MAINNET]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MAINNET], _tokens__WEBPACK_IMPORTED_MODULE_0__/* .DAI */ .h1, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .USDC */ .gn, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .USDT */ .AA, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .WBTC */ .ML, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .RUNE */ .uj, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .NFTX */ .lK, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .STETH */ ._S],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MATIC]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MATIC], _tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.USDC */ .W3.USDC, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.WBTC */ .W3.WBTC, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.DAI */ .W3.DAI, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.WETH */ .W3.WETH, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.USDT */ .W3.USDT],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.FANTOM]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.FANTOM], _tokens__WEBPACK_IMPORTED_MODULE_0__/* .FANTOM.DAI */ .of.DAI, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .FANTOM.USDC */ .of.USDC, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .FANTOM.WBTC */ .of.WBTC, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .FANTOM.WETH */ .of.WETH],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.BSC]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.BSC], _tokens__WEBPACK_IMPORTED_MODULE_0__/* .BSC.DAI */ .Su.DAI, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .BSC.USD */ .Su.USD, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .BSC.USDC */ .Su.USDC, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .BSC.USDT */ .Su.USDT, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .BSC.BTCB */ .Su.BTCB, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .BSC.WETH */ .Su.WETH],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.ARBITRUM]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.ARBITRUM]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.XDAI]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.XDAI], _tokens__WEBPACK_IMPORTED_MODULE_0__/* .XDAI.USDC */ .AC.USDC, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .XDAI.USDT */ .AC.USDT, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .XDAI.WBTC */ .AC.WBTC, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .XDAI.WETH */ .AC.WETH],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.AVALANCHE]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.AVALANCHE], _tokens__WEBPACK_IMPORTED_MODULE_0__/* .AVALANCHE.DAI */ .Qz.DAI, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .AVALANCHE.USDT */ .Qz.USDT, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .AVALANCHE.WBTC */ .Qz.WBTC, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .AVALANCHE.WETH */ .Qz.WETH],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HARMONY]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HARMONY], _tokens__WEBPACK_IMPORTED_MODULE_0__/* .HARMONY.DAI */ ._T.DAI, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .HARMONY.USDC */ ._T.USDC, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .HARMONY.USDT */ ._T.USDT, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .HARMONY.WBTC */ ._T.WBTC, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .HARMONY.WETH */ ._T.WETH],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HECO]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HECO], _tokens__WEBPACK_IMPORTED_MODULE_0__/* .HECO.DAI */ .rs.DAI, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .HECO.USDC */ .rs.USDC, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .HECO.USDT */ .rs.USDT, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .HECO.WBTC */ .rs.WBTC, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .HECO.WETH */ .rs.WETH],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.OKEX]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.OKEX], _tokens__WEBPACK_IMPORTED_MODULE_0__/* .OKEX.DAI */ .Xn.DAI, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .OKEX.USDC */ .Xn.USDC, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .OKEX.USDT */ .Xn.USDT, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .OKEX.WBTC */ .Xn.WBTC, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .OKEX.WETH */ .Xn.WETH],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.CELO]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.CELO], _tokens__WEBPACK_IMPORTED_MODULE_0__/* .CELO.mCUSD */ .T5.mCUSD, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .CELO.mCELO */ .T5.mCELO, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .CELO.mcEURO */ .T5.mcEURO, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .CELO.cUSD */ .T5.cUSD, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .CELO.cEURO */ .T5.cEURO, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .CELO.cBTC */ .T5.cBTC]
});
const ADDITIONAL_BASES = {
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MAINNET]: _objectSpread(_objectSpread({}, MIRROR_ADDITIONAL_BASES), {}, {
    '0xF16E4d813f4DcfDe4c5b44f305c908742De84eF0': [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .ETH2X_FLI */ .Lp],
    '0xe379a60A8FC7C9DD161887fFADF3054790576c8D': [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .XSUSHI */ .LL],
    // XSUSHI 25 Call [30 June 2021]
    '0xB46F57e7Ce3a284d74b70447Ef9352B5E5Df8963': [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .UMA */ .iD],
    // UMA 25 Call [30 June 2021]
    [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .FEI.address */ .sr.address]: [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .TRIBE */ .em],
    [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .TRIBE.address */ .em.address]: [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .FEI */ .sr],
    [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .FRAX.address */ .BN.address]: [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .FXS */ .xn],
    [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .FXS.address */ .xn.address]: [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .FRAX */ .BN],
    [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .WBTC.address */ .ML.address]: [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .RENBTC */ .vS],
    [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .RENBTC.address */ .vS.address]: [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .WBTC */ .ML],
    [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .PONT.address */ .YY.address]: [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .PWING */ .Wg],
    [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .PWING.address */ .Wg.address]: [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .PONT */ .YY],
    [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .PLAY.address */ .NH.address]: [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .DOUGH */ .du],
    [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .DOUGH.address */ .du.address]: [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .PLAY */ .NH],
    [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .IBETH.address */ .yl.address]: [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .ALPHA */ .Xe],
    [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .ALPHA.address */ .Xe.address]: [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .IBETH */ .yl],
    [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .HBTC.address */ .y7.address]: [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .CREAM */ .rK],
    [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .CREAM.address */ .rK.address]: [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .HBTC */ .y7],
    [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .DUCK.address */ .IE.address]: [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .USDP */ .Es],
    [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .USDP.address */ .Es.address]: [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .DUCK */ .IE],
    [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .BAB.address */ ._C.address]: [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .BAC */ .mf],
    [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .BAC.address */ .mf.address]: [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .BAB */ ._C],
    [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .LIFT.address */ .t3.address]: [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .LFBTC */ .iI],
    [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .LFBTC.address */ .iI.address]: [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .LIFT */ .t3],
    [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .CVXCRV.address */ .Wo.address]: [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .CRV */ .be],
    [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .CRV.address */ .be.address]: [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .CVXCRV */ .Wo]
  }),
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MATIC]: {
    [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.FRAX.address */ .W3.FRAX.address]: [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.FXS */ .W3.FXS],
    [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.FXS.address */ .W3.FXS.address]: [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.FRAX */ .W3.FRAX],
    [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.DRAX.address */ .W3.DRAX.address]: [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.DMAGIC */ .W3.DMAGIC],
    [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.DMAGIC.address */ .W3.DMAGIC.address]: [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.DRAX */ .W3.DRAX]
  }
};
/**
 * Some tokens can only be swapped via certain pairs, so we override the list of bases that are considered for these
 * tokens.
 */

const CUSTOM_BASES = {
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MAINNET]: {
    [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .AMPL.address */ .s5.address]: [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .DAI */ .h1, _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MAINNET]]
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MATIC]: {
    [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.TEL.address */ .W3.TEL.address]: [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.SUSHI */ .W3.SUSHI, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.AAVE */ .W3.AAVE]
  }
};
/**
 * Shows up in the currency select for swap and add liquidity
 */
// export const COMMON_BASES: ChainCurrencyList = {
//     [ChainId.MAINNET]: [ExtendedEther.onChain(1), DAI, USDC, USDT, WBTC, WETH9_EXTENDED[1]],
//     [3]: [ExtendedEther.onChain(3), WETH9_EXTENDED[3]],
//     [4]: [ExtendedEther.onChain(4), WETH9_EXTENDED[4]],
//     [5]: [ExtendedEther.onChain(5), WETH9_EXTENDED[5]],
//     [42]: [ExtendedEther.onChain(42), WETH9_EXTENDED[42]],
//     [SupportedChainId.ARBITRUM_KOVAN]: [
//         ExtendedEther.onChain(SupportedChainId.ARBITRUM_KOVAN),
//         WETH9_EXTENDED[SupportedChainId.ARBITRUM_KOVAN],
//     ],
//     [SupportedChainId.ARBITRUM_ONE]: [
//         ExtendedEther.onChain(SupportedChainId.ARBITRUM_ONE),
//         WETH9_EXTENDED[SupportedChainId.ARBITRUM_ONE],
//     ],
// }

/**
 * Shows up in the currency select for swap and add liquidity
 */

const COMMON_BASES = {
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MAINNET]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MAINNET], _tokens__WEBPACK_IMPORTED_MODULE_0__/* .DAI */ .h1, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .USDC */ .gn, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .USDT */ .AA, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .WBTC */ .ML],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MATIC]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MATIC], _tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.USDC */ .W3.USDC, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.WBTC */ .W3.WBTC, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.DAI */ .W3.DAI, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.WETH */ .W3.WETH, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.USDT */ .W3.USDT],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.FANTOM]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.FANTOM], _tokens__WEBPACK_IMPORTED_MODULE_0__/* .FANTOM.DAI */ .of.DAI, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .FANTOM.USDC */ .of.USDC, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .FANTOM.WBTC */ .of.WBTC, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .FANTOM.WETH */ .of.WETH],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.BSC]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.BSC], _tokens__WEBPACK_IMPORTED_MODULE_0__/* .BSC.DAI */ .Su.DAI, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .BSC.USD */ .Su.USD, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .BSC.USDC */ .Su.USDC, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .BSC.USDT */ .Su.USDT, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .BSC.BTCB */ .Su.BTCB, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .BSC.WETH */ .Su.WETH],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.ARBITRUM]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.ARBITRUM]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.XDAI]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.XDAI], _tokens__WEBPACK_IMPORTED_MODULE_0__/* .XDAI.USDC */ .AC.USDC, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .XDAI.USDT */ .AC.USDT, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .XDAI.WBTC */ .AC.WBTC, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .XDAI.WETH */ .AC.WETH],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.AVALANCHE]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.AVALANCHE], _tokens__WEBPACK_IMPORTED_MODULE_0__/* .AVALANCHE.DAI */ .Qz.DAI, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .AVALANCHE.USDT */ .Qz.USDT, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .AVALANCHE.WBTC */ .Qz.WBTC, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .AVALANCHE.WETH */ .Qz.WETH],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HARMONY]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HARMONY], _tokens__WEBPACK_IMPORTED_MODULE_0__/* .HARMONY.DAI */ ._T.DAI, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .HARMONY.USDC */ ._T.USDC, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .HARMONY.USDT */ ._T.USDT, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .HARMONY.WETH */ ._T.WETH, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .HARMONY.WBTC */ ._T.WBTC],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HECO]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HECO], _tokens__WEBPACK_IMPORTED_MODULE_0__/* .HECO.DAI */ .rs.DAI, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .HECO.USDC */ .rs.USDC, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .HECO.USDT */ .rs.USDT, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .HECO.WBTC */ .rs.WBTC, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .HECO.WETH */ .rs.WETH],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.OKEX]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.OKEX], _tokens__WEBPACK_IMPORTED_MODULE_0__/* .OKEX.DAI */ .Xn.DAI, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .OKEX.USDC */ .Xn.USDC, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .OKEX.USDT */ .Xn.USDT, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .OKEX.WBTC */ .Xn.WBTC, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .OKEX.WETH */ .Xn.WETH] // [ChainId.CELO]: [
  //   ...WRAPPED_NATIVE_ONLY[ChainId.CELO],
  //   CELO.mCUSD,
  //   CELO.mCELO,
  //   CELO.mcEURO,
  //   CELO.cEUR,
  // ],

}; // used to construct the list of all pairs we consider by default in the frontend

const BASES_TO_TRACK_LIQUIDITY_FOR = _objectSpread(_objectSpread({}, WRAPPED_NATIVE_ONLY), {}, {
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MAINNET]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MAINNET], _tokens__WEBPACK_IMPORTED_MODULE_0__/* .DAI */ .h1, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .USDC */ .gn, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .USDT */ .AA, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .WBTC */ .ML],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MATIC]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MATIC], _tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.USDC */ .W3.USDC, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.WBTC */ .W3.WBTC, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.DAI */ .W3.DAI, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.WETH */ .W3.WETH, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .MATIC.USDT */ .W3.USDT],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.FANTOM]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.FANTOM], _tokens__WEBPACK_IMPORTED_MODULE_0__/* .FANTOM.DAI */ .of.DAI, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .FANTOM.USDC */ .of.USDC, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .FANTOM.WBTC */ .of.WBTC, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .FANTOM.WETH */ .of.WETH],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.BSC]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.BSC], _tokens__WEBPACK_IMPORTED_MODULE_0__/* .BSC.DAI */ .Su.DAI, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .BSC.USD */ .Su.USD, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .BSC.USDC */ .Su.USDC, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .BSC.USDT */ .Su.USDT, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .BSC.BTCB */ .Su.BTCB, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .BSC.WETH */ .Su.WETH],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.ARBITRUM]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.ARBITRUM]],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.XDAI]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.XDAI], _tokens__WEBPACK_IMPORTED_MODULE_0__/* .XDAI.USDC */ .AC.USDC, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .XDAI.USDT */ .AC.USDT, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .XDAI.WBTC */ .AC.WBTC, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .XDAI.WETH */ .AC.WETH],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.AVALANCHE]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.AVALANCHE], _tokens__WEBPACK_IMPORTED_MODULE_0__/* .AVALANCHE.DAI */ .Qz.DAI, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .AVALANCHE.USDT */ .Qz.USDT, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .AVALANCHE.WBTC */ .Qz.WBTC, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .AVALANCHE.WETH */ .Qz.WETH],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HARMONY]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HARMONY], _tokens__WEBPACK_IMPORTED_MODULE_0__/* .HARMONY.DAI */ ._T.DAI, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .HARMONY.USDC */ ._T.USDC, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .HARMONY.USDT */ ._T.USDT, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .HARMONY.WBTC */ ._T.WBTC, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .HARMONY.WETH */ ._T.WETH],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HECO]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HECO], _tokens__WEBPACK_IMPORTED_MODULE_0__/* .HECO.DAI */ .rs.DAI, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .HECO.USDC */ .rs.USDC, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .HECO.USDT */ .rs.USDT, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .HECO.WBTC */ .rs.WBTC, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .HECO.WETH */ .rs.WETH],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.OKEX]: [...WRAPPED_NATIVE_ONLY[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.OKEX], _tokens__WEBPACK_IMPORTED_MODULE_0__/* .OKEX.DAI */ .Xn.DAI, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .OKEX.USDC */ .Xn.USDC, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .OKEX.USDT */ .Xn.USDT, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .OKEX.WBTC */ .Xn.WBTC, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .OKEX.WETH */ .Xn.WETH] // [ChainId.CELO]: [
  //   ...WRAPPED_NATIVE_ONLY[ChainId.CELO],
  //   CELO.mCUSD,
  //   CELO.mCELO,
  //   CELO.mcEURO,
  //   CELO.cEUR,
  // ],

});
const PINNED_PAIRS = {
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MAINNET]: [[_tokens__WEBPACK_IMPORTED_MODULE_0__/* .SUSHI */ .hs[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MAINNET], _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.WNATIVE[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MAINNET]], [new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MAINNET, '0x5d3a536E4D6DbD6114cc1Ead35777bAB948E3643', 8, 'cDAI', 'Compound Dai'), new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MAINNET, '0x39AA39c021dfbaE8faC545936693aC917d5E7563', 8, 'cUSDC', 'Compound USD Coin')], [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .USDC */ .gn, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .USDT */ .AA], [_tokens__WEBPACK_IMPORTED_MODULE_0__/* .DAI */ .h1, _tokens__WEBPACK_IMPORTED_MODULE_0__/* .USDT */ .AA]]
};

/***/ }),

/***/ 1818:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "US": function() { return /* binding */ UNSUPPORTED_LIST_URLS; },
/* harmony export */   "Lx": function() { return /* binding */ DEFAULT_LIST_OF_LISTS; },
/* harmony export */   "c8": function() { return /* binding */ DEFAULT_ACTIVE_LIST_URLS; }
/* harmony export */ });
/* unused harmony export OPTIMISM_LIST */
const BA_LIST = 'https://raw.githubusercontent.com/The-Blockchain-Association/sec-notice-list/master/ba-sec-list.json'; // used to mark unsupported tokens, these are hosted lists of unsupported tokens

/**
 * @TODO add list from blockchain association
 */

const UNSUPPORTED_LIST_URLS = [BA_LIST];
const YEARN_LIST = 'https://yearn.science/static/tokenlist.json';
const NFTX_LIST_V1 = 'https://nftx.ethereumdb.com/v1/tokenlist/';
const NFTX_LIST_V2 = 'https://nftx.ethereumdb.com/v2/tokenlist/';
const SYNTHETIX_LIST = 'synths.snx.eth';
const OPYN_LIST = 'https://raw.githubusercontent.com/opynfinance/opyn-tokenlist/master/opyn-v1.tokenlist.json';
const AAVE_LIST = 'tokenlist.aave.eth';
const CMC_ALL_LIST = 'defi.cmc.eth';
const CMC_STABLECOIN = 'stablecoin.cmc.eth';
const COINGECKO_LIST = 'https://tokens.coingecko.com/uniswap/all.json';
const COMPOUND_LIST = 'https://raw.githubusercontent.com/compound-finance/token-list/master/compound.tokenlist.json';
const GEMINI_LIST = 'https://www.gemini.com/uniswap/manifest.json';
const KLEROS_LIST = 't2crtokens.eth';
const OPTIMISM_LIST = 'https://static.optimism.io/optimism.tokenlist.json';
const ROLL_LIST = 'https://app.tryroll.com/tokens.json';
const SET_LIST = 'https://raw.githubusercontent.com/SetProtocol/uniswap-tokenlist/main/set.tokenlist.json';
const UMA_LIST = 'https://umaproject.org/uma.tokenlist.json';
const WRAPPED_LIST = 'wrapped.tokensoft.eth'; // lower index == higher priority for token import

const DEFAULT_LIST_OF_LISTS = [COMPOUND_LIST, AAVE_LIST, CMC_ALL_LIST, CMC_STABLECOIN, UMA_LIST, YEARN_LIST, SYNTHETIX_LIST, WRAPPED_LIST, SET_LIST, ROLL_LIST, COINGECKO_LIST, KLEROS_LIST, OPYN_LIST, NFTX_LIST_V1, NFTX_LIST_V2, OPTIMISM_LIST, GEMINI_LIST, ...UNSUPPORTED_LIST_URLS // need to load unsupported tokens as well
]; // default lists to be 'active' aka searched across

const DEFAULT_ACTIVE_LIST_URLS = [YEARN_LIST, GEMINI_LIST];

/***/ }),

/***/ 6540:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "T5": function() { return /* binding */ CELO; },
/* harmony export */   "Su": function() { return /* binding */ BSC; },
/* harmony export */   "of": function() { return /* binding */ FANTOM; },
/* harmony export */   "W3": function() { return /* binding */ MATIC; },
/* harmony export */   "Xn": function() { return /* binding */ OKEX; },
/* harmony export */   "rs": function() { return /* binding */ HECO; },
/* harmony export */   "_T": function() { return /* binding */ HARMONY; },
/* harmony export */   "AC": function() { return /* binding */ XDAI; },
/* harmony export */   "Qz": function() { return /* binding */ AVALANCHE; },
/* harmony export */   "Xe": function() { return /* binding */ ALPHA; },
/* harmony export */   "s5": function() { return /* binding */ AMPL; },
/* harmony export */   "_C": function() { return /* binding */ BAB; },
/* harmony export */   "mf": function() { return /* binding */ BAC; },
/* harmony export */   "rK": function() { return /* binding */ CREAM; },
/* harmony export */   "h1": function() { return /* binding */ DAI; },
/* harmony export */   "du": function() { return /* binding */ DOUGH; },
/* harmony export */   "IE": function() { return /* binding */ DUCK; },
/* harmony export */   "Lp": function() { return /* binding */ ETH2X_FLI; },
/* harmony export */   "sr": function() { return /* binding */ FEI; },
/* harmony export */   "BN": function() { return /* binding */ FRAX; },
/* harmony export */   "xn": function() { return /* binding */ FXS; },
/* harmony export */   "y7": function() { return /* binding */ HBTC; },
/* harmony export */   "yl": function() { return /* binding */ IBETH; },
/* harmony export */   "PY": function() { return /* binding */ MEOW; },
/* harmony export */   "Td": function() { return /* binding */ MIR; },
/* harmony export */   "lK": function() { return /* binding */ NFTX; },
/* harmony export */   "NH": function() { return /* binding */ PLAY; },
/* harmony export */   "YY": function() { return /* binding */ PONT; },
/* harmony export */   "Wg": function() { return /* binding */ PWING; },
/* harmony export */   "vS": function() { return /* binding */ RENBTC; },
/* harmony export */   "uj": function() { return /* binding */ RUNE; },
/* harmony export */   "_S": function() { return /* binding */ STETH; },
/* harmony export */   "em": function() { return /* binding */ TRIBE; },
/* harmony export */   "iD": function() { return /* binding */ UMA; },
/* harmony export */   "gn": function() { return /* binding */ USDC; },
/* harmony export */   "Es": function() { return /* binding */ USDP; },
/* harmony export */   "AA": function() { return /* binding */ USDT; },
/* harmony export */   "bi": function() { return /* binding */ UST; },
/* harmony export */   "ML": function() { return /* binding */ WBTC; },
/* harmony export */   "LL": function() { return /* binding */ XSUSHI; },
/* harmony export */   "t3": function() { return /* binding */ LIFT; },
/* harmony export */   "iI": function() { return /* binding */ LFBTC; },
/* harmony export */   "Wo": function() { return /* binding */ CVXCRV; },
/* harmony export */   "be": function() { return /* binding */ CRV; },
/* harmony export */   "hs": function() { return /* binding */ SUSHI; }
/* harmony export */ });
/* unused harmony exports UMA_CALL, XSUSHI_CALL, WETH9_EXTENDED, ExtendedEther */
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6766);
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _chains__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8809);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



const CELO = {
  mCUSD: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.CELO, '0x64dEFa3544c695db8c535D289d843a189aa26b98', 18, 'mCUSD', 'Moola cUSD'),
  mCELO: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.CELO, '0x7037F7296B2fc7908de7b57a89efaa8319f0C500', 18, 'mCELO', 'Moola CELO'),
  mcEURO: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.CELO, '0xa8d0E6799FF3Fd19c6459bf02689aE09c4d78Ba7', 18, 'mCEUR', 'Moola Celo Euro'),
  cUSD: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.CELO, '0x765DE816845861e75A25fCA122bb6898B8B1282a', 18, 'cUSD', 'Celo Dollar'),
  cEURO: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.CELO, '0xD8763CBa276a3738E6DE85b4b3bF5FDed6D6cA73', 18, 'cEUR', 'Celo Euro'),
  cBTC: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.CELO, '0xD629eb00dEced2a080B7EC630eF6aC117e614f1b', 18, 'cBTC', 'Wrapped Bitcoin')
};
const BSC = {
  DAI: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.BSC, '0x1AF3F329e8BE154074D8769D1FFa4eE058B1DBc3', 18, 'DAI', 'Dai Stablecoin'),
  USD: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.BSC, '0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56', 18, 'BUSD', 'Binance USD'),
  USDC: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.BSC, '0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d', 18, 'USDC', 'USD Coin'),
  USDT: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.BSC, '0x55d398326f99059fF775485246999027B3197955', 18, 'USDT', 'Tether USD'),
  BTCB: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.BSC, '0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c', 18, 'BTCB', 'Bitcoin'),
  WETH: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.BSC, '0x2170Ed0880ac9A755fd29B2688956BD959F933F8', 18, 'WETH', 'Wrapped Ether')
};
const FANTOM = {
  USDC: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.FANTOM, '0x04068DA6C83AFCFA0e13ba15A6696662335D5B75', 6, 'USDC', 'USD Coin'),
  WBTC: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.FANTOM, '0x321162Cd933E2Be498Cd2267a90534A804051b11', 8, 'WBTC', 'Wrapped Bitcoin'),
  DAI: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.FANTOM, '0x8D11eC38a3EB5E956B052f67Da8Bdc9bef8Abf3E', 18, 'DAI', 'Dai Stablecoin'),
  WETH: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.FANTOM, '0x74b23882a30290451A17c44f4F05243b6b58C76d', 18, 'WETH', 'Wrapped Ether')
};
const MATIC = {
  USDC: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC, '0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174', 6, 'USDC', 'USD Coin'),
  WBTC: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC, '0x1BFD67037B42Cf73acF2047067bd4F2C47D9BfD6', 8, 'WBTC', 'Wrapped Bitcoin'),
  DAI: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC, '0x8f3Cf7ad23Cd3CaDbD9735AFf958023239c6A063', 18, 'DAI', 'Dai Stablecoin'),
  WETH: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC, '0x7ceB23fD6bC0adD59E62ac25578270cFf1b9f619', 18, 'WETH', 'Wrapped Ether'),
  USDT: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC, '0xc2132D05D31c914a87C6611C10748AEb04B58e8F', 6, 'USDT', 'Tether USD'),
  TEL: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC, '0xdF7837DE1F2Fa4631D716CF2502f8b230F1dcc32', 2, 'TEL', 'Telcoin'),
  SUSHI: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC, '0x0b3F868E0BE5597D5DB7fEB59E1CADBb0fdDa50a', 18, 'SUSHI', 'SushiToken'),
  AAVE: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC, '0xD6DF932A45C0f255f85145f286eA0b292B21C90B', 18, 'AAVE', 'Aave'),
  FRAX: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC, '0x104592a158490a9228070E0A8e5343B499e125D0', 18, 'FRAX', 'Frax'),
  FXS: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC, '0x3e121107F6F22DA4911079845a470757aF4e1A1b', 18, 'FXS', 'Frax Share'),
  DMAGIC: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC, '0x61dAECaB65EE2A1D5b6032df030f3fAA3d116Aa7', 18, 'DMAGIC', 'Dark Magic'),
  DRAX: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC, '0x1Ba3510A9ceEb72E5CdBa8bcdDe9647E1f20fB4b', 18, 'DRAX', 'Drax')
};
const OKEX = {
  DAI: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.OKEX, '0x21cDE7E32a6CAF4742d00d44B07279e7596d26B9', 18, 'DAI', 'Dai Stablecoin'),
  USDC: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.OKEX, '0xc946DAf81b08146B1C7A8Da2A851Ddf2B3EAaf85', 18, 'USDC', 'USD Coin'),
  USDT: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.OKEX, '0x382bB369d343125BfB2117af9c149795C6C65C50', 18, 'USDT', 'Tether USD'),
  WBTC: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.OKEX, '0x506f731F7656e2FB34b587B912808f2a7aB640BD', 18, 'WBTC', 'Wrapped Bitcoin'),
  WETH: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.OKEX, '0xEF71CA2EE68F45B9Ad6F72fbdb33d707b872315C', 18, 'WETH', 'Wrapped Ether')
};
const HECO = {
  DAI: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HECO, '0x3D760a45D0887DFD89A2F5385a236B29Cb46ED2a', 18, 'DAI', 'Dai Stablecoin'),
  USDC: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HECO, '0x9362Bbef4B8313A8Aa9f0c9808B80577Aa26B73B', 18, 'USDC', 'USD Coin'),
  USDT: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HECO, '0xa71EdC38d189767582C38A3145b5873052c3e47a', 18, 'USDT', 'Tether USD'),
  WBTC: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HECO, '0x66a79D23E58475D2738179Ca52cd0b41d73f0BEa', 18, 'WBTC', 'Wrapped Bitcoin'),
  WETH: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HECO, '0x64FF637fB478863B7468bc97D30a5bF3A428a1fD', 18, 'WETH', 'Wrapped Ether')
};
const HARMONY = {
  DAI: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HARMONY, '0xEf977d2f931C1978Db5F6747666fa1eACB0d0339', 18, 'DAI', 'Dai Stablecoin'),
  USDC: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HARMONY, '0x985458E523dB3d53125813eD68c274899e9DfAb4', 6, 'USDC', 'USD Coin'),
  USDT: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HARMONY, '0x3C2B8Be99c50593081EAA2A724F0B8285F5aba8f', 6, 'USDT', 'Tether USD'),
  WBTC: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HARMONY, '0x3095c7557bCb296ccc6e363DE01b760bA031F2d9', 8, 'WBTC', 'Wrapped Bitcoin'),
  WETH: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HARMONY, '0x6983D1E6DEf3690C4d616b13597A09e6193EA013', 18, 'WETH', 'Wrapped Ether')
};
const XDAI = {
  USDC: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.XDAI, '0xDDAfbb505ad214D7b80b1f830fcCc89B60fb7A83', 6, 'USDC', 'USD Coin'),
  USDT: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.XDAI, '0x4ECaBa5870353805a9F068101A40E0f32ed605C6', 6, 'USDT', 'Tether USD'),
  WBTC: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.XDAI, '0x8e5bBbb09Ed1ebdE8674Cda39A0c169401db4252', 8, 'WBTC', 'Wrapped Bitcoin'),
  WETH: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.XDAI, '0x6A023CCd1ff6F2045C3309768eAd9E68F978f6e1', 18, 'WETH', 'Wrapped Ether')
};
const AVALANCHE = {
  DAI: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.AVALANCHE, '0xbA7dEebBFC5fA1100Fb055a87773e1E99Cd3507a', 18, 'DAI', 'Dai Stablecoin'),
  USDT: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.AVALANCHE, '0xde3A24028580884448a5397872046a019649b084', 6, 'USDT', 'Tether USD'),
  WBTC: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.AVALANCHE, '0x408D4cD0ADb7ceBd1F1A1C33A0Ba2098E1295bAB', 8, 'WBTC', 'Wrapped Bitcoin'),
  WETH: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.AVALANCHE, '0xf20d962a6c8f70c731bd838a3a388D7d48fA6e15', 18, 'WETH', 'Wrapped Ether')
}; // Default Ethereum chain tokens

const ALPHA = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0xa1faa113cbE53436Df28FF0aEe54275c13B40975', 18, 'ALPHA', 'AlphaToken');
const AMPL = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0xD46bA6D942050d489DBd938a2C909A5d5039A161', 9, 'AMPL', 'Ampleforth');
const BAB = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0xC36824905dfF2eAAEE7EcC09fCC63abc0af5Abc5', 18, 'BAB', 'BAB');
const BAC = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0x3449FC1Cd036255BA1EB19d65fF4BA2b8903A69a', 18, 'BAC', 'Basis Cash');
const CREAM = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0x2ba592F78dB6436527729929AAf6c908497cB200', 18, 'CREAM', 'Cream');
const DAI = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0x6B175474E89094C44Da98b954EedeAC495271d0F', 18, 'DAI', 'Dai Stablecoin');
const DOUGH = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0xad32A8e6220741182940c5aBF610bDE99E737b2D', 18, 'DOUGH', 'PieDAO Dough v2');
const DUCK = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0x92E187a03B6CD19CB6AF293ba17F2745Fd2357D5', 18, 'DUCK', 'DUCK');
const ETH2X_FLI = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0xAa6E8127831c9DE45ae56bB1b0d4D4Da6e5665BD', 18, 'ETH2x-FLI', 'ETH 2x Flexible Leverage Index');
const FEI = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0x956F47F50A910163D8BF957Cf5846D573E7f87CA', 18, 'FEI', 'Fei USD');
const FRAX = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0x853d955aCEf822Db058eb8505911ED77F175b99e', 18, 'FRAX', 'FRAX');
const FXS = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0x3432B6A60D23Ca0dFCa7761B7ab56459D9C964D0', 18, 'FXS', 'Frax Share');
const HBTC = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0x0316EB71485b0Ab14103307bf65a021042c6d380', 18, 'HBTC', 'Huobi BTC');
const IBETH = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0xeEa3311250FE4c3268F8E684f7C87A82fF183Ec1', 8, 'ibETHv2', 'Interest Bearing Ether v2');
const MEOW = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0x650F44eD6F1FE0E1417cb4b3115d52494B4D9b6D', 18, 'MEOW', 'Meowshi');
const MIR = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0x09a3EcAFa817268f77BE1283176B946C4ff2E608', 18, 'MIR', 'Wrapped MIR');
const NFTX = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0x87d73E916D7057945c9BcD8cdd94e42A6F47f776', 18, 'NFTX', 'NFTX');
const PLAY = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0x33e18a092a93ff21aD04746c7Da12e35D34DC7C4', 18, 'PLAY', 'Metaverse NFT Index');
const PONT = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0xcb46C550539ac3DB72dc7aF7c89B11c306C727c2', 9, 'pONT', 'Poly Ontology Token');
const PWING = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0xDb0f18081b505A7DE20B18ac41856BCB4Ba86A1a', 9, 'pWING', 'Poly Ontology Wing Token');
const RENBTC = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(1, '0xEB4C2781e4ebA804CE9a9803C67d0893436bB27D', 8, 'renBTC', 'renBTC');
const RUNE = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0x3155BA85D5F96b2d030a4966AF206230e46849cb', 18, 'RUNE', 'RUNE.ETH');
const STETH = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0xDFe66B14D37C77F4E9b180cEb433d1b164f0281D', 18, 'stETH', 'stakedETH');
const TRIBE = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0xc7283b66Eb1EB5FB86327f08e1B5816b0720212B', 18, 'TRIBE', 'Tribe');
const UMA = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0x04Fa0d235C4abf4BcF4787aF4CF447DE572eF828', 18, 'UMA', 'UMA');
const UMA_CALL = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0x1062aD0E59fa67fa0b27369113098cC941Dd0D5F', 18, 'UMA', 'UMA 35 Call [30 Apr 2021]');
const USDC = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48', 6, 'USDC', 'USD Coin');
const USDP = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0x1456688345527bE1f37E9e627DA0837D6f08C925', 18, 'USDP', 'USDP Stablecoin');
const USDT = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0xdAC17F958D2ee523a2206206994597C13D831ec7', 6, 'USDT', 'Tether USD');
const UST = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0xa47c8bf37f92aBed4A126BDA807A7b7498661acD', 18, 'UST', 'Wrapped UST');
const XSUSHI_CALL = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0xada279f9301C01A4eF914127a6C2a493Ad733924', 18, 'XSUc25-0531', 'XSUSHI 25 Call [31 May 2021]');
const WBTC = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599', 8, 'WBTC', 'Wrapped BTC');
const XSUSHI = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0x8798249c2E607446EfB7Ad49eC89dD1865Ff4272', 18, 'xSUSHI', 'SushiBar');
const LIFT = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0xf9209d900f7ad1DC45376a2caA61c78f6dEA53B6', 18, 'LIFT', 'LiftKitchen');
const LFBTC = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0xafcE9B78D409bF74980CACF610AFB851BF02F257', 18, 'LFBTC', 'LiftKitchen BTC');
const CVXCRV = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0x62B9c7356A2Dc64a1969e19C23e4f579F9810Aa7', 18, 'cvxCRV', 'cvxCRV');
const CRV = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, '0xD533a949740bb3306d119CC777fa900bA034cd52', 18, 'CRV', 'Curve');
// SUSHI
const SUSHI = {
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET]: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.SUSHI_ADDRESS[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET], 18, 'SUSHI', 'SushiToken'),
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.ROPSTEN]: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.ROPSTEN, _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.SUSHI_ADDRESS[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.ROPSTEN], 18, 'SUSHI', 'SushiToken'),
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.RINKEBY]: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.RINKEBY, _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.SUSHI_ADDRESS[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.RINKEBY], 18, 'SUSHI', 'SushiToken'),
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId["GÖRLI"]]: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId["GÖRLI"], _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.SUSHI_ADDRESS[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId["GÖRLI"]], 18, 'SUSHI', 'SushiToken'),
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.KOVAN]: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.KOVAN, _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.SUSHI_ADDRESS[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.KOVAN], 18, 'SUSHI', 'SushiToken'),
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC]: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC, _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.SUSHI_ADDRESS[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC], 18, 'SUSHI', 'SushiToken'),
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.FANTOM]: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.FANTOM, _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.SUSHI_ADDRESS[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.FANTOM], 18, 'SUSHI', 'SushiToken'),
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.XDAI]: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.XDAI, _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.SUSHI_ADDRESS[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.XDAI], 18, 'SUSHI', 'SushiToken'),
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.BSC]: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.BSC, _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.SUSHI_ADDRESS[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.BSC], 18, 'SUSHI', 'SushiToken'),
  // [ChainId.ARBITRUM]: new Token(ChainId.ARBITRUM, SUSHI_ADDRESS[ChainId.ARBITRUM], 18, 'SUSHI', 'SushiToken'),
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.AVALANCHE]: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.AVALANCHE, _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.SUSHI_ADDRESS[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.AVALANCHE], 18, 'SUSHI', 'SushiToken'),
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.OKEX]: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.OKEX, _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.SUSHI_ADDRESS[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.OKEX], 18, 'SUSHI', 'SushiToken'),
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HARMONY]: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HARMONY, _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.SUSHI_ADDRESS[_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HARMONY], 18, 'SUSHI', 'SushiToken') // [ChainId.HECO]: new Token(ChainId.HECO, SUSHI_ADDRESS[ChainId.HECO], 18, 'SUSHI', 'SushiToken'),

};
const WETH9_EXTENDED = _objectSpread(_objectSpread({}, _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.WETH9), {}, {
  [_chains__WEBPACK_IMPORTED_MODULE_1__/* .SupportedChainId.ARBITRUM_TESTNET */ .H.ARBITRUM_TESTNET]: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.ARBITRUM_TESTNET, '0x4A5e4A42dC430f669086b417AADf2B128beFEfac', 18, 'WETH9', 'Wrapped Ether'),
  [_chains__WEBPACK_IMPORTED_MODULE_1__/* .SupportedChainId.ARBITRUM */ .H.ARBITRUM]: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.ARBITRUM, '0x82aF49447D8a07e3bd95BD0d56f35241523fBab1', 18, 'WETH', 'Wrapped Ether'),
  [_chains__WEBPACK_IMPORTED_MODULE_1__/* .SupportedChainId.FANTOM */ .H.FANTOM]: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.FANTOM, '0x21be370D5312f44cB42ce377BC9b8a0cEF1A4C83', 18, 'WFTM', 'Wrapped Fantom') // [SupportedChainId.CELO]: new Token(
  //   SupportedChainId.CELO,
  //   "0x471EcE3750Da237f93B8E339c536989b8978a438",
  //   18,
  //   "CELO",
  //   "Celo"
  // ),

});
class ExtendedEther extends (/* unused pure expression or super */ null && (Ether)) {
  get wrapped() {
    // if (this.chainId in WNATIVE) return WNATIVE[this.chainId]
    if (this.chainId in WETH9_EXTENDED) return WETH9_EXTENDED[this.chainId];
    throw new Error('Unsupported chain ID');
  }

  static onChain(chainId) {
    return new ExtendedEther(chainId);
  }

} // export class ExtendedCelo extends Celo {
//   public get wrapped(): Token {
//     if (this.chainId in WNATIVE) return WNATIVE[this.chainId];
//     throw new Error("Unsupported chain ID");
//   }
//   public static onChain(chainId: number): ExtendedCelo {
//     return new ExtendedCelo(chainId);
//   }
// }

/***/ }),

/***/ 663:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "uN": function() { return /* binding */ getContract; },
  "TY": function() { return /* binding */ getProviderOrSigner; },
  "TC": function() { return /* binding */ getSigner; }
});

// UNUSED EXPORTS: getArcherRouterContract, getRouterAddress, getRouterContract

// EXTERNAL MODULE: external "@sushiswap/sdk"
var sdk_ = __webpack_require__(6766);
// EXTERNAL MODULE: ./src/constants/index.ts
var constants = __webpack_require__(8532);
// EXTERNAL MODULE: external "@ethersproject/constants"
var constants_ = __webpack_require__(6148);
// EXTERNAL MODULE: ./src/constants/abis/archer-router.json
var archer_router = __webpack_require__(1955);
// EXTERNAL MODULE: external "@ethersproject/contracts"
var contracts_ = __webpack_require__(4440);
;// CONCATENATED MODULE: ./src/constants/abis/uniswap-v2-router-02.json
var uniswap_v2_router_02_namespaceObject = [];
;// CONCATENATED MODULE: ./src/constants/abis/uniswap-v2-router-02-no-eth.json
var uniswap_v2_router_02_no_eth_namespaceObject = [];
// EXTERNAL MODULE: ./src/functions/validate.ts
var validate = __webpack_require__(2556);
;// CONCATENATED MODULE: ./src/functions/contract.ts
// NOTE: Try not to add anything to thie file, it's almost entirely refactored out.







 // account is not optional

function getSigner(library, account) {
  return library.getSigner(account).connectUnchecked();
} // account is optional

function getProviderOrSigner(library, account) {
  return account ? getSigner(library, account) : library;
} // account is optional

function getContract(address, ABI, library, account) {
  if (!(0,validate/* isAddress */.UJ)(address) || address === constants_.AddressZero) {
    throw Error(`Invalid 'address' parameter '${address}'.`);
  }

  return new contracts_.Contract(address, ABI, getProviderOrSigner(library, account));
}
function getRouterAddress(chainId) {
  if (!chainId) {
    throw Error(`Undefined 'chainId' parameter '${chainId}'.`);
  }

  return ROUTER_ADDRESS[chainId];
} // account is optional

function getRouterContract(chainId, library, account) {
  return getContract(getRouterAddress(chainId), chainId !== ChainId.CELO ? IUniswapV2Router02ABI : IUniswapV2Router02NoETHABI, library, account);
}
function getArcherRouterContract(chainId, library, account) {
  var _ARCHER_ROUTER_ADDRES;

  return getContract((_ARCHER_ROUTER_ADDRES = ARCHER_ROUTER_ADDRESS[chainId]) !== null && _ARCHER_ROUTER_ADDRES !== void 0 ? _ARCHER_ROUTER_ADDRES : '', ArcherSwapRouterABI, library, account);
}

/***/ }),

/***/ 7025:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "il": function() { return /* reexport */ contenthashToUri; },
  "ie": function() { return /* reexport */ uriToHttp; }
});

// UNUSED EXPORTS: basisPointsToPercent

// EXTERNAL MODULE: external "@sushiswap/sdk"
var sdk_ = __webpack_require__(6766);
;// CONCATENATED MODULE: ./src/functions/convert/basisPointsToPercent.ts
 // converts a basis points value to a sdk percent

function basisPointsToPercent(num) {
  return new Percent(JSBI.BigInt(num), JSBI.BigInt(10000));
}
// EXTERNAL MODULE: external "multihashes"
var external_multihashes_ = __webpack_require__(6841);
// EXTERNAL MODULE: external "multicodec"
var external_multicodec_ = __webpack_require__(1980);
// EXTERNAL MODULE: external "cids"
var external_cids_ = __webpack_require__(4588);
var external_cids_default = /*#__PURE__*/__webpack_require__.n(external_cids_);
;// CONCATENATED MODULE: ./src/functions/convert/contenthashToUri.ts



function hexToUint8Array(hex) {
  hex = hex.startsWith('0x') ? hex.substr(2) : hex;
  if (hex.length % 2 !== 0) throw new Error('hex must have length that is multiple of 2');
  const arr = new Uint8Array(hex.length / 2);

  for (let i = 0; i < arr.length; i++) {
    arr[i] = parseInt(hex.substr(i * 2, 2), 16);
  }

  return arr;
}
const UTF_8_DECODER = new TextDecoder();
/**
 * Returns the URI representation of the content hash for supported codecs
 * @param contenthash to decode
 */

function contenthashToUri(contenthash) {
  const buff = hexToUint8Array(contenthash);
  const codec = (0,external_multicodec_.getCodec)(buff); // the typing is wrong for @types/multicodec

  switch (codec) {
    case 'ipfs-ns':
      {
        const data = (0,external_multicodec_.rmPrefix)(buff);
        const cid = new (external_cids_default())(data);
        return `ipfs://${(0,external_multihashes_.toB58String)(cid.multihash)}`;
      }

    case 'ipns-ns':
      {
        const data = (0,external_multicodec_.rmPrefix)(buff);
        const cid = new (external_cids_default())(data);
        const multihash = (0,external_multihashes_.decode)(cid.multihash);

        if (multihash.name === 'identity') {
          return `ipns://${UTF_8_DECODER.decode(multihash.digest).trim()}`;
        } else {
          return `ipns://${(0,external_multihashes_.toB58String)(cid.multihash)}`;
        }
      }

    default:
      throw new Error(`Unrecognized codec: ${codec}`);
  }
}
;// CONCATENATED MODULE: ./src/functions/convert/uriToHttp.ts
/**
 * Given a URI that may be ipfs, ipns, http, or https protocol, return the fetch-able http(s) URLs for the same content
 * @param uri to convert to fetch-able http url
 */
function uriToHttp(uri) {
  var _uri$match, _uri$match2;

  const protocol = uri.split(':')[0].toLowerCase();

  switch (protocol) {
    case 'https':
      return [uri];

    case 'http':
      return ['https' + uri.substr(4), uri];

    case 'ipfs':
      const hash = (_uri$match = uri.match(/^ipfs:(\/\/)?(.*)$/i)) === null || _uri$match === void 0 ? void 0 : _uri$match[2];
      return [`https://cloudflare-ipfs.com/ipfs/${hash}/`, `https://ipfs.io/ipfs/${hash}/`];

    case 'ipns':
      const name = (_uri$match2 = uri.match(/^ipns:(\/\/)?(.*)$/i)) === null || _uri$match2 === void 0 ? void 0 : _uri$match2[2];
      return [`https://cloudflare-ipfs.com/ipns/${name}/`, `https://ipfs.io/ipns/${name}/`];

    default:
      return [];
  }
}
;// CONCATENATED MODULE: ./src/functions/convert/index.ts




/***/ }),

/***/ 5612:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "H": function() { return /* binding */ currencyId; }
/* harmony export */ });
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6766);
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__);

function currencyId(currency) {
  if ([_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.CELO].includes(currency.chainId)) {
    return currency.wrapped.address;
  }

  if (currency.isNative) return 'ETH';
  if (currency.isToken) return currency.address;
  throw new Error('invalid currency');
} // export function currencyId(
//   currency: Currency,
//   chainId = ChainId.MAINNET
// ): string {
//   if (currency === Currency.getNativeCurrency(chainId))
//     return Currency.getNativeCurrencySymbol(chainId);
//   if (currency instanceof Token) return currency.address;
//   throw new Error("invalid currency");
// }

/***/ }),

/***/ 1368:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "z": function() { return /* binding */ getCurrency; }
/* harmony export */ });
/* unused harmony export USD_CURRENCY */
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6766);
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var ethers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4879);
/* harmony import */ var ethers__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(ethers__WEBPACK_IMPORTED_MODULE_1__);


// Pricing currency
// TODO: Check decimals and finish table
const USD_CURRENCY = {
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET]: {
    address: '0xdAC17F958D2ee523a2206206994597C13D831ec7',
    decimals: 6
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.ROPSTEN]: {
    address: '0x516de3a7A567d81737e3a46ec4FF9cFD1fcb0136',
    decimals: 6
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.KOVAN]: {
    address: '0x07de306FF27a2B630B1141956844eB1552B956B5',
    decimals: 6
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.RINKEBY]: {
    address: '0xD9BA894E0097f8cC2BBc9D24D308b98e36dc6D02',
    decimals: 6
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId["GÖRLI"]]: {
    address: '0xD87Ba7A50B2E7E660f678A895E4B72E7CB4CCd9C',
    decimals: 6
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.BSC]: {
    address: '0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56',
    decimals: 18
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.BSC_TESTNET]: {
    address: '0x337610d27c682E347C9cD60BD4b3b107C9d34dDd',
    decimals: 18
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HECO]: {
    address: '0x0298c2b32eaE4da002a15f36fdf7615BEa3DA047',
    decimals: 8
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HECO_TESTNET]: {
    address: '',
    decimals: 6
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC]: {
    address: '0xc2132D05D31c914a87C6611C10748AEb04B58e8F',
    decimals: 6
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC_TESTNET]: {
    address: '',
    decimals: 6
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.XDAI]: {
    address: '',
    decimals: 6
  }
};
function getCurrency(chainId) {
  return USD_CURRENCY[chainId || 1] || {
    address: ethers__WEBPACK_IMPORTED_MODULE_1__.ethers.constants.AddressZero,
    decimals: 18
  };
}

/***/ }),

/***/ 6081:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Hh": function() { return /* reexport safe */ _currencyId__WEBPACK_IMPORTED_MODULE_0__.H; },
/* harmony export */   "Bv": function() { return /* reexport safe */ _wrappedCurrency__WEBPACK_IMPORTED_MODULE_2__.B; },
/* harmony export */   "iN": function() { return /* reexport safe */ _maxAmountSpend__WEBPACK_IMPORTED_MODULE_3__.i; }
/* harmony export */ });
/* harmony import */ var _currencyId__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5612);
/* harmony import */ var _getCurrency__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1368);
/* harmony import */ var _wrappedCurrency__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9748);
/* harmony import */ var _maxAmountSpend__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2520);





/***/ }),

/***/ 2520:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "i": function() { return /* binding */ maxAmountSpend; }
/* harmony export */ });
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6766);
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__);

const MIN_NATIVE_CURRENCY_FOR_GAS = _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.exponentiate(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(10), _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(16)); // .01 ETH

/**
 * Given some token amount, return the max that can be spent of it
 * @param currencyAmount to return max of
 */

function maxAmountSpend(currencyAmount) {
  if (!currencyAmount) return undefined;

  if (currencyAmount.currency.isNative) {
    if (_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.greaterThan(currencyAmount.quotient, MIN_NATIVE_CURRENCY_FOR_GAS)) {
      return _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.CurrencyAmount.fromRawAmount(currencyAmount.currency, _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.subtract(currencyAmount.quotient, MIN_NATIVE_CURRENCY_FOR_GAS));
    } else {
      return _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.CurrencyAmount.fromRawAmount(currencyAmount.currency, _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(0));
    }
  }

  return currencyAmount;
}

/***/ }),

/***/ 9748:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "B": function() { return /* binding */ unwrappedToken; }
});

// EXTERNAL MODULE: external "@sushiswap/sdk"
var sdk_ = __webpack_require__(6766);
// EXTERNAL MODULE: ./src/constants/chains.ts
var chains = __webpack_require__(8809);
;// CONCATENATED MODULE: ./src/functions/chain.ts

/**
 * Returns the input chain ID if chain is supported. If not, return undefined
 * @param chainId a chain ID, which will be returned if it is a supported chain ID
 */

function supportedChainId(chainId) {
  if (chainId in chains/* SupportedChainId */.H) {
    return chainId;
  }

  return undefined;
}
;// CONCATENATED MODULE: ./src/functions/currency/wrappedCurrency.ts


function unwrappedToken(currency) {
  if (currency.isNative) return currency;
  const formattedChainId = supportedChainId(currency.chainId); // if (formattedChainId && currency.equals(WETH9_EXTENDED[formattedChainId]))
  //   return ExtendedEther.onChain(currency.chainId)

  if (formattedChainId && currency.equals(sdk_.WNATIVE[formattedChainId])) return sdk_.NATIVE[currency.chainId];
  return currency;
}

/***/ }),

/***/ 1302:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "N": function() { return /* binding */ resolveENSContentHash; },
/* harmony export */   "y": function() { return /* binding */ parseENSAddress; }
/* harmony export */ });
/* harmony import */ var _ethersproject_contracts__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4440);
/* harmony import */ var _ethersproject_contracts__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_contracts__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var ethers_lib_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1674);
/* harmony import */ var ethers_lib_utils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(ethers_lib_utils__WEBPACK_IMPORTED_MODULE_1__);


const REGISTRAR_ABI = [{
  constant: true,
  inputs: [{
    name: 'node',
    type: 'bytes32'
  }],
  name: 'resolver',
  outputs: [{
    name: 'resolverAddress',
    type: 'address'
  }],
  payable: false,
  stateMutability: 'view',
  type: 'function'
}];
const REGISTRAR_ADDRESS = '0x00000000000C2E074eC69A0dFb2997BA6C7d2e1e';
const RESOLVER_ABI = [{
  constant: true,
  inputs: [{
    internalType: 'bytes32',
    name: 'node',
    type: 'bytes32'
  }],
  name: 'contenthash',
  outputs: [{
    internalType: 'bytes',
    name: '',
    type: 'bytes'
  }],
  payable: false,
  stateMutability: 'view',
  type: 'function'
}]; // cache the resolver contracts since most of them are the public resolver

function resolverContract(resolverAddress, provider) {
  return new _ethersproject_contracts__WEBPACK_IMPORTED_MODULE_0__.Contract(resolverAddress, RESOLVER_ABI, provider);
}
/**
 * Fetches and decodes the result of an ENS contenthash lookup on mainnet to a URI
 * @param ensName to resolve
 * @param provider provider to use to fetch the data
 */


async function resolveENSContentHash(ensName, provider) {
  const ensRegistrarContract = new _ethersproject_contracts__WEBPACK_IMPORTED_MODULE_0__.Contract(REGISTRAR_ADDRESS, REGISTRAR_ABI, provider);
  const hash = (0,ethers_lib_utils__WEBPACK_IMPORTED_MODULE_1__.namehash)(ensName);
  const resolverAddress = await ensRegistrarContract.resolver(hash);
  return resolverContract(resolverAddress, provider).contenthash(hash);
}
const ENS_NAME_REGEX = /^(([a-zA-Z0-9]+(-[a-zA-Z0-9]+)*\.)+)eth(\/.*)?$/;
function parseENSAddress(ensAddress) {
  const match = ensAddress.match(ENS_NAME_REGEX);
  if (!match) return undefined;
  return {
    ensName: `${match[1].toLowerCase()}eth`,
    ensPath: match[4]
  };
}

/***/ }),

/***/ 8277:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Xn": function() { return /* binding */ shortenAddress; },
/* harmony export */   "T3": function() { return /* binding */ formatPercent; },
/* harmony export */   "uf": function() { return /* binding */ formatNumber; },
/* harmony export */   "nH": function() { return /* binding */ formatNumberScale; },
/* harmony export */   "hr": function() { return /* binding */ escapeRegExp; },
/* harmony export */   "az": function() { return /* binding */ formatBalance; },
/* harmony export */   "ZO": function() { return /* binding */ formatCurrencyAmount; },
/* harmony export */   "s4": function() { return /* binding */ formatDateAgo; }
/* harmony export */ });
/* unused harmony exports capitalize, formatK, shortenString, formatPrice */
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6766);
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var numeral__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3756);
/* harmony import */ var numeral__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(numeral__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var ethers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4879);
/* harmony import */ var ethers__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(ethers__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _ethersproject_address__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7398);
/* harmony import */ var _ethersproject_address__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_address__WEBPACK_IMPORTED_MODULE_3__);
// CONVENTION formatFoo -> string




const capitalize = s => {
  if (typeof s !== 'string') return '';
  return s.charAt(0).toUpperCase() + s.slice(1);
};
const formatK = value => {
  return numeral__WEBPACK_IMPORTED_MODULE_1___default()(value).format('0.[00]a');
}; // shorten the checksummed version of the input address to have 0x + 4 characters at start and end

function shortenAddress(address, chars = 4) {
  try {
    const parsed = (0,_ethersproject_address__WEBPACK_IMPORTED_MODULE_3__.getAddress)(address);
    return `${parsed.substring(0, chars + 2)}...${parsed.substring(42 - chars)}`;
  } catch (error) {
    throw Error(`Invalid 'address' parameter '${address}'.`);
  }
} // shorten string to its maximum length using three dots

function shortenString(string, length) {
  if (!string) return '';
  if (length < 5) return string;
  if (string.length <= length) return string;
  return string.slice(0, 4) + '...' + string.slice(string.length - length + 5, string.length);
} // using a currency library here in case we want to add more in future

const priceFormatter = new Intl.NumberFormat('en-US', {
  style: 'currency',
  currency: 'USD',
  minimumFractionDigits: 2
});
function formatPercent(percentString) {
  const percent = parseFloat(percentString);

  if (!percent || percent === Infinity || percent === 0) {
    return '0%';
  }

  if (percent < 0.0001 && percent > 0) {
    return '< 0.0001%';
  }

  if (percent < 0 && percent > -0.0001) {
    return '< 0.0001%';
  }

  const fixedPercent = percent.toFixed(2);

  if (fixedPercent === '0.00') {
    return '0%';
  }

  if (Number(fixedPercent) > 0) {
    if (Number(fixedPercent) > 100) {
      return `${percent === null || percent === void 0 ? void 0 : percent.toFixed(0).toLocaleString()}%`;
    } else {
      return `${fixedPercent}%`;
    }
  } else {
    return `${fixedPercent}%`;
  }
}
const formatNumber = (number, usd = false, scale = true) => {
  if (isNaN(number) || number === '' || number === undefined) {
    return usd ? '$0.00' : '0';
  }

  const num = parseFloat(number);

  if (num > 500000000 && scale) {
    return (usd ? '$' : '') + formatK(num.toFixed(0));
  }

  if (num === 0) {
    if (usd) {
      return '$0.00';
    }

    return '0';
  }

  if (num < 0.0001 && num > 0) {
    return usd ? '< $0.0001' : '< 0.0001';
  }

  if (num > 1000) {
    return usd ? '$' + Number(parseFloat(String(num)).toFixed(0)).toLocaleString() : '' + Number(parseFloat(String(num)).toFixed(0)).toLocaleString();
  }

  if (usd) {
    if (num < 0.1) {
      return '$' + Number(parseFloat(String(num)).toFixed(4));
    } else {
      const usdString = priceFormatter.format(num);
      return '$' + usdString.slice(1, usdString.length);
    }
  }

  return parseFloat(String(num)).toPrecision(4);
};
function formatNumberScale(number, usd = false) {
  if (isNaN(number) || number === '' || number === undefined) {
    return usd ? '$0.00' : '0';
  }

  const num = parseFloat(number);
  const wholeNumberLength = String(Math.floor(num)).length;
  if (wholeNumberLength >= 13) return (usd ? '$' : '') + (num / Math.pow(10, 12)).toFixed(1) + 'T';
  if (wholeNumberLength >= 10) return (usd ? '$' : '') + (num / Math.pow(10, 9)).toFixed(1) + 'B';
  if (wholeNumberLength >= 7) return (usd ? '$' : '') + (num / Math.pow(10, 6)).toFixed(1) + 'M';
  if (wholeNumberLength >= 4) return (usd ? '$' : '') + (num / Math.pow(10, 3)).toFixed(1) + 'K';

  if (num < 0.0001 && num > 0) {
    return usd ? '< $0.0001' : '< 0.0001';
  }

  return (usd ? '$' : '') + num.toFixed(2);
}
function escapeRegExp(string) {
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); // $& means the whole matched string
}
const formatBalance = (value, decimals = 18, maxFraction = 0) => {
  const formatted = ethers__WEBPACK_IMPORTED_MODULE_2__.ethers.utils.formatUnits(value, decimals);

  if (maxFraction > 0) {
    const split = formatted.split('.');

    if (split.length > 1) {
      return split[0] + '.' + split[1].substr(0, maxFraction);
    }
  }

  return formatted;
};
function formatCurrencyAmount(amount, sigFigs) {
  if (!amount) {
    return '-';
  }

  if (_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.equal(amount.quotient, _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(0))) {
    return '0';
  }

  if (amount.divide(amount.decimalScale).lessThan(new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Fraction(1, 100000))) {
    return '<0.00001';
  }

  return amount.toSignificant(sigFigs);
}
function formatPrice(price, sigFigs) {
  if (!price) {
    return '-';
  }

  if (parseFloat(price.toFixed(sigFigs)) < 0.0001) {
    return '<0.0001';
  }

  return price.toSignificant(sigFigs);
}
function formatDateAgo(date) {
  const currentDate = new Date();
  const secondsAgo = Math.floor((currentDate.getTime() - date.getTime()) / 1000);
  if (secondsAgo < 60) return `${secondsAgo} Second${secondsAgo === 1 ? '' : 's'} Ago`;
  if (secondsAgo < 3600) return `${Math.floor(secondsAgo / 60)} Minute${secondsAgo / 120 >= 1 ? 's' : ''} Ago`;
  if (secondsAgo < 86400) return `${Math.floor(secondsAgo / 3600)} Hour${secondsAgo / 7200 >= 1 ? 's' : ''} Ago`;
  if (secondsAgo < 2592000) return `${Math.floor(secondsAgo / 86400)} Day${secondsAgo / 172800 >= 1 ? 's' : ''} Ago`;
  if (secondsAgo < 31536000) return `${Math.floor(secondsAgo / 2592000)} Month${secondsAgo / 5184000 >= 1 ? 's' : ''} Ago`;
  return `${Math.floor(secondsAgo / 31536000)} Year${secondsAgo / 63072000 >= 1 ? 's' : ''} Ago`;
}

/***/ }),

/***/ 7735:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Hh": function() { return /* reexport safe */ _currency__WEBPACK_IMPORTED_MODULE_1__.Hh; },
/* harmony export */   "iN": function() { return /* reexport safe */ _currency__WEBPACK_IMPORTED_MODULE_1__.iN; },
/* harmony export */   "hr": function() { return /* reexport safe */ _format__WEBPACK_IMPORTED_MODULE_4__.hr; },
/* harmony export */   "az": function() { return /* reexport safe */ _format__WEBPACK_IMPORTED_MODULE_4__.az; },
/* harmony export */   "ZO": function() { return /* reexport safe */ _format__WEBPACK_IMPORTED_MODULE_4__.ZO; },
/* harmony export */   "s4": function() { return /* reexport safe */ _format__WEBPACK_IMPORTED_MODULE_4__.s4; },
/* harmony export */   "uf": function() { return /* reexport safe */ _format__WEBPACK_IMPORTED_MODULE_4__.uf; },
/* harmony export */   "nH": function() { return /* reexport safe */ _format__WEBPACK_IMPORTED_MODULE_4__.nH; },
/* harmony export */   "T3": function() { return /* reexport safe */ _format__WEBPACK_IMPORTED_MODULE_4__.T3; },
/* harmony export */   "Xn": function() { return /* reexport safe */ _format__WEBPACK_IMPORTED_MODULE_4__.Xn; },
/* harmony export */   "xE": function() { return /* reexport safe */ _math__WEBPACK_IMPORTED_MODULE_7__.xE; },
/* harmony export */   "am": function() { return /* reexport safe */ _parse__WEBPACK_IMPORTED_MODULE_8__.a; },
/* harmony export */   "eo": function() { return /* reexport safe */ _parse__WEBPACK_IMPORTED_MODULE_8__.e; },
/* harmony export */   "oX": function() { return /* reexport safe */ _prices__WEBPACK_IMPORTED_MODULE_9__.oX; },
/* harmony export */   "AK": function() { return /* reexport safe */ _styling__WEBPACK_IMPORTED_MODULE_12__.A; },
/* harmony export */   "yC": function() { return /* reexport safe */ _trade__WEBPACK_IMPORTED_MODULE_13__.yC; },
/* harmony export */   "UJ": function() { return /* reexport safe */ _validate__WEBPACK_IMPORTED_MODULE_14__.UJ; },
/* harmony export */   "Fr": function() { return /* reexport safe */ _validate__WEBPACK_IMPORTED_MODULE_14__.Fr; }
/* harmony export */ });
/* harmony import */ var _convert__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7025);
/* harmony import */ var _currency__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6081);
/* harmony import */ var _ens__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1302);
/* harmony import */ var _contract__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(663);
/* harmony import */ var _format__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8277);
/* harmony import */ var _kashi__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(834);
/* harmony import */ var _list__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7284);
/* harmony import */ var _math__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9247);
/* harmony import */ var _parse__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7208);
/* harmony import */ var _prices__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1545);
/* harmony import */ var _rebase__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2271);
/* harmony import */ var _retry__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4162);
/* harmony import */ var _styling__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1769);
/* harmony import */ var _trade__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(4113);
/* harmony import */ var _validate__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(2556);



















/***/ }),

/***/ 834:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Mu": function() { return /* binding */ accrue; },
/* harmony export */   "zK": function() { return /* binding */ accrueTotalAssetWithFee; },
/* harmony export */   "FO": function() { return /* binding */ interestAccrue; },
/* harmony export */   "xM": function() { return /* binding */ getUSDValue; },
/* harmony export */   "Rm": function() { return /* binding */ getUSDString; },
/* harmony export */   "bi": function() { return /* binding */ easyAmount; },
/* harmony export */   "Ym": function() { return /* binding */ takeFee; }
/* harmony export */ });
/* unused harmony export addBorrowFee */
/* harmony import */ var _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1446);
/* harmony import */ var _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constants_kashi__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5635);
/* harmony import */ var _math__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9247);
/* harmony import */ var _currency_getCurrency__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1368);




function accrue(pair, amount, includePrincipal = false) {
  return amount.mul(pair.accrueInfo.interestPerSecond).mul(pair.elapsedSeconds).div((0,_math__WEBPACK_IMPORTED_MODULE_2__/* .e10 */ .TB)(18)).add(includePrincipal ? amount : _math__WEBPACK_IMPORTED_MODULE_2__/* .ZERO */ .xE);
}
function accrueTotalAssetWithFee(pair) {
  const extraAmount = pair.totalBorrow.elastic.mul(pair.accrueInfo.interestPerSecond).mul(pair.elapsedSeconds.add('3600')) // Project an hour into the future
  .div((0,_math__WEBPACK_IMPORTED_MODULE_2__/* .e10 */ .TB)(18));
  const feeAmount = extraAmount.mul(_constants_kashi__WEBPACK_IMPORTED_MODULE_1__/* .PROTOCOL_FEE */ .rO).div(_constants_kashi__WEBPACK_IMPORTED_MODULE_1__/* .PROTOCOL_FEE_DIVISOR */ .LY); // % of interest paid goes to fee

  const feeFraction = feeAmount.mulDiv(pair.totalAsset.base, pair.currentAllAssets.value);
  return {
    elastic: pair.totalAsset.elastic,
    base: pair.totalAsset.base.add(feeFraction)
  };
}
function interestAccrue(pair, interest) {
  if (pair.totalBorrow.base.eq(0)) {
    return _constants_kashi__WEBPACK_IMPORTED_MODULE_1__/* .STARTING_INTEREST_PER_YEAR */ .x3;
  }

  if (pair.elapsedSeconds.lte(0)) {
    return interest;
  }

  let currentInterest = interest;

  if (pair.utilization.lt(_constants_kashi__WEBPACK_IMPORTED_MODULE_1__/* .MINIMUM_TARGET_UTILIZATION */ .L0)) {
    const underFactor = _constants_kashi__WEBPACK_IMPORTED_MODULE_1__/* .MINIMUM_TARGET_UTILIZATION.sub */ .L0.sub(pair.utilization).mulDiv(_constants_kashi__WEBPACK_IMPORTED_MODULE_1__/* .FACTOR_PRECISION */ .v5, _constants_kashi__WEBPACK_IMPORTED_MODULE_1__/* .MINIMUM_TARGET_UTILIZATION */ .L0);
    const scale = _constants_kashi__WEBPACK_IMPORTED_MODULE_1__/* .INTEREST_ELASTICITY.add */ .ch.add(underFactor.mul(underFactor).mul(pair.elapsedSeconds));
    currentInterest = currentInterest.mul(_constants_kashi__WEBPACK_IMPORTED_MODULE_1__/* .INTEREST_ELASTICITY */ .ch).div(scale);

    if (currentInterest.lt(_constants_kashi__WEBPACK_IMPORTED_MODULE_1__/* .MINIMUM_INTEREST_PER_YEAR */ .a3)) {
      currentInterest = _constants_kashi__WEBPACK_IMPORTED_MODULE_1__/* .MINIMUM_INTEREST_PER_YEAR */ .a3; // 0.25% APR minimum
    }
  } else if (pair.utilization.gt(_constants_kashi__WEBPACK_IMPORTED_MODULE_1__/* .MAXIMUM_TARGET_UTILIZATION */ .Ey)) {
    const overFactor = pair.utilization.sub(_constants_kashi__WEBPACK_IMPORTED_MODULE_1__/* .MAXIMUM_TARGET_UTILIZATION */ .Ey).mul(_constants_kashi__WEBPACK_IMPORTED_MODULE_1__/* .FACTOR_PRECISION.div */ .v5.div(_constants_kashi__WEBPACK_IMPORTED_MODULE_1__/* .FULL_UTILIZATION_MINUS_MAX */ .h7));
    const scale = _constants_kashi__WEBPACK_IMPORTED_MODULE_1__/* .INTEREST_ELASTICITY.add */ .ch.add(overFactor.mul(overFactor).mul(pair.elapsedSeconds));
    currentInterest = currentInterest.mul(scale).div(_constants_kashi__WEBPACK_IMPORTED_MODULE_1__/* .INTEREST_ELASTICITY */ .ch);

    if (currentInterest.gt(_constants_kashi__WEBPACK_IMPORTED_MODULE_1__/* .MAXIMUM_INTEREST_PER_YEAR */ .eD)) {
      currentInterest = _constants_kashi__WEBPACK_IMPORTED_MODULE_1__/* .MAXIMUM_INTEREST_PER_YEAR */ .eD; // 1000% APR maximum
    }
  }

  return currentInterest;
}
function getUSDValue(amount, token) {
  return _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0__.BigNumber.from(amount).mul(token.usd).div((0,_math__WEBPACK_IMPORTED_MODULE_2__/* .e10 */ .TB)(token !== null && token !== void 0 && token.decimals ? token.decimals : token.tokenInfo.decimals));
}
function getUSDString(amount, token) {
  return _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0__.BigNumber.from(amount).mul(token.usd).div((0,_math__WEBPACK_IMPORTED_MODULE_2__/* .e10 */ .TB)(token !== null && token !== void 0 && token.decimals ? token.decimals : token.tokenInfo.decimals)).toFixed((0,_currency_getCurrency__WEBPACK_IMPORTED_MODULE_3__/* .getCurrency */ .z)(token.tokenInfo.chainId).decimals);
}
function easyAmount(amount, token) {
  return {
    value: amount,
    string: amount.toFixed(token !== null && token !== void 0 && token.decimals ? token.decimals : token.tokenInfo.decimals),
    usdValue: getUSDValue(amount, token),
    usd: getUSDString(amount, token)
  };
}
function takeFee(amount) {
  return amount.mul(_ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0__.BigNumber.from(9)).div(_ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0__.BigNumber.from(10));
}
function addBorrowFee(amount) {
  return amount.mul(BigNumber.from(10005)).div(BigNumber.from(10000));
}

/***/ }),

/***/ 7284:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HJ": function() { return /* binding */ getTokenList; },
/* harmony export */   "MX": function() { return /* binding */ sortByListPriority; },
/* harmony export */   "ui": function() { return /* binding */ listVersionLabel; }
/* harmony export */ });
/* harmony import */ var _convert__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7025);
/* harmony import */ var ajv__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7663);
/* harmony import */ var ajv__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(ajv__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _constants_token_lists__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1818);
/* harmony import */ var _ens__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1302);
/* harmony import */ var _uniswap_token_lists_src_tokenlist_schema_json__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9081);





const tokenListValidator = new (ajv__WEBPACK_IMPORTED_MODULE_1___default())({
  allErrors: true
}).compile(_uniswap_token_lists_src_tokenlist_schema_json__WEBPACK_IMPORTED_MODULE_4__);
/**
 * Contains the logic for resolving a list URL to a validated token list
 * @param listUrl list url
 * @param resolveENSContentHash resolves an ens name to a contenthash
 */

async function getTokenList(listUrl, resolveENSContentHash) {
  const parsedENS = (0,_ens__WEBPACK_IMPORTED_MODULE_3__/* .parseENSAddress */ .y)(listUrl);
  let urls;

  if (parsedENS) {
    var _parsedENS$ensPath;

    let contentHashUri;

    try {
      contentHashUri = await resolveENSContentHash(parsedENS.ensName);
    } catch (error) {
      console.debug(`Failed to resolve ENS name: ${parsedENS.ensName}`, error);
      throw new Error(`Failed to resolve ENS name: ${parsedENS.ensName}`);
    }

    let translatedUri;

    try {
      translatedUri = (0,_convert__WEBPACK_IMPORTED_MODULE_0__/* .contenthashToUri */ .il)(contentHashUri);
    } catch (error) {
      console.debug('Failed to translate contenthash to URI', contentHashUri);
      throw new Error(`Failed to translate contenthash to URI: ${contentHashUri}`);
    }

    urls = (0,_convert__WEBPACK_IMPORTED_MODULE_0__/* .uriToHttp */ .ie)(`${translatedUri}${(_parsedENS$ensPath = parsedENS.ensPath) !== null && _parsedENS$ensPath !== void 0 ? _parsedENS$ensPath : ''}`);
  } else {
    urls = (0,_convert__WEBPACK_IMPORTED_MODULE_0__/* .uriToHttp */ .ie)(listUrl);
  }

  for (let i = 0; i < urls.length; i++) {
    const url = urls[i];
    const isLast = i === urls.length - 1;
    let response;

    try {
      response = await fetch(url);
    } catch (error) {
      console.debug('Failed to fetch list', listUrl, error);
      if (isLast) throw new Error(`Failed to download list ${listUrl}`);
      continue;
    }

    if (!response.ok) {
      if (isLast) throw new Error(`Failed to download list ${listUrl}`);
      continue;
    }

    const json = await response.json();

    if (!tokenListValidator(json)) {
      var _tokenListValidator$e, _tokenListValidator$e2;

      const validationErrors = (_tokenListValidator$e = (_tokenListValidator$e2 = tokenListValidator.errors) === null || _tokenListValidator$e2 === void 0 ? void 0 : _tokenListValidator$e2.reduce((memo, error) => {
        var _error$message;

        const add = `${error.dataPath} ${(_error$message = error.message) !== null && _error$message !== void 0 ? _error$message : ''}`;
        return memo.length > 0 ? `${memo}; ${add}` : `${add}`;
      }, '')) !== null && _tokenListValidator$e !== void 0 ? _tokenListValidator$e : 'unknown error';
      throw new Error(`Token list failed validation: ${validationErrors}`);
    }

    return json;
  }

  throw new Error('Unrecognized list URL protocol.');
} // use ordering of default list of lists to assign priority

function sortByListPriority(urlA, urlB) {
  const first = _constants_token_lists__WEBPACK_IMPORTED_MODULE_2__/* .DEFAULT_LIST_OF_LISTS.includes */ .Lx.includes(urlA) ? _constants_token_lists__WEBPACK_IMPORTED_MODULE_2__/* .DEFAULT_LIST_OF_LISTS.indexOf */ .Lx.indexOf(urlA) : Number.MAX_SAFE_INTEGER;
  const second = _constants_token_lists__WEBPACK_IMPORTED_MODULE_2__/* .DEFAULT_LIST_OF_LISTS.includes */ .Lx.includes(urlB) ? _constants_token_lists__WEBPACK_IMPORTED_MODULE_2__/* .DEFAULT_LIST_OF_LISTS.indexOf */ .Lx.indexOf(urlB) : Number.MAX_SAFE_INTEGER; // need reverse order to make sure mapping includes top priority last

  if (first < second) return 1;else if (first > second) return -1;
  return 0;
}
function listVersionLabel(version) {
  return `v${version.major}.${version.minor}.${version.patch}`;
}

/***/ }),

/***/ 9247:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "xE": function() { return /* binding */ ZERO; },
/* harmony export */   "TB": function() { return /* binding */ e10; },
/* harmony export */   "LT": function() { return /* binding */ minimum; },
/* harmony export */   "gW": function() { return /* binding */ maximum; }
/* harmony export */ });
/* harmony import */ var _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1446);
/* harmony import */ var _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0__);

const ZERO = _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0__.BigNumber.from('0');
function e10(exponent) {
  return _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0__.BigNumber.from('10').pow(_ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0__.BigNumber.from(exponent));
}
function minimum(...values) {
  let lowest = _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0__.BigNumber.from(values[0]);

  for (let i = 1; i < values.length; i++) {
    const value = _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0__.BigNumber.from(values[i]);

    if (value.lt(lowest)) {
      lowest = value;
    }
  }

  return lowest;
}
function maximum(...values) {
  let highest = _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0__.BigNumber.from(values[0]);

  for (let i = 1; i < values.length; i++) {
    const value = _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0__.BigNumber.from(values[i]);

    if (value.gt(highest)) {
      highest = value;
    }
  }

  return highest;
}

/***/ }),

/***/ 7208:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "a": function() { return /* binding */ parseBalance; },
/* harmony export */   "e": function() { return /* binding */ tryParseAmount; }
/* harmony export */ });
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6766);
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ethersproject_units__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(685);
/* harmony import */ var _ethersproject_units__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_units__WEBPACK_IMPORTED_MODULE_1__);


const parseBalance = (value, decimals = 18) => {
  return (0,_ethersproject_units__WEBPACK_IMPORTED_MODULE_1__.parseUnits)(value || '0', decimals);
}; // try to parse a user entered amount for a given token

function tryParseAmount(value, currency) {
  if (!value || !currency) {
    return undefined;
  }

  try {
    const typedValueParsed = (0,_ethersproject_units__WEBPACK_IMPORTED_MODULE_1__.parseUnits)(value, currency.decimals).toString();

    if (typedValueParsed !== '0') {
      return _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.CurrencyAmount.fromRawAmount(currency, _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(typedValueParsed));
    }
  } catch (error) {
    // should fail if the user specifies too many decimal places of precision (or maybe exceed max uint?)
    console.debug(`Failed to parse input amount: "${value}"`, error);
  } // necessary for all paths to return a value


  return undefined;
}

/***/ }),

/***/ 1545:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GS": function() { return /* binding */ computeRealizedLPFeePercent; },
/* harmony export */   "oX": function() { return /* binding */ warningSeverity; }
/* harmony export */ });
/* unused harmony exports formatExecutionPrice, computeRealizedLPFeeAmount */
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8532);
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6766);
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__);


const THIRTY_BIPS_FEE = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.Percent(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.JSBI.BigInt(30), _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.JSBI.BigInt(10000));
const ONE_HUNDRED_PERCENT = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.Percent(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.JSBI.BigInt(10000), _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.JSBI.BigInt(10000));
const INPUT_FRACTION_AFTER_FEE = ONE_HUNDRED_PERCENT.subtract(THIRTY_BIPS_FEE);
const TWENTY_FIVE_BIPS_FEE = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.Percent(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.JSBI.BigInt(25), _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.JSBI.BigInt(10000));
const FIVE_BIPS_FEE = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.Percent(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.JSBI.BigInt(5), _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.JSBI.BigInt(10000));
function formatExecutionPrice(trade, inverted, chainId) {
  if (!trade) {
    return '';
  }

  return inverted ? `${trade.executionPrice.invert().toSignificant(6)} ${trade.inputAmount.currency.symbol} / ${trade.outputAmount.currency.symbol}` : `${trade.executionPrice.toSignificant(6)} ${trade.outputAmount.currency.symbol} / ${trade.inputAmount.currency.symbol}`;
} // computes realized lp fee as a percent

function computeRealizedLPFeePercent(trade) {
  let percent;

  if (trade instanceof _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.Trade) {
    // for each hop in our trade, take away the x*y=k price impact from 0.3% fees
    // e.g. for 3 tokens/2 hops: 1 - ((1 - .03) * (1-.03))
    percent = ONE_HUNDRED_PERCENT.subtract(trade.route.pairs.reduce(currentFee => currentFee.multiply(INPUT_FRACTION_AFTER_FEE), ONE_HUNDRED_PERCENT));
  }

  return new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.Percent(percent.numerator, percent.denominator);
} // computes price breakdown for the trade

function computeRealizedLPFeeAmount(trade) {
  if (trade) {
    const realizedLPFee = computeRealizedLPFeePercent(trade); // the amount of the input that accrues to LPs

    return CurrencyAmount.fromRawAmount(trade.inputAmount.currency, trade.inputAmount.multiply(realizedLPFee).quotient);
  }

  return undefined;
}
const IMPACT_TIERS = [_constants__WEBPACK_IMPORTED_MODULE_0__/* .BLOCKED_PRICE_IMPACT_NON_EXPERT */ .lN, _constants__WEBPACK_IMPORTED_MODULE_0__/* .ALLOWED_PRICE_IMPACT_HIGH */ .Uf, _constants__WEBPACK_IMPORTED_MODULE_0__/* .ALLOWED_PRICE_IMPACT_MEDIUM */ .p9, _constants__WEBPACK_IMPORTED_MODULE_0__/* .ALLOWED_PRICE_IMPACT_LOW */ .Bz];
function warningSeverity(priceImpact) {
  if (!priceImpact) return 4;
  let impact = IMPACT_TIERS.length;

  for (const impactLevel of IMPACT_TIERS) {
    if (impactLevel.lessThan(priceImpact)) return impact;
    impact--;
  }

  return 0;
}

/***/ }),

/***/ 2271:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "N": function() { return /* binding */ toElastic; }
/* harmony export */ });
/* unused harmony export rebase */
/* harmony import */ var _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1446);
/* harmony import */ var _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0__);

function rebase(value, from, to) {
  return from ? value.mul(to).div(from) : BigNumber.from(0);
}
function toElastic(total, base, roundUp) {
  let elastic;

  if (total.base.eq(_ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_0__.BigNumber.from(0))) {
    elastic = base;
  } else {
    elastic = base.mul(total.elastic).div(total.base);

    if (roundUp && elastic.mul(total.base).div(total.elastic).lt(base)) {
      elastic = elastic.add(1);
    }
  }

  return elastic;
}

/***/ }),

/***/ 4162:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "s1": function() { return /* binding */ RetryableError; },
/* harmony export */   "XD": function() { return /* binding */ retry; }
/* harmony export */ });
/* unused harmony export CancelledError */
function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function wait(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function waitRandom(min, max) {
  return wait(min + Math.round(Math.random() * Math.max(0, max - min)));
}
/**
 * This error is thrown if the function is cancelled before completing
 */


class CancelledError extends Error {
  constructor() {
    super('Cancelled');

    _defineProperty(this, "isCancelledError", true);
  }

}
/**
 * Throw this error if the function should retry
 */

class RetryableError extends Error {
  constructor(...args) {
    super(...args);

    _defineProperty(this, "isRetryableError", true);
  }

}

/**
 * Retries the function that returns the promise until the promise successfully resolves up to n retries
 * @param fn function to retry
 * @param n how many times to retry
 * @param minWait min wait between retries in ms
 * @param maxWait max wait between retries in ms
 */
function retry(fn, {
  n,
  minWait,
  maxWait
}) {
  let completed = false;
  let rejectCancelled;
  const promise = new Promise(async (resolve, reject) => {
    rejectCancelled = reject;

    while (true) {
      let result;

      try {
        result = await fn();

        if (!completed) {
          resolve(result);
          completed = true;
        }

        break;
      } catch (error) {
        if (completed) {
          break;
        }

        if (n <= 0 || !error.isRetryableError) {
          reject(error);
          completed = true;
          break;
        }

        n--;
      }

      await waitRandom(minWait, maxWait);
    }
  });
  return {
    promise,
    cancel: () => {
      if (completed) return;
      completed = true;
      rejectCancelled(new CancelledError());
    }
  };
}

/***/ }),

/***/ 1769:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "A": function() { return /* binding */ classNames; }
/* harmony export */ });
function classNames(...classes) {
  return classes.filter(Boolean).join(' ');
}

/***/ }),

/***/ 4113:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "_B": function() { return /* binding */ isTradeBetter; },
/* harmony export */   "yC": function() { return /* binding */ calculateGasMargin; },
/* harmony export */   "uc": function() { return /* binding */ calculateSlippageAmount; },
/* harmony export */   "Ld": function() { return /* binding */ computeFiatValuePriceImpact; }
/* harmony export */ });
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6766);
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8532);
/* harmony import */ var ethers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4879);
/* harmony import */ var ethers__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(ethers__WEBPACK_IMPORTED_MODULE_2__);


 // returns whether tradeB is better than tradeA by at least a threshold percentage amount

function isTradeBetter(tradeA, tradeB, minimumDelta = _constants__WEBPACK_IMPORTED_MODULE_1__/* .ZERO_PERCENT */ .qN) {
  if (tradeA && !tradeB) return false;
  if (tradeB && !tradeA) return true;
  if (!tradeA || !tradeB) return undefined;

  if (tradeA.tradeType !== tradeB.tradeType || !tradeA.inputAmount.currency.equals(tradeB.inputAmount.currency) || !tradeB.outputAmount.currency.equals(tradeB.outputAmount.currency)) {
    throw new Error('Comparing incomparable trades');
  }

  if (minimumDelta.equalTo(_constants__WEBPACK_IMPORTED_MODULE_1__/* .ZERO_PERCENT */ .qN)) {
    return tradeA.executionPrice.lessThan(tradeB.executionPrice);
  } else {
    return tradeA.executionPrice.asFraction.multiply(minimumDelta.add(_constants__WEBPACK_IMPORTED_MODULE_1__/* .ONE_HUNDRED_PERCENT */ .yC)).lessThan(tradeB.executionPrice);
  }
} // add 20%

function calculateGasMargin(value) {
  return value.mul(ethers__WEBPACK_IMPORTED_MODULE_2__.BigNumber.from(10000 + 2000)).div(ethers__WEBPACK_IMPORTED_MODULE_2__.BigNumber.from(10000));
}
const ONE = new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Fraction(1, 1);
function calculateSlippageAmount(value, slippage) {
  if (slippage.lessThan(0) || slippage.greaterThan(ONE)) throw new Error('Unexpected slippage');
  return [value.multiply(ONE.subtract(slippage)).quotient, value.multiply(ONE.add(slippage)).quotient];
}
function computeFiatValuePriceImpact(fiatValueInput, fiatValueOutput) {
  if (!fiatValueOutput || !fiatValueInput) return undefined;
  if (!fiatValueInput.currency.equals(fiatValueOutput.currency)) return undefined;
  if (_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.equal(fiatValueInput.quotient, _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(0))) return undefined;
  const pct = _constants__WEBPACK_IMPORTED_MODULE_1__/* .ONE_HUNDRED_PERCENT.subtract */ .yC.subtract(fiatValueOutput.divide(fiatValueInput));
  return new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.Percent(pct.numerator, pct.denominator);
}

/***/ }),

/***/ 2556:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Fr": function() { return /* binding */ isZero; },
/* harmony export */   "O2": function() { return /* binding */ isEmptyValue; },
/* harmony export */   "UJ": function() { return /* binding */ isAddress; },
/* harmony export */   "wK": function() { return /* binding */ isTokenOnList; }
/* harmony export */ });
/* harmony import */ var ethers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4879);
/* harmony import */ var ethers__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(ethers__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ethersproject_address__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7398);
/* harmony import */ var _ethersproject_address__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_address__WEBPACK_IMPORTED_MODULE_1__);
// CONVENTION isFoo -> boolean


/**
 * Returns true if the string value is zero in hex
 * @param hexNumberString
 */

function isZero(hexNumberString) {
  return /^0x0*$/.test(hexNumberString);
}
const isEmptyValue = text => ethers__WEBPACK_IMPORTED_MODULE_0__.BigNumber.isBigNumber(text) ? ethers__WEBPACK_IMPORTED_MODULE_0__.BigNumber.from(text).isZero() : text === '' || text.replace(/0/g, '').replace(/\./, '') === ''; // returns the checksummed address if the address is valid, otherwise returns false

function isAddress(value) {
  try {
    return (0,_ethersproject_address__WEBPACK_IMPORTED_MODULE_1__.getAddress)(value);
  } catch {
    return false;
  }
}
function isTokenOnList(tokenAddressMap, token) {
  var _tokenAddressMap$toke;

  return Boolean((token === null || token === void 0 ? void 0 : token.isToken) && ((_tokenAddressMap$toke = tokenAddressMap[token.chainId]) === null || _tokenAddressMap$toke === void 0 ? void 0 : _tokenAddressMap$toke[token.address]));
}

/***/ }),

/***/ 1955:
/***/ (function(module) {

"use strict";
module.exports = JSON.parse('[{"inputs":[{"internalType":"address","name":"_uniV3Factory","type":"address"},{"internalType":"address","name":"_WETH","type":"address"}],"stateMutability":"nonpayable","type":"constructor"},{"inputs":[],"name":"WETH","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"components":[{"internalType":"bytes","name":"path","type":"bytes"},{"internalType":"address","name":"recipient","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"},{"internalType":"uint256","name":"amountIn","type":"uint256"},{"internalType":"uint256","name":"amountOutMinimum","type":"uint256"}],"internalType":"struct IUniV3Router.ExactInputParams","name":"params","type":"tuple"}],"name":"exactInput","outputs":[{"internalType":"uint256","name":"amountOut","type":"uint256"}],"stateMutability":"payable","type":"function"},{"inputs":[{"components":[{"internalType":"bytes","name":"path","type":"bytes"},{"internalType":"address","name":"recipient","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"},{"internalType":"uint256","name":"amountIn","type":"uint256"},{"internalType":"uint256","name":"amountOutMinimum","type":"uint256"}],"internalType":"struct IUniV3Router.ExactInputParams","name":"params","type":"tuple"},{"internalType":"uint256","name":"tipAmount","type":"uint256"}],"name":"exactInputAndTipAmount","outputs":[{"internalType":"uint256","name":"amountOut","type":"uint256"}],"stateMutability":"payable","type":"function"},{"inputs":[{"components":[{"internalType":"address","name":"tokenIn","type":"address"},{"internalType":"address","name":"tokenOut","type":"address"},{"internalType":"uint24","name":"fee","type":"uint24"},{"internalType":"address","name":"recipient","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"},{"internalType":"uint256","name":"amountIn","type":"uint256"},{"internalType":"uint256","name":"amountOutMinimum","type":"uint256"},{"internalType":"uint160","name":"sqrtPriceLimitX96","type":"uint160"}],"internalType":"struct IUniV3Router.ExactInputSingleParams","name":"params","type":"tuple"}],"name":"exactInputSingle","outputs":[{"internalType":"uint256","name":"amountOut","type":"uint256"}],"stateMutability":"payable","type":"function"},{"inputs":[{"components":[{"internalType":"address","name":"tokenIn","type":"address"},{"internalType":"address","name":"tokenOut","type":"address"},{"internalType":"uint24","name":"fee","type":"uint24"},{"internalType":"address","name":"recipient","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"},{"internalType":"uint256","name":"amountIn","type":"uint256"},{"internalType":"uint256","name":"amountOutMinimum","type":"uint256"},{"internalType":"uint160","name":"sqrtPriceLimitX96","type":"uint160"}],"internalType":"struct IUniV3Router.ExactInputSingleParams","name":"params","type":"tuple"},{"internalType":"uint256","name":"tipAmount","type":"uint256"}],"name":"exactInputSingleAndTipAmount","outputs":[{"internalType":"uint256","name":"amountOut","type":"uint256"}],"stateMutability":"payable","type":"function"},{"inputs":[{"components":[{"internalType":"bytes","name":"path","type":"bytes"},{"internalType":"address","name":"recipient","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"},{"internalType":"uint256","name":"amountOut","type":"uint256"},{"internalType":"uint256","name":"amountInMaximum","type":"uint256"}],"internalType":"struct IUniV3Router.ExactOutputParams","name":"params","type":"tuple"}],"name":"exactOutput","outputs":[{"internalType":"uint256","name":"amountIn","type":"uint256"}],"stateMutability":"payable","type":"function"},{"inputs":[{"components":[{"internalType":"bytes","name":"path","type":"bytes"},{"internalType":"address","name":"recipient","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"},{"internalType":"uint256","name":"amountOut","type":"uint256"},{"internalType":"uint256","name":"amountInMaximum","type":"uint256"}],"internalType":"struct IUniV3Router.ExactOutputParams","name":"params","type":"tuple"},{"internalType":"uint256","name":"tipAmount","type":"uint256"}],"name":"exactOutputAndTipAmount","outputs":[{"internalType":"uint256","name":"amountIn","type":"uint256"}],"stateMutability":"payable","type":"function"},{"inputs":[{"components":[{"internalType":"address","name":"tokenIn","type":"address"},{"internalType":"address","name":"tokenOut","type":"address"},{"internalType":"uint24","name":"fee","type":"uint24"},{"internalType":"address","name":"recipient","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"},{"internalType":"uint256","name":"amountOut","type":"uint256"},{"internalType":"uint256","name":"amountInMaximum","type":"uint256"},{"internalType":"uint160","name":"sqrtPriceLimitX96","type":"uint160"}],"internalType":"struct IUniV3Router.ExactOutputSingleParams","name":"params","type":"tuple"}],"name":"exactOutputSingle","outputs":[{"internalType":"uint256","name":"amountIn","type":"uint256"}],"stateMutability":"payable","type":"function"},{"inputs":[{"components":[{"internalType":"address","name":"tokenIn","type":"address"},{"internalType":"address","name":"tokenOut","type":"address"},{"internalType":"uint24","name":"fee","type":"uint24"},{"internalType":"address","name":"recipient","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"},{"internalType":"uint256","name":"amountOut","type":"uint256"},{"internalType":"uint256","name":"amountInMaximum","type":"uint256"},{"internalType":"uint160","name":"sqrtPriceLimitX96","type":"uint160"}],"internalType":"struct IUniV3Router.ExactOutputSingleParams","name":"params","type":"tuple"},{"internalType":"uint256","name":"tipAmount","type":"uint256"}],"name":"exactOutputSingleAndTipAmount","outputs":[{"internalType":"uint256","name":"amountIn","type":"uint256"}],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"bytes[]","name":"data","type":"bytes[]"}],"name":"multicall","outputs":[{"internalType":"bytes[]","name":"results","type":"bytes[]"}],"stateMutability":"payable","type":"function"},{"inputs":[],"name":"refundETH","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"address","name":"token","type":"address"},{"internalType":"uint256","name":"value","type":"uint256"},{"internalType":"uint256","name":"deadline","type":"uint256"},{"internalType":"uint8","name":"v","type":"uint8"},{"internalType":"bytes32","name":"r","type":"bytes32"},{"internalType":"bytes32","name":"s","type":"bytes32"}],"name":"selfPermit","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"address","name":"token","type":"address"},{"internalType":"uint256","name":"nonce","type":"uint256"},{"internalType":"uint256","name":"expiry","type":"uint256"},{"internalType":"uint8","name":"v","type":"uint8"},{"internalType":"bytes32","name":"r","type":"bytes32"},{"internalType":"bytes32","name":"s","type":"bytes32"}],"name":"selfPermitAllowed","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"address","name":"token","type":"address"},{"internalType":"uint256","name":"nonce","type":"uint256"},{"internalType":"uint256","name":"expiry","type":"uint256"},{"internalType":"uint8","name":"v","type":"uint8"},{"internalType":"bytes32","name":"r","type":"bytes32"},{"internalType":"bytes32","name":"s","type":"bytes32"}],"name":"selfPermitAllowedIfNecessary","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"address","name":"token","type":"address"},{"internalType":"uint256","name":"value","type":"uint256"},{"internalType":"uint256","name":"deadline","type":"uint256"},{"internalType":"uint8","name":"v","type":"uint8"},{"internalType":"bytes32","name":"r","type":"bytes32"},{"internalType":"bytes32","name":"s","type":"bytes32"}],"name":"selfPermitIfNecessary","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"address","name":"factory","type":"address"},{"components":[{"internalType":"uint256","name":"amountIn","type":"uint256"},{"internalType":"uint256","name":"amountOut","type":"uint256"},{"internalType":"address[]","name":"path","type":"address[]"},{"internalType":"address payable","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"}],"internalType":"struct ArcherSwapRouter.Trade","name":"trade","type":"tuple"},{"internalType":"uint256","name":"tipAmount","type":"uint256"}],"name":"swapETHForExactTokensAndTipAmount","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"address","name":"factory","type":"address"},{"components":[{"internalType":"uint256","name":"amountIn","type":"uint256"},{"internalType":"uint256","name":"amountOut","type":"uint256"},{"internalType":"address[]","name":"path","type":"address[]"},{"internalType":"address payable","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"}],"internalType":"struct ArcherSwapRouter.Trade","name":"trade","type":"tuple"},{"internalType":"uint256","name":"tipAmount","type":"uint256"}],"name":"swapExactETHForTokensAndTipAmount","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"address","name":"factory","type":"address"},{"components":[{"internalType":"uint256","name":"amountIn","type":"uint256"},{"internalType":"uint256","name":"amountOut","type":"uint256"},{"internalType":"address[]","name":"path","type":"address[]"},{"internalType":"address payable","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"}],"internalType":"struct ArcherSwapRouter.Trade","name":"trade","type":"tuple"},{"internalType":"uint256","name":"tipAmount","type":"uint256"}],"name":"swapExactTokensForETHAndTipAmount","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"address","name":"factory","type":"address"},{"components":[{"internalType":"uint256","name":"amountIn","type":"uint256"},{"internalType":"uint256","name":"amountOut","type":"uint256"},{"internalType":"address[]","name":"path","type":"address[]"},{"internalType":"address payable","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"}],"internalType":"struct ArcherSwapRouter.Trade","name":"trade","type":"tuple"}],"name":"swapExactTokensForTokensAndTipAmount","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"address","name":"factory","type":"address"},{"components":[{"internalType":"uint256","name":"amountIn","type":"uint256"},{"internalType":"uint256","name":"amountOut","type":"uint256"},{"internalType":"address[]","name":"path","type":"address[]"},{"internalType":"address payable","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"}],"internalType":"struct ArcherSwapRouter.Trade","name":"trade","type":"tuple"},{"internalType":"address[]","name":"pathToEth","type":"address[]"},{"internalType":"uint32","name":"tipPct","type":"uint32"}],"name":"swapExactTokensForTokensAndTipPct","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"address","name":"factory","type":"address"},{"components":[{"internalType":"uint256","name":"amountIn","type":"uint256"},{"internalType":"uint256","name":"amountOut","type":"uint256"},{"internalType":"address[]","name":"path","type":"address[]"},{"internalType":"address payable","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"}],"internalType":"struct ArcherSwapRouter.Trade","name":"trade","type":"tuple"},{"internalType":"uint256","name":"tipAmount","type":"uint256"}],"name":"swapTokensForExactETHAndTipAmount","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"address","name":"factory","type":"address"},{"components":[{"internalType":"uint256","name":"amountIn","type":"uint256"},{"internalType":"uint256","name":"amountOut","type":"uint256"},{"internalType":"address[]","name":"path","type":"address[]"},{"internalType":"address payable","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"}],"internalType":"struct ArcherSwapRouter.Trade","name":"trade","type":"tuple"}],"name":"swapTokensForExactTokensAndTipAmount","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"address","name":"factory","type":"address"},{"components":[{"internalType":"uint256","name":"amountIn","type":"uint256"},{"internalType":"uint256","name":"amountOut","type":"uint256"},{"internalType":"address[]","name":"path","type":"address[]"},{"internalType":"address payable","name":"to","type":"address"},{"internalType":"uint256","name":"deadline","type":"uint256"}],"internalType":"struct ArcherSwapRouter.Trade","name":"trade","type":"tuple"},{"internalType":"address[]","name":"pathToEth","type":"address[]"},{"internalType":"uint32","name":"tipPct","type":"uint32"}],"name":"swapTokensForExactTokensAndTipPct","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"address","name":"token","type":"address"},{"internalType":"uint256","name":"amountMinimum","type":"uint256"},{"internalType":"address","name":"recipient","type":"address"}],"name":"sweepToken","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"address","name":"token","type":"address"},{"internalType":"uint256","name":"amountMinimum","type":"uint256"},{"internalType":"address","name":"recipient","type":"address"},{"internalType":"uint256","name":"feeBips","type":"uint256"},{"internalType":"address","name":"feeRecipient","type":"address"}],"name":"sweepTokenWithFee","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"uint256","name":"tipAmount","type":"uint256"}],"name":"tip","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[],"name":"uniV3Factory","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"int256","name":"amount0Delta","type":"int256"},{"internalType":"int256","name":"amount1Delta","type":"int256"},{"internalType":"bytes","name":"_data","type":"bytes"}],"name":"uniswapV3SwapCallback","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"amountMinimum","type":"uint256"},{"internalType":"address","name":"recipient","type":"address"}],"name":"unwrapWETH","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"uint256","name":"tipAmount","type":"uint256"},{"internalType":"uint256","name":"amountMinimum","type":"uint256"},{"internalType":"address","name":"recipient","type":"address"}],"name":"unwrapWETHAndTip","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"uint256","name":"amountMinimum","type":"uint256"},{"internalType":"address","name":"recipient","type":"address"},{"internalType":"uint256","name":"feeBips","type":"uint256"},{"internalType":"address","name":"feeRecipient","type":"address"}],"name":"unwrapWETHWithFee","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"uint256","name":"amountMinimum","type":"uint256"}],"name":"withdrawWETH","outputs":[{"internalType":"uint256","name":"balanceWETH","type":"uint256"}],"stateMutability":"nonpayable","type":"function"},{"stateMutability":"payable","type":"receive"}]');

/***/ })

};
;