exports.id = 369;
exports.ids = [369];
exports.modules = {

/***/ 3553:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WJ": function() { return /* binding */ Chef; },
/* harmony export */   "FJ": function() { return /* binding */ PairType; }
/* harmony export */ });
/* unused harmony export Rewarder */
let Chef;

(function (Chef) {
  Chef[Chef["MASTERCHEF"] = 0] = "MASTERCHEF";
  Chef[Chef["MASTERCHEF_V2"] = 1] = "MASTERCHEF_V2";
  Chef[Chef["MINICHEF"] = 2] = "MINICHEF";
})(Chef || (Chef = {}));

let Rewarder;

(function (Rewarder) {
  Rewarder[Rewarder["SIMPLE"] = 0] = "SIMPLE";
  Rewarder[Rewarder["COMPLEX"] = 1] = "COMPLEX";
  Rewarder[Rewarder["ALCX"] = 2] = "ALCX";
})(Rewarder || (Rewarder = {}));

let PairType;

(function (PairType) {
  PairType[PairType["SWAP"] = 0] = "SWAP";
  PairType[PairType["KASHI"] = 1] = "KASHI";
})(PairType || (PairType = {}));

/***/ }),

/***/ 369:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "nH": function() { return /* reexport */ useAlcxPrice; },
  "Te": function() { return /* reexport */ useAverageBlockTime; },
  "Py": function() { return /* reexport */ useCustomDayBlock; },
  "oP": function() { return /* reexport */ useCvxPrice; },
  "Yg": function() { return /* reexport */ useDayData; },
  "Bh": function() { return /* reexport */ useEthPrice; },
  "rv": function() { return /* reexport */ useFactory; },
  "fU": function() { return /* reexport */ useFarmPairAddresses; },
  "E2": function() { return /* reexport */ useFarms; },
  "Fp": function() { return /* reexport */ useKashiPairs; },
  "av": function() { return /* reexport */ useMasterChefV1SushiPerBlock; },
  "M1": function() { return /* reexport */ useMasterChefV1TotalAllocPoint; },
  "ME": function() { return /* reexport */ useMaticPrice; },
  "ZU": function() { return /* reexport */ useOneDayBlock; },
  "Fb": function() { return /* reexport */ useOnePrice; },
  "T5": function() { return /* reexport */ useOneWeekBlock; },
  "it": function() { return /* reexport */ useStakePrice; },
  "__": function() { return /* reexport */ useSushiPairs; },
  "W": function() { return /* reexport */ useSushiPrice; },
  "dQ": function() { return /* reexport */ useToken; },
  "w_": function() { return /* reexport */ useTokenPairs; },
  "rU": function() { return /* reexport */ useTokens; },
  "nC": function() { return /* reexport */ useTransactions; }
});

// UNUSED EXPORTS: BLOCKS, EXCHANGE, MASTERCHEF_V1, MASTERCHEF_V2, MINICHEF, exchange, fetcher, getAlcxPrice, getAverageBlockTime, getBlocks, getBundle, getCustomDayBlock, getCvxPrice, getDayData, getEthPrice, getFactory, getLiquidityPositions, getMasterChefV1Farms, getMasterChefV1PairAddreses, getMasterChefV1SushiPerBlock, getMasterChefV1TotalAllocPoint, getMasterChefV2Farms, getMasterChefV2PairAddreses, getMaticPrice, getMiniChefFarms, getMiniChefPairAddreses, getOneDayBlock, getOnePrice, getOneWeekBlock, getPairs, getStakePrice, getSushiPrice, getToken, getTokenPairs, getTokenPrice, getTokenPrices, getTokenSubset, getTokens, getTransactions, masterChefV1, masterChefV2, miniChef, status, useBundle, useExchange, useLiquidityPositions, useMasterChefV1Farms, useMasterChefV1PairAddresses, useMasterChefV2Farms, useMasterChefV2PairAddresses, useMiniChefFarms, useMiniChefPairAddresses

// EXTERNAL MODULE: external "date-fns"
var external_date_fns_ = __webpack_require__(3879);
// EXTERNAL MODULE: external "@sushiswap/sdk"
var sdk_ = __webpack_require__(6766);
;// CONCATENATED MODULE: ./src/services/graph/constants/index.ts

const THE_GRAPH = 'https://api.thegraph.com';
const constants_GRAPH_HOST = {
  [sdk_.ChainId.MAINNET]: THE_GRAPH,
  [sdk_.ChainId.XDAI]: THE_GRAPH,
  [sdk_.ChainId.MATIC]: THE_GRAPH,
  [sdk_.ChainId.FANTOM]: THE_GRAPH,
  [sdk_.ChainId.BSC]: THE_GRAPH,
  [sdk_.ChainId.AVALANCHE]: THE_GRAPH,
  [sdk_.ChainId.CELO]: THE_GRAPH,
  [sdk_.ChainId.HARMONY]: 'https://sushi.graph.t.hmny.io',
  [sdk_.ChainId.OKEX]: 'https://graph.kkt.one/node'
};
// EXTERNAL MODULE: ./src/services/graph/queries/index.ts + 5 modules
var queries = __webpack_require__(4068);
// EXTERNAL MODULE: external "graphql-request"
var external_graphql_request_ = __webpack_require__(7435);
;// CONCATENATED MODULE: ./src/services/graph/fetchers/blocks.ts





const BLOCKS = {
  [sdk_.ChainId.MAINNET]: 'blocklytics/ethereum-blocks',
  [sdk_.ChainId.XDAI]: 'matthewlilley/xdai-blocks',
  [sdk_.ChainId.MATIC]: 'matthewlilley/polygon-blocks',
  [sdk_.ChainId.FANTOM]: 'matthewlilley/fantom-blocks',
  [sdk_.ChainId.BSC]: 'matthewlilley/bsc-blocks',
  [sdk_.ChainId.HARMONY]: 'sushiswap/harmony-blocks',
  [sdk_.ChainId.AVALANCHE]: 'matthewlilley/avalanche-blocks',
  [sdk_.ChainId.CELO]: 'sushiswap/celo-blocks'
};
const fetcher = async (chainId = sdk_.ChainId.MAINNET, query, variables) => (0,external_graphql_request_.request)(`${constants_GRAPH_HOST[chainId]}/subgraphs/name/${BLOCKS[chainId]}`, query, variables);
const getBlocks = async (chainId = sdk_.ChainId.MAINNET, start, end) => {
  const {
    blocks
  } = await fetcher(chainId, queries/* blocksQuery */.LG, {
    start,
    end
  });
  return blocks;
};
const getOneDayBlock = async (chainId = sdk_.ChainId.MAINNET) => {
  var _blocks$;

  const date = (0,external_date_fns_.startOfHour)((0,external_date_fns_.subDays)(Date.now(), 1));
  const start = Math.floor(Number(date) / 1000);
  const end = Math.floor(Number(date) / 1000) + 600;
  const {
    blocks
  } = await fetcher(chainId, queries/* blocksQuery */.LG, {
    start,
    end
  });
  return blocks === null || blocks === void 0 ? void 0 : (_blocks$ = blocks[0]) === null || _blocks$ === void 0 ? void 0 : _blocks$.number;
};
const getOneWeekBlock = async (chainId = sdk_.ChainId.MAINNET) => {
  var _blocks$2;

  const date = (0,external_date_fns_.startOfHour)((0,external_date_fns_.subDays)(Date.now(), 7));
  const start = Math.floor(Number(date) / 1000);
  const end = Math.floor(Number(date) / 1000) + 600;
  const {
    blocks
  } = await fetcher(chainId, queries/* blocksQuery */.LG, {
    start,
    end
  });
  return blocks === null || blocks === void 0 ? void 0 : (_blocks$2 = blocks[0]) === null || _blocks$2 === void 0 ? void 0 : _blocks$2.number;
};
const getCustomDayBlock = async (chainId = sdk_.ChainId.MAINNET, days) => {
  var _blocks$3;

  const date = (0,external_date_fns_.startOfHour)((0,external_date_fns_.subDays)(Date.now(), days));
  const start = Math.floor(Number(date) / 1000);
  const end = Math.floor(Number(date) / 1000) + 600;
  const {
    blocks
  } = await (0,external_graphql_request_.request)(`https://api.thegraph.com/subgraphs/name/${BLOCKS[chainId]}`, queries/* blocksQuery */.LG, {
    start,
    end
  });
  return blocks === null || blocks === void 0 ? void 0 : (_blocks$3 = blocks[0]) === null || _blocks$3 === void 0 ? void 0 : _blocks$3.number;
}; // Grabs the last 1000 (a sample statistical) blocks and averages
// the time difference between them

const getAverageBlockTime = async (chainId = sdk_.ChainId.MAINNET) => {
  // console.log('getAverageBlockTime')
  const now = (0,external_date_fns_.startOfHour)(Date.now());
  const start = (0,external_date_fns_.getUnixTime)((0,external_date_fns_.subHours)(now, 6));
  const end = (0,external_date_fns_.getUnixTime)(now);
  const blocks = await getBlocks(chainId, start, end);
  const averageBlockTime = blocks === null || blocks === void 0 ? void 0 : blocks.reduce((previousValue, currentValue, currentIndex) => {
    if (previousValue.timestamp) {
      const difference = previousValue.timestamp - currentValue.timestamp;
      previousValue.averageBlockTime = previousValue.averageBlockTime + difference;
    }

    previousValue.timestamp = currentValue.timestamp;

    if (currentIndex === blocks.length - 1) {
      return previousValue.averageBlockTime / blocks.length;
    }

    return previousValue;
  }, {
    timestamp: null,
    averageBlockTime: 0
  });
  return averageBlockTime;
};
;// CONCATENATED MODULE: ./src/services/graph/fetchers/exchange.ts




const EXCHANGE = {
  [sdk_.ChainId.MAINNET]: 'sushiswap/exchange',
  [sdk_.ChainId.XDAI]: 'sushiswap/xdai-exchange',
  [sdk_.ChainId.MATIC]: 'sushiswap/matic-exchange',
  [sdk_.ChainId.FANTOM]: 'sushiswap/fantom-exchange',
  [sdk_.ChainId.BSC]: 'sushiswap/bsc-exchange',
  [sdk_.ChainId.HARMONY]: 'sushiswap/harmony-exchange',
  [sdk_.ChainId.OKEX]: 'sushiswap/okex-exchange',
  [sdk_.ChainId.AVALANCHE]: 'sushiswap/avalanche-exchange',
  [sdk_.ChainId.CELO]: 'sushiswap/celo-exchange'
};
const exchange_exchange = async (chainId = sdk_.ChainId.MAINNET, query, variables) => (0,external_graphql_request_.request)(`${constants_GRAPH_HOST[chainId]}/subgraphs/name/${EXCHANGE[chainId]}`, query, variables);
const getPairs = async (chainId = sdk_.ChainId.MAINNET, variables = undefined, query = queries/* pairsQuery */.aS) => {
  const {
    pairs
  } = await exchange_exchange(chainId, query, variables);
  return pairs;
};
const getTokenSubset = async (chainId = sdk_.ChainId.MAINNET, variables) => {
  // console.log('getTokenSubset')
  const {
    tokens
  } = await exchange_exchange(chainId, queries/* tokenSubsetQuery */.Zg, variables);
  return tokens;
};
const getTokens = async (chainId = sdk_.ChainId.MAINNET, query = queries/* tokensQuery */.zz, variables) => {
  // console.log('getTokens')
  const {
    tokens
  } = await exchange_exchange(chainId, query, variables);
  return tokens;
};
const getToken = async (chainId = sdk_.ChainId.MAINNET, query = queries/* tokenQuery */.Pd, variables) => {
  // console.log('getTokens')
  const {
    token
  } = await exchange_exchange(chainId, query, variables);
  return token;
};
const getTokenPrices = async (chainId = ChainId.MAINNET, variables) => {
  // console.log('getTokenPrice')
  const {
    tokens
  } = await exchange_exchange(chainId, tokensQuery, variables);
  return tokens.map(token => token === null || token === void 0 ? void 0 : token.derivedETH);
};
const getTokenPrice = async (chainId = sdk_.ChainId.MAINNET, query, variables) => {
  // console.log('getTokenPrice')
  const ethPrice = await getEthPrice(chainId);
  const {
    token
  } = await exchange_exchange(chainId, query, variables);
  return (token === null || token === void 0 ? void 0 : token.derivedETH) * ethPrice;
};
const getEthPrice = async (chainId = sdk_.ChainId.MAINNET, variables = undefined) => {
  var _data$bundles, _data$bundles$;

  // console.log('getEthPrice')
  const data = await exchange_getBundle(chainId, undefined, variables);
  return data === null || data === void 0 ? void 0 : (_data$bundles = data.bundles) === null || _data$bundles === void 0 ? void 0 : (_data$bundles$ = _data$bundles[0]) === null || _data$bundles$ === void 0 ? void 0 : _data$bundles$.ethPrice;
};
const getCvxPrice = async () => {
  return getTokenPrice(sdk_.ChainId.MAINNET, queries/* tokenPriceQuery */.qI, {
    id: '0x4e3fbd56cd56c3e72c1403e103b45db9da5b9d2b'
  });
};
const getMaticPrice = async () => {
  // console.log('getMaticPrice')
  return getTokenPrice(sdk_.ChainId.MATIC, queries/* tokenPriceQuery */.qI, {
    id: '0x0d500b1d8e8ef31e21c99d1db9a6444d3adf1270'
  });
};
const getAlcxPrice = async () => {
  // console.log('getAlcxPrice')
  return getTokenPrice(sdk_.ChainId.MAINNET, queries/* tokenPriceQuery */.qI, {
    id: '0xdbdb4d16eda451d0503b854cf79d55697f90c8df'
  });
};
const getSushiPrice = async () => {
  // console.log('getSushiPrice')
  return getTokenPrice(sdk_.ChainId.MAINNET, queries/* tokenPriceQuery */.qI, {
    id: '0x6b3595068778dd592e39a122f4f5a5cf09c90fe2'
  });
};
const getStakePrice = async () => {
  return getTokenPrice(sdk_.ChainId.XDAI, queries/* tokenPriceQuery */.qI, {
    id: '0xb7d311e2eb55f2f68a9440da38e7989210b9a05e'
  });
};
const getOnePrice = async () => {
  return getTokenPrice(sdk_.ChainId.HARMONY, queries/* tokenPriceQuery */.qI, {
    id: '0xcf664087a5bb0237a0bad6742852ec6c8d69a27a'
  });
};
const exchange_getBundle = async (chainId = sdk_.ChainId.MAINNET, query = queries/* ethPriceQuery */.B8, variables = {
  id: 1
}) => {
  return exchange_exchange(chainId, query, variables);
};
const exchange_getLiquidityPositions = async (chainId = ChainId.MAINNET, variables) => {
  const {
    liquidityPositions
  } = await exchange_exchange(chainId, liquidityPositionsQuery, variables);
  return liquidityPositions;
};
const getDayData = async (chainId = sdk_.ChainId.MAINNET, query = queries/* dayDatasQuery */.We, variables = undefined) => {
  const {
    dayDatas
  } = await exchange_exchange(chainId, query, variables);
  return dayDatas;
};
const getFactory = async (chainId = sdk_.ChainId.MAINNET, variables = undefined) => {
  const {
    factory
  } = await exchange_exchange(chainId, queries/* factoryQuery */.wY, variables);
  return factory;
};
const getTransactions = async (chainId = sdk_.ChainId.MAINNET, query = queries/* transactionsQuery */.ky, variables = undefined) => {
  const {
    swaps
  } = await exchange_exchange(chainId, query, variables);
  return swaps;
};
const getTokenPairs = async (chainId = sdk_.ChainId.MAINNET, query = queries/* tokenPairsQuery */.A, variables = undefined) => {
  const {
    pairs1,
    pairs2
  } = await exchange_exchange(chainId, query, variables);
  return pairs1 || pairs2 ? [...(pairs1 ? pairs1 : []), ...(pairs2 ? pairs2 : [])] : undefined;
};
;// CONCATENATED MODULE: ./src/services/graph/fetchers/masterchef.ts




const MINICHEF = {
  [sdk_.ChainId.MATIC]: 'sushiswap/matic-minichef',
  [sdk_.ChainId.XDAI]: 'matthewlilley/xdai-minichef',
  [sdk_.ChainId.HARMONY]: 'sushiswap/harmony-minichef'
};
const miniChef = async (query, chainId = sdk_.ChainId.MAINNET) => (0,external_graphql_request_.request)(`${constants_GRAPH_HOST[chainId]}/subgraphs/name/${MINICHEF[chainId]}`, query);
const MASTERCHEF_V2 = {
  [sdk_.ChainId.MAINNET]: 'jiro-ono/sushitestsubgraph'
};
const masterChefV2 = async (query, chainId = sdk_.ChainId.MAINNET) => (0,external_graphql_request_.request)(`${constants_GRAPH_HOST[chainId]}/subgraphs/name/${MASTERCHEF_V2[chainId]}`, query);
const MASTERCHEF_V1 = {
  [sdk_.ChainId.MAINNET]: 'sushiswap/master-chef'
};
const masterChefV1 = async (query, chainId = sdk_.ChainId.MAINNET) => (0,external_graphql_request_.request)(`${constants_GRAPH_HOST[chainId]}/subgraphs/name/${MASTERCHEF_V1[chainId]}`, query);
const getMasterChefV1TotalAllocPoint = async () => {
  const {
    masterChef: {
      totalAllocPoint
    }
  } = await masterChefV1(queries/* masterChefV1TotalAllocPointQuery */.ze);
  return totalAllocPoint;
};
const getMasterChefV1SushiPerBlock = async () => {
  const {
    masterChef: {
      sushiPerBlock
    }
  } = await masterChefV1(queries/* masterChefV1SushiPerBlockQuery */.r);
  return sushiPerBlock / 1e18;
};
const getMasterChefV1Farms = async () => {
  const {
    pools
  } = await masterChefV1(queries/* poolsQuery */.N_);
  return pools;
};
const getMasterChefV1PairAddreses = async () => {
  const {
    pools
  } = await masterChefV1(queries/* masterChefV1PairAddressesQuery */.oo);
  return pools;
};
const getMasterChefV2Farms = async () => {
  const {
    pools
  } = await masterChefV2(queries/* poolsV2Query */.z3);
  return pools;
};
const getMasterChefV2PairAddreses = async () => {
  const {
    pools
  } = await masterChefV2(queries/* masterChefV2PairAddressesQuery */.Wt);
  return pools;
};
const getMiniChefFarms = async (chainId = sdk_.ChainId.MAINNET) => {
  const {
    pools
  } = await miniChef(queries/* miniChefPoolsQuery */.dv, chainId);
  return pools;
};
const getMiniChefPairAddreses = async (chainId = sdk_.ChainId.MAINNET) => {
  console.debug('getMiniChefPairAddreses');
  const {
    pools
  } = await miniChef(queries/* miniChefPairAddressesQuery */.kG, chainId);
  return pools;
};
;// CONCATENATED MODULE: ./src/services/graph/fetchers/status.ts



const status_status = async (chainId = ChainId.MAINNET, subgraphName) => request(`${GRAPH_HOST[chainId]}/index-node/graphql`, `
        indexingStatusForCurrentVersion(subgraphName: "${subgraphName}") {
            synced
            health
            fatalError {
              message
              block {
                number
                hash
              }
              handler
            }
            chains {
              chainHeadBlock {
                number
              }
              latestBlock {
                number
              }
            }
          }
        `);
;// CONCATENATED MODULE: ./src/services/graph/fetchers/index.ts




// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: external "swr"
var external_swr_ = __webpack_require__(7749);
var external_swr_default = /*#__PURE__*/__webpack_require__.n(external_swr_);
// EXTERNAL MODULE: ./src/features/farm/enum.ts
var farm_enum = __webpack_require__(3553);
// EXTERNAL MODULE: external "lodash/concat"
var concat_ = __webpack_require__(7508);
var concat_default = /*#__PURE__*/__webpack_require__.n(concat_);
// EXTERNAL MODULE: ./src/hooks/useActiveWeb3React.ts
var hooks_useActiveWeb3React = __webpack_require__(8269);
// EXTERNAL MODULE: external "graphql-tag"
var external_graphql_tag_ = __webpack_require__(9875);
var external_graphql_tag_default = /*#__PURE__*/__webpack_require__.n(external_graphql_tag_);
;// CONCATENATED MODULE: ./src/services/graph/queries/bentobox.ts

const bentoTokenFieldsQuery = (external_graphql_tag_default())`
  fragment bentoTokenFields on Token {
    id
    # bentoBox
    name
    symbol
    decimals
    totalSupplyElastic
    totalSupplyBase
    block
    timestamp
  }
`;
const kashiPairFieldsQuery = (external_graphql_tag_default())`
  fragment kashiPairFields on KashiPair {
    id
    # bentoBox
    type
    masterContract
    owner
    feeTo
    name
    symbol
    oracle
    asset {
      ...bentoTokenFields
    }
    collateral {
      ...bentoTokenFields
    }
    exchangeRate
    totalAssetElastic
    totalAssetBase
    totalCollateralShare
    totalBorrowElastic
    totalBorrowBase
    interestPerSecond
    utilization
    feesEarnedFraction
    totalFeesEarnedFraction
    lastAccrued
    supplyAPR
    borrowAPR
    # transactions
    # users
    block
    timestamp
  }
  ${bentoTokenFieldsQuery}
`;
const kashiPairsQuery = (external_graphql_tag_default())`
  query kashiPairs(
    $skip: Int = 0
    $first: Int = 1000
    $where: KashiPair_filter
    $block: Block_height
    $orderBy: KashiPair_orderBy = "utilization"
    $orderDirection: OrderDirection! = "desc"
  ) {
    kashiPairs(
      skip: $skip
      first: $first
      where: $where
      block: $block
      orderBy: $orderBy
      orderDirection: $orderDirection
    ) {
      ...kashiPairFields
    }
  }
  ${kashiPairFieldsQuery}
`;
;// CONCATENATED MODULE: ./src/services/graph/fetchers/bentobox.ts
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






const BENTOBOX = {
  [sdk_.ChainId.MAINNET]: 'sushiswap/bentobox',
  [sdk_.ChainId.XDAI]: 'sushiswap/xdai-bentobox',
  [sdk_.ChainId.MATIC]: 'sushiswap/matic-bentobox',
  [sdk_.ChainId.FANTOM]: 'sushiswap/fantom-bentobox',
  [sdk_.ChainId.BSC]: 'sushiswap/bsc-bentobox'
};
const bentobox_fetcher = async (chainId = sdk_.ChainId.MAINNET, query, variables) => (0,external_graphql_request_.request)(`${constants_GRAPH_HOST[chainId]}/subgraphs/name/${BENTOBOX[chainId]}`, query);
const getKashiPairs = async (chainId = sdk_.ChainId.MAINNET, variables = undefined) => {
  const {
    kashiPairs
  } = await bentobox_fetcher(chainId, kashiPairsQuery, variables);
  const tokens = await getTokenSubset(chainId, {
    tokenAddresses: Array.from(kashiPairs.reduce((previousValue, currentValue) => previousValue.add(currentValue.asset.id, currentValue.collateral.id), new Set() // use set to avoid duplicates
    ))
  });
  return kashiPairs.map(pair => _objectSpread(_objectSpread({}, pair), {}, {
    token0: _objectSpread(_objectSpread({}, pair.asset), tokens.find(token => token.id === pair.asset.id)),
    token1: _objectSpread(_objectSpread({}, pair.collateral), tokens.find(token => token.id === pair.collateral.id))
  }));
};
// EXTERNAL MODULE: ./src/hooks/index.ts + 2 modules
var hooks = __webpack_require__(9202);
;// CONCATENATED MODULE: ./src/services/graph/hooks/bentobox.ts




function useKashiPairs(variables = undefined, swrConfig = undefined) {
  const {
    chainId
  } = (0,hooks/* useActiveWeb3React */.aQ)();
  const shouldFetch = chainId && (chainId === sdk_.ChainId.MAINNET || chainId === sdk_.ChainId.MATIC); // useEffect(() => {
  //   console.log('debug', { shouldFetch, chainId, pairAddresses })
  // }, [shouldFetch, chainId, pairAddresses])

  const {
    data
  } = external_swr_default()(shouldFetch ? () => ['kashiPairs', chainId, JSON.stringify(variables)] : null, (_, chainId) => getKashiPairs(chainId, variables), swrConfig);
  return data;
}
;// CONCATENATED MODULE: ./src/services/graph/hooks/blocks.ts



function useOneDayBlock(swrConfig = undefined) {
  const {
    chainId
  } = (0,hooks/* useActiveWeb3React */.aQ)();
  const {
    data
  } = external_swr_default()(chainId ? ['oneDayBlock', chainId] : null, (_, chainId) => getOneDayBlock(chainId), swrConfig);
  return data;
}
function useOneWeekBlock(swrConfig = undefined) {
  const {
    chainId
  } = (0,hooks/* useActiveWeb3React */.aQ)();
  const {
    data
  } = external_swr_default()(chainId ? ['oneWeekBlock', chainId] : null, (_, chainId) => getOneWeekBlock(chainId), swrConfig);
  return data;
}
function useCustomDayBlock(days, swrConfig = undefined) {
  const {
    chainId
  } = (0,hooks/* useActiveWeb3React */.aQ)();
  const {
    data
  } = external_swr_default()(chainId ? ['customDayBlock', chainId, days] : null, (_, chainId) => getCustomDayBlock(chainId, days), swrConfig);
  return data;
}
function useAverageBlockTime(swrConfig = undefined) {
  const {
    chainId
  } = (0,hooks/* useActiveWeb3React */.aQ)();
  const {
    data
  } = external_swr_default()(chainId ? ['averageBlockTime', chainId] : null, (_, chainId) => getAverageBlockTime(chainId), swrConfig);
  return data;
}
;// CONCATENATED MODULE: ./src/services/graph/hooks/exchange.ts






function useExchange(variables = undefined, query = undefined, swrConfig = undefined) {
  const {
    chainId
  } = useActiveWeb3React();
  const {
    data
  } = useSWR(chainId ? [chainId, query, JSON.stringify(variables)] : null, () => exchange(chainId, query, variables), swrConfig);
  return data;
}
function useFactory(variables = undefined, swrConfig = undefined) {
  const {
    chainId
  } = (0,hooks/* useActiveWeb3React */.aQ)();
  const {
    data
  } = external_swr_default()(chainId ? ['factory', chainId, JSON.stringify(variables)] : null, () => getFactory(chainId, variables), swrConfig);
  return data;
}
function useEthPrice(variables = undefined, swrConfig = undefined) {
  const {
    chainId
  } = (0,hooks/* useActiveWeb3React */.aQ)();
  const {
    data
  } = external_swr_default()(chainId ? ['ethPrice', JSON.stringify(variables)] : null, () => getEthPrice(chainId, variables), swrConfig);
  return data;
}
function useStakePrice(swrConfig = undefined) {
  const {
    chainId
  } = (0,hooks/* useActiveWeb3React */.aQ)();
  const shouldFetch = chainId && chainId === sdk_.ChainId.XDAI;
  const {
    data
  } = external_swr_default()(shouldFetch ? 'stakePrice' : null, () => getStakePrice(), swrConfig);
  return data;
}
function useOnePrice(swrConfig = undefined) {
  const {
    chainId
  } = (0,hooks/* useActiveWeb3React */.aQ)();
  const shouldFetch = chainId && chainId === sdk_.ChainId.HARMONY;
  const {
    data
  } = external_swr_default()(shouldFetch ? 'onePrice' : null, () => getOnePrice(), swrConfig);
  return data;
}
function useAlcxPrice(swrConfig = undefined) {
  const {
    chainId
  } = (0,hooks/* useActiveWeb3React */.aQ)();
  const {
    data
  } = external_swr_default()(chainId && chainId === sdk_.ChainId.MAINNET ? 'aclxPrice' : null, () => getAlcxPrice(), swrConfig);
  return data;
}
function useCvxPrice(swrConfig = undefined) {
  const {
    chainId
  } = (0,hooks/* useActiveWeb3React */.aQ)();
  const {
    data
  } = external_swr_default()(chainId && chainId === sdk_.ChainId.MAINNET ? 'cvxPrice' : null, () => getCvxPrice(), swrConfig);
  return data;
}
function useMaticPrice(swrConfig = undefined) {
  const {
    chainId
  } = (0,hooks/* useActiveWeb3React */.aQ)();
  const {
    data
  } = external_swr_default()(chainId && chainId === sdk_.ChainId.MATIC ? 'maticPrice' : null, () => getMaticPrice(), swrConfig);
  return data;
}
function useSushiPrice(swrConfig = undefined) {
  const {
    data
  } = external_swr_default()('sushiPrice', () => getSushiPrice(), swrConfig);
  return data;
}
function useBundle(variables = undefined, swrConfig = undefined) {
  const {
    chainId
  } = useActiveWeb3React();
  const {
    data
  } = useSWR(chainId ? [chainId, ethPriceQuery, JSON.stringify(variables)] : null, () => getBundle(), swrConfig);
  return data;
}
function useLiquidityPositions(variables = undefined, swrConfig = undefined) {
  const {
    chainId
  } = useActiveWeb3React();
  const shouldFetch = chainId;
  const {
    data
  } = useSWR(shouldFetch ? ['liquidityPositions', chainId, JSON.stringify(variables)] : null, (_, chainId) => getLiquidityPositions(chainId, variables), swrConfig);
  return data;
}
function useSushiPairs(variables = undefined, query = undefined, swrConfig = undefined) {
  const {
    chainId
  } = (0,hooks/* useActiveWeb3React */.aQ)();
  const shouldFetch = chainId;
  const {
    data
  } = external_swr_default()(shouldFetch ? ['sushiPairs', chainId, JSON.stringify(variables)] : null, (_, chainId) => getPairs(chainId, variables, query), swrConfig);
  return data;
}
function useTokens(variables = undefined, query = undefined, swrConfig = undefined) {
  const {
    chainId
  } = (0,hooks/* useActiveWeb3React */.aQ)();
  const shouldFetch = chainId;
  const {
    data
  } = external_swr_default()(shouldFetch ? ['tokens', chainId, query, JSON.stringify(variables)] : null, (_, chainId) => getTokens(chainId, query, variables), swrConfig);
  return data;
}
function useToken(variables, query = undefined, swrConfig = undefined) {
  const {
    chainId
  } = (0,hooks/* useActiveWeb3React */.aQ)();
  const shouldFetch = chainId;
  const {
    data
  } = external_swr_default()(shouldFetch ? ['token', chainId, query, JSON.stringify(variables)] : null, (_, chainId) => getToken(chainId, query, variables), swrConfig);
  return data;
}
function useDayData(variables = undefined, query = undefined, swrConfig = undefined) {
  const {
    chainId
  } = (0,hooks/* useActiveWeb3React */.aQ)();
  const shouldFetch = chainId;
  const {
    data
  } = external_swr_default()(shouldFetch ? ['dayData', chainId, query, JSON.stringify(variables)] : null, (_, chainId) => getDayData(chainId, query, variables), swrConfig);
  return data;
}
function useTransactions(variables = undefined, query = undefined, swrConfig = undefined) {
  const {
    chainId
  } = (0,hooks/* useActiveWeb3React */.aQ)();
  const shouldFetch = chainId;
  const {
    data
  } = external_swr_default()(shouldFetch ? ['transactions', chainId, query, JSON.stringify(variables)] : null, (_, chainId) => getTransactions(chainId, query, variables), swrConfig);
  return data;
}
function useTokenPairs(variables = undefined, query = undefined, swrConfig = undefined) {
  const {
    chainId
  } = (0,hooks/* useActiveWeb3React */.aQ)();
  const shouldFetch = chainId;
  const {
    data
  } = external_swr_default()(shouldFetch ? ['tokenPairs', chainId, query, JSON.stringify(variables)] : null, (_, chainId) => getTokenPairs(chainId, query, variables), swrConfig);
  return data;
}
;// CONCATENATED MODULE: ./src/services/graph/hooks/index.ts
function hooks_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function hooks_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { hooks_ownKeys(Object(source), true).forEach(function (key) { hooks_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { hooks_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function hooks_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }











function useMasterChefV1TotalAllocPoint(swrConfig = undefined) {
  const {
    chainId
  } = (0,hooks_useActiveWeb3React/* default */.Z)();
  const shouldFetch = chainId && chainId === sdk_.ChainId.MAINNET;
  const {
    data
  } = external_swr_default()(shouldFetch ? 'masterChefV1TotalAllocPoint' : null, () => getMasterChefV1TotalAllocPoint(), swrConfig);
  return data;
}
function useMasterChefV1SushiPerBlock(swrConfig = undefined) {
  const {
    chainId
  } = (0,hooks_useActiveWeb3React/* default */.Z)();
  const shouldFetch = chainId && chainId === sdk_.ChainId.MAINNET;
  const {
    data
  } = external_swr_default()(shouldFetch ? 'masterChefV1SushiPerBlock' : null, () => getMasterChefV1SushiPerBlock(), swrConfig);
  return data;
}
function useMasterChefV1Farms(swrConfig = undefined) {
  const {
    chainId
  } = (0,hooks_useActiveWeb3React/* default */.Z)();
  const shouldFetch = chainId && chainId === sdk_.ChainId.MAINNET;
  const {
    data
  } = external_swr_default()(shouldFetch ? 'masterChefV1Farms' : null, () => getMasterChefV1Farms(), swrConfig);
  return (0,external_react_.useMemo)(() => {
    if (!data) return [];
    return data.map(data => hooks_objectSpread(hooks_objectSpread({}, data), {}, {
      chef: farm_enum/* Chef.MASTERCHEF */.WJ.MASTERCHEF
    }));
  }, [data]);
}
function useMasterChefV2Farms(swrConfig = undefined) {
  const {
    chainId
  } = (0,hooks_useActiveWeb3React/* default */.Z)();
  const shouldFetch = chainId && chainId === sdk_.ChainId.MAINNET;
  const {
    data
  } = external_swr_default()(shouldFetch ? 'masterChefV2Farms' : null, () => getMasterChefV2Farms(), swrConfig);
  return (0,external_react_.useMemo)(() => {
    if (!data) return [];
    return data.map(data => hooks_objectSpread(hooks_objectSpread({}, data), {}, {
      chef: farm_enum/* Chef.MASTERCHEF_V2 */.WJ.MASTERCHEF_V2
    }));
  }, [data]);
}
function useMiniChefFarms(swrConfig = undefined) {
  const {
    chainId
  } = (0,hooks_useActiveWeb3React/* default */.Z)();
  const shouldFetch = chainId && [sdk_.ChainId.MATIC, sdk_.ChainId.XDAI, sdk_.ChainId.HARMONY].includes(chainId);
  const {
    data
  } = external_swr_default()(shouldFetch ? ['miniChefFarms', chainId] : null, (_, chainId) => getMiniChefFarms(chainId), swrConfig);
  return (0,external_react_.useMemo)(() => {
    if (!data) return [];
    return data.map(data => hooks_objectSpread(hooks_objectSpread({}, data), {}, {
      chef: farm_enum/* Chef.MINICHEF */.WJ.MINICHEF
    }));
  }, [data]);
}
function useFarms(swrConfig = undefined) {
  const masterChefV1Farms = useMasterChefV1Farms();
  const masterChefV2Farms = useMasterChefV2Farms();
  const miniChefFarms = useMiniChefFarms(); // useEffect(() => {
  //   console.log('debug', { masterChefV1Farms, masterChefV2Farms, miniChefFarms })
  // }, [masterChefV1Farms, masterChefV2Farms, miniChefFarms])

  return (0,external_react_.useMemo)(() => concat_default()(masterChefV1Farms, masterChefV2Farms, miniChefFarms).filter(pool => pool && pool.pair), [masterChefV1Farms, masterChefV2Farms, miniChefFarms]);
}
function useMasterChefV1PairAddresses() {
  const {
    chainId
  } = (0,hooks_useActiveWeb3React/* default */.Z)();
  const shouldFetch = chainId && chainId === sdk_.ChainId.MAINNET;
  const {
    data
  } = external_swr_default()(shouldFetch ? ['masterChefV1PairAddresses', chainId] : null, _ => getMasterChefV1PairAddreses());
  return (0,external_react_.useMemo)(() => {
    if (!data) return [];
    return data.map(data => data.pair);
  }, [data]);
}
function useMasterChefV2PairAddresses() {
  const {
    chainId
  } = (0,hooks_useActiveWeb3React/* default */.Z)();
  const shouldFetch = chainId && chainId === sdk_.ChainId.MAINNET;
  const {
    data
  } = external_swr_default()(shouldFetch ? ['masterChefV2PairAddresses', chainId] : null, _ => getMasterChefV2PairAddreses());
  return (0,external_react_.useMemo)(() => {
    if (!data) return [];
    return data.map(data => data.pair);
  }, [data]);
}
function useMiniChefPairAddresses() {
  const {
    chainId
  } = (0,hooks_useActiveWeb3React/* default */.Z)();
  const shouldFetch = chainId && [sdk_.ChainId.MATIC, sdk_.ChainId.XDAI, sdk_.ChainId.HARMONY].includes(chainId);
  const {
    data
  } = external_swr_default()(shouldFetch ? ['miniChefPairAddresses', chainId] : null, (_, chainId) => getMiniChefPairAddreses(chainId));
  return (0,external_react_.useMemo)(() => {
    if (!data) return [];
    return data.map(data => data.pair);
  }, [data]);
}
function useFarmPairAddresses() {
  const masterChefV1PairAddresses = useMasterChefV1PairAddresses();
  const masterChefV2PairAddresses = useMasterChefV2PairAddresses();
  const miniChefPairAddresses = useMiniChefPairAddresses();
  return (0,external_react_.useMemo)(() => concat_default()(masterChefV1PairAddresses, masterChefV2PairAddresses, miniChefPairAddresses), [masterChefV1PairAddresses, masterChefV2PairAddresses, miniChefPairAddresses]);
}
;// CONCATENATED MODULE: ./src/services/graph/index.ts



/***/ }),

/***/ 4068:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "LG": function() { return /* reexport */ blocksQuery; },
  "We": function() { return /* reexport */ dayDatasQuery; },
  "B8": function() { return /* reexport */ ethPriceQuery; },
  "wY": function() { return /* reexport */ factoryQuery; },
  "oo": function() { return /* reexport */ masterChefV1PairAddressesQuery; },
  "r": function() { return /* reexport */ masterChefV1SushiPerBlockQuery; },
  "ze": function() { return /* reexport */ masterChefV1TotalAllocPointQuery; },
  "Wt": function() { return /* reexport */ masterChefV2PairAddressesQuery; },
  "kG": function() { return /* reexport */ miniChefPairAddressesQuery; },
  "dv": function() { return /* reexport */ miniChefPoolsQuery; },
  "aS": function() { return /* reexport */ pairsQuery; },
  "N_": function() { return /* reexport */ poolsQuery; },
  "z3": function() { return /* reexport */ poolsV2Query; },
  "KB": function() { return /* reexport */ tokenDayDatasQuery; },
  "A": function() { return /* reexport */ tokenPairsQuery; },
  "qI": function() { return /* reexport */ tokenPriceQuery; },
  "Pd": function() { return /* reexport */ tokenQuery; },
  "Zg": function() { return /* reexport */ tokenSubsetQuery; },
  "zz": function() { return /* reexport */ tokensQuery; },
  "ky": function() { return /* reexport */ transactionsQuery; }
});

// UNUSED EXPORTS: blockQuery, bundleFields, dayDataFieldsQuery, ethPriceTimeTravelQuery, liquidityPositionsQuery, pairCountQuery, pairDayDatasQuery, pairFieldsQuery, pairIdsQuery, pairQuery, pairTimeTravelQuery, pairsTimeTravelQuery, tokenFieldsQuery, tokenIdsQuery, tokenTimeTravelQuery, tokensTimeTravelQuery, uniswapUserQuery, userIdsQuery

// EXTERNAL MODULE: external "graphql-tag"
var external_graphql_tag_ = __webpack_require__(9875);
var external_graphql_tag_default = /*#__PURE__*/__webpack_require__.n(external_graphql_tag_);
;// CONCATENATED MODULE: ./src/services/graph/queries/blocks.ts

const blockFieldsQuery = (external_graphql_tag_default())`
  fragment blockFields on Block {
    id
    number
    timestamp
  }
`;
const blockQuery = (external_graphql_tag_default())`
  query blockQuery($start: Int!, $end: Int!) {
    blocks(first: 1, orderBy: timestamp, orderDirection: asc, where: { timestamp_gt: $start, timestamp_lt: $end }) {
      ...blockFields
    }
  }
  ${blockFieldsQuery}
`;
const blocksQuery = (external_graphql_tag_default())`
  query blocksQuery($first: Int! = 1000, $skip: Int! = 0, $start: Int!, $end: Int!) {
    blocks(
      first: $first
      skip: $skip
      orderBy: number
      orderDirection: desc
      where: { timestamp_gt: $start, timestamp_lt: $end }
    ) {
      ...blockFields
    }
  }
  ${blockFieldsQuery}
`;
;// CONCATENATED MODULE: ./src/services/graph/queries/exchange.ts

const factoryQuery = (external_graphql_tag_default())`
  query factoryQuery($id: String! = "0xc0aee478e3658e2610c5f7a4a2e1777ce9e4f2ac", $block: Block_height) {
    factory(id: $id, block: $block) {
      id
      volumeUSD
      liquidityUSD
    }
  }
`;
const userIdsQuery = (external_graphql_tag_default())`
  query userIdsQuery($first: Int! = 1000, $skip: Int! = 0) {
    users(first: $first, skip: $skip) {
      id
    }
  }
`;
const uniswapUserQuery = (external_graphql_tag_default())`
  query uniswapUserQuery($id: String!) {
    uniswapUser: user(id: $id) {
      id
      liquidityPositions {
        id
        liquidityTokenBalance
        # historicalSnapshots {
        #   id
        #   reserve0
        #   reserve1
        #   block
        #   timestamp
        #   liquidityTokenBalance
        #   liquidityTokenTotalSupply
        # }
      }
    }
  }
`;
const bundleFields = (external_graphql_tag_default())`
  fragment bundleFields on Bundle {
    id
    ethPrice
  }
`;
const ethPriceQuery = (external_graphql_tag_default())`
  query ethPriceQuery($id: Int! = 1, $block: Block_height) {
    bundles(id: $id, block: $block) {
      ...bundleFields
    }
  }
  ${bundleFields}
`;
const ethPriceTimeTravelQuery = (external_graphql_tag_default())`
  query ethPriceTimeTravelQuery($id: Int! = 1, $block: Block_height!) {
    bundles(id: $id, block: $block) {
      ...bundleFields
    }
  }
  ${bundleFields}
`;
const tokenPriceQuery = (external_graphql_tag_default())`
  query tokenPriceQuery($id: String!) {
    token(id: $id) {
      id
      derivedETH
    }
  }
`;
const dayDataFieldsQuery = (external_graphql_tag_default())`
  fragment dayDataFields on DayData {
    id
    date
    volumeETH
    volumeUSD
    untrackedVolume
    liquidityETH
    liquidityUSD
    txCount
  }
`; // Dashboard...

const dayDatasQuery = (external_graphql_tag_default())`
  query dayDatasQuery($first: Int! = 1000, $date: Int! = 0, $where: DayData_filter) {
    dayDatas(first: $first, orderBy: date, orderDirection: desc, where: $where) {
      ...dayDataFields
    }
  }
  ${dayDataFieldsQuery}
`; // Pairs...

const pairFieldsQuery = (external_graphql_tag_default())`
  fragment pairFields on Pair {
    id
    reserveUSD
    reserveETH
    volumeUSD
    untrackedVolumeUSD
    trackedReserveETH
    token0 {
      ...PairToken
    }
    token1 {
      ...PairToken
    }
    reserve0
    reserve1
    token0Price
    token1Price
    totalSupply
    txCount
    timestamp
  }
  fragment PairToken on Token {
    id
    name
    symbol
    totalSupply
    derivedETH
  }
`;
const pairQuery = (external_graphql_tag_default())`
  query pairQuery($id: String!) {
    pair(id: $id) {
      ...pairFields
    }
  }
  ${pairFieldsQuery}
`;
const pairTimeTravelQuery = (external_graphql_tag_default())`
  query pairTimeTravelQuery($id: String!, $block: Block_height!) {
    pair(id: $id, block: $block) {
      ...pairFields
    }
  }
  ${pairFieldsQuery}
`;
const pairIdsQuery = (external_graphql_tag_default())`
  query pairIdsQuery {
    pairs(first: 1000) {
      id
    }
  }
`;
const pairCountQuery = (external_graphql_tag_default())`
  query pairCountQuery {
    uniswapFactories {
      pairCount
    }
  }
`;
const pairDayDatasQuery = (external_graphql_tag_default())`
  query pairDayDatasQuery($first: Int = 1000, $date: Int = 0, $pairs: [Bytes]!) {
    pairDayDatas(first: $first, orderBy: date, orderDirection: desc, where: { pair_in: $pairs, date_gt: $date }) {
      date
      pair {
        id
      }
      token0 {
        derivedETH
      }
      token1 {
        derivedETH
      }
      reserveUSD
      volumeToken0
      volumeToken1
      volumeUSD
      txCount
    }
  }
`;
const liquidityPositionsQuery = (external_graphql_tag_default())`
  query liquidityPositionSubsetQuery($first: Int! = 1000, $where: LiquidityPosition_filter) {
    liquidityPositions(first: $first, where: $where) {
      id
      liquidityTokenBalance
      user {
        id
      }
      pair {
        id
      }
    }
  }
`;
const pairsQuery = (external_graphql_tag_default())`
  query pair(
    $skip: Int = 0
    $first: Int = 1000
    $where: Pair_filter
    $block: Block_height
    $orderBy: Pair_orderBy = "trackedReserveETH"
    $orderDirection: OrderDirection = "desc"
  ) {
    pairs(
      skip: $skip
      first: $first
      orderBy: $orderBy
      orderDirection: $orderDirection
      block: $block
      where: $where
    ) {
      ...pairFields
    }
  }
  ${pairFieldsQuery}
`;
const pairsTimeTravelQuery = (external_graphql_tag_default())`
  query pairsTimeTravelQuery($first: Int! = 1000, $pairAddresses: [Bytes]!, $block: Block_height!) {
    pairs(
      first: $first
      block: $block
      orderBy: trackedReserveETH
      orderDirection: desc
      where: { id_in: $pairAddresses }
    ) {
      id
      reserveUSD
      trackedReserveETH
      volumeUSD
      untrackedVolumeUSD
      txCount
    }
  }
`; // Tokens...

const tokenFieldsQuery = (external_graphql_tag_default())`
  fragment tokenFields on Token {
    id
    symbol
    name
    decimals
    totalSupply
    volume
    volumeUSD
    untrackedVolumeUSD
    txCount
    liquidity
    derivedETH
  }
`;
const tokenQuery = (external_graphql_tag_default())`
  query tokenQuery($id: String!, $block: Block_height) {
    token(id: $id, block: $block) {
      ...tokenFields
    }
  }
  ${tokenFieldsQuery}
`;
const tokenTimeTravelQuery = (external_graphql_tag_default())`
  query tokenTimeTravelQuery($id: String!, $block: Block_height!) {
    token(id: $id, block: $block) {
      ...tokenFields
    }
  }
  ${tokenFieldsQuery}
`;
const tokenIdsQuery = (external_graphql_tag_default())`
  query tokenIdsQuery {
    tokens(first: 1000) {
      id
    }
  }
`;
const tokenDayDatasQuery = (external_graphql_tag_default())`
  query tokenDayDatasQuery($first: Int! = 1000, $tokens: [Bytes]!, $date: Int! = 0) {
    tokenDayDatas(first: $first, orderBy: date, orderDirection: desc, where: { token_in: $tokens, date_gt: $date }) {
      id
      date
      token {
        id
      }
      volumeUSD
      liquidityUSD
      priceUSD
      txCount
    }
  }
`;
const tokenPairsQuery = (external_graphql_tag_default())`
  query tokenPairsQuery($id: String!) {
    pairs0: pairs(first: 1000, orderBy: reserveUSD, orderDirection: desc, where: { token0: $id }) {
      ...pairFields
    }
    pairs1: pairs(first: 1000, orderBy: reserveUSD, orderDirection: desc, where: { token1: $id }) {
      ...pairFields
    }
  }
  ${pairFieldsQuery}
`;
const tokensQuery = (external_graphql_tag_default())`
  query tokensQuery($first: Int! = 1000, $block: Block_height) {
    tokens(first: $first, orderBy: volumeUSD, orderDirection: desc, block: $block) {
      ...tokenFields
      dayData(first: 7, skip: 0, orderBy: date, order: asc) {
        id
        priceUSD
      }
      # hourData(first: 168, skip: 0, orderBy: date, order: asc) {
      #   priceUSD
      # }
    }
  }
  ${tokenFieldsQuery}
`;
const tokenSubsetQuery = (external_graphql_tag_default())`
  query tokenSubsetQuery(
    $first: Int! = 1000
    $tokenAddresses: [Bytes]!
    $orderBy: String! = "id"
    $orderDirection: String! = "desc"
  ) {
    tokens(first: $first, orderBy: $orderBy, orderDirection: $orderDirection, where: { id_in: $tokenAddresses }) {
      ...tokenFields
    }
  }
  ${tokenFieldsQuery}
`;
const tokensTimeTravelQuery = (external_graphql_tag_default())`
  query tokensTimeTravelQuery($first: Int! = 1000, $block: Block_height!) {
    tokens(first: $first, block: $block) {
      ...tokenFields
    }
  }
  ${tokenFieldsQuery}
`; // Transactions...

const transactionsQuery = (external_graphql_tag_default())`
  query transactionsQuery($pairAddresses: [Bytes]!) {
    swaps(orderBy: timestamp, orderDirection: desc, where: { pair_in: $pairAddresses }) {
      id
      timestamp
      pair {
        token0 {
          symbol
        }
        token1 {
          symbol
        }
      }
      sender
      amount0In
      amount0Out
      amount1In
      amount1Out
      amountUSD
      to
    }
    mints(orderBy: timestamp, orderDirection: desc, where: { pair_in: $pairAddresses }) {
      id
      timestamp
      pair {
        token0 {
          symbol
        }
        token1 {
          symbol
        }
      }
      sender
      amount0
      amount1
      amountUSD
      to
    }
    burns(orderBy: timestamp, orderDirection: desc, where: { pair_in: $pairAddresses }) {
      id
      timestamp
      pair {
        token0 {
          symbol
        }
        token1 {
          symbol
        }
      }
      sender
      amount0
      amount1
      amountUSD
      to
    }
  }
`;
;// CONCATENATED MODULE: ./src/services/graph/queries/masterchef.ts

const poolsQuery = (external_graphql_tag_default())`
  query poolsQuery(
    $first: Int! = 1000
    $skip: Int! = 0
    $orderBy: String! = "id"
    $orderDirection: String! = "desc"
    $where: Pool_filter! = { allocPoint_gt: 0, accSushiPerShare_gt: 0 }
  ) {
    pools(first: $first, skip: $skip, orderBy: $orderBy, orderDirection: $orderDirection, where: $where) {
      id
      pair
      allocPoint
      lastRewardBlock
      accSushiPerShare
      balance
      userCount
      owner {
        id
        sushiPerBlock
        totalAllocPoint
      }
    }
  }
`;
const masterChefV1PairAddressesQuery = (external_graphql_tag_default())`
  query masterChefV1PairAddresses(
    $first: Int! = 1000
    $skip: Int! = 0
    $orderBy: String! = "id"
    $orderDirection: String! = "desc"
    $where: Pool_filter! = { allocPoint_gt: 0, accSushiPerShare_gt: 0 }
  ) {
    pools(first: $first, skip: $skip, orderBy: $orderBy, orderDirection: $orderDirection, where: $where) {
      id
      allocPoint
      accSushiPerShare
      pair {
        id
      }
    }
  }
`;
const masterChefV1TotalAllocPointQuery = (external_graphql_tag_default())`
  query masterChefV1TotalAllocPoint($id: String! = "0xc2edad668740f1aa35e4d8f227fb8e17dca888cd") {
    masterChef(id: $id) {
      id
      totalAllocPoint
    }
  }
`;
const masterChefV1SushiPerBlockQuery = (external_graphql_tag_default())`
  query masterChefV1SushiPerBlock($id: String! = "0xc2edad668740f1aa35e4d8f227fb8e17dca888cd") {
    masterChef(id: $id) {
      id
      sushiPerBlock
    }
  }
`;
;// CONCATENATED MODULE: ./src/services/graph/queries/masterchef-v2.ts

const poolsV2Query = (external_graphql_tag_default())`
  query poolsV2Query(
    $first: Int! = 1000
    $skip: Int! = 0
    $orderBy: String! = "id"
    $orderDirection: String! = "desc"
    $where: Pool_filter! = { allocPoint_gt: 0, accSushiPerShare_gt: 0 }
  ) {
    pools(first: $first, skip: $skip, orderBy: $orderBy, orderDirection: $orderDirection, where: $where) {
      id
      pair
      allocPoint
      slpBalance
      masterChef {
        id
        totalAllocPoint
      }
      rewarder {
        id
        rewardToken
        rewardPerBlock
      }
    }
  }
`;
const masterChefV2PairAddressesQuery = (external_graphql_tag_default())`
  query masterChefV2PairAddresses(
    $first: Int! = 1000
    $skip: Int! = 0
    $orderBy: String! = "id"
    $orderDirection: String! = "desc"
    $where: Pool_filter! = { allocPoint_gt: 0, accSushiPerShare_gt: 0 }
  ) {
    pools(first: $first, skip: $skip, orderBy: $orderBy, orderDirection: $orderDirection, where: $where) {
      id
      allocPoint
      accSushiPerShare
      pair {
        id
      }
    }
  }
`;
;// CONCATENATED MODULE: ./src/services/graph/queries/minichef.ts

const miniChefPoolsQuery = (external_graphql_tag_default())`
  query miniChefPoolsQuery(
    $first: Int! = 1000
    $skip: Int! = 0
    $orderBy: String! = "id"
    $orderDirection: String! = "desc"
    $where: Pool_filter! = { allocPoint_gt: 0, accSushiPerShare_gt: 0 }
  ) {
    pools(first: $first, skip: $skip, orderBy: $orderBy, orderDirection: $orderDirection, where: $where) {
      id
      pair
      rewarder {
        id
        rewardToken
        rewardPerSecond
      }
      allocPoint
      lastRewardTime
      accSushiPerShare
      slpBalance
      userCount
      miniChef {
        id
        sushiPerSecond
        totalAllocPoint
      }
    }
  }
`;
const miniChefPairAddressesQuery = (external_graphql_tag_default())`
  query miniChefPairAddresses(
    $first: Int! = 1000
    $skip: Int! = 0
    $orderBy: String! = "id"
    $orderDirection: String! = "desc"
    $where: Pool_filter! = { allocPoint_gt: 0, accSushiPerShare_gt: 0 }
  ) {
    pools(first: $first, skip: $skip, orderBy: $orderBy, orderDirection: $orderDirection, where: $where) {
      id
      allocPoint
      accSushiPerShare
      pair {
        id
      }
    }
  }
`;
;// CONCATENATED MODULE: ./src/services/graph/queries/index.ts






/***/ })

};
;