exports.id = 3106;
exports.ids = [3106];
exports.modules = {

/***/ 3106:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_ga__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9831);
/* harmony import */ var react_ga__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_ga__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _functions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7735);


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }




const COLOR = {
  default: 'text-primary hover:text-high-emphesis focus:text-high-emphesis',
  blue: 'text-blue opacity-80 hover:opacity-100 focus:opacity-100'
};

const ExternalLink = (_ref) => {
  let {
    target = '_blank',
    href,
    children,
    rel = 'noopener noreferrer',
    className = '',
    color = 'default',
    startIcon = undefined,
    endIcon = undefined
  } = _ref,
      rest = _objectWithoutProperties(_ref, ["target", "href", "children", "rel", "className", "color", "startIcon", "endIcon"]);

  const handleClick = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(event => {
    // don't prevent default, don't redirect if it's a new tab
    if (target === '_blank' || event.ctrlKey || event.metaKey) {
      react_ga__WEBPACK_IMPORTED_MODULE_2___default().outboundLink({
        label: href
      }, () => {
        console.debug('Fired outbound link event', href);
      });
    } else {
      event.preventDefault(); // send a ReactGA event and then trigger a location change

      react_ga__WEBPACK_IMPORTED_MODULE_2___default().outboundLink({
        label: href
      }, () => {
        window.location.href = href;
      });
    }
  }, [href, target]);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", _objectSpread(_objectSpread({
    target: target,
    rel: rel,
    href: href,
    onClick: handleClick,
    className: (0,_functions__WEBPACK_IMPORTED_MODULE_3__/* .classNames */ .AK)('text-baseline whitespace-nowrap', COLOR[color], (startIcon || endIcon) && 'space-x-1 flex items-center justify-center', className)
  }, rest), {}, {
    children: [startIcon && startIcon, children, endIcon && endIcon]
  }));
};

/* harmony default export */ __webpack_exports__["Z"] = (ExternalLink);

/***/ })

};
;