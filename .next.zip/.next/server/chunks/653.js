exports.id = 653;
exports.ids = [653];
exports.modules = {

/***/ 8561:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9914);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const Dots = styled_components__WEBPACK_IMPORTED_MODULE_0___default().span.withConfig({
  displayName: "Dots",
  componentId: "sc-1wyu7py-0"
})(["&::after{display:inline-block;animation:ellipsis 1.25s infinite;content:'.';width:1em;text-align:left;}@keyframes ellipsis{0%{content:'.';}33%{content:'..';}66%{content:'...';}}"]);
/* harmony default export */ __webpack_exports__["Z"] = (Dots);

/***/ }),

/***/ 4509:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": function() { return /* binding */ components_Footer; }
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
// EXTERNAL MODULE: ./src/constants/index.ts
var constants = __webpack_require__(8532);
// EXTERNAL MODULE: external "@sushiswap/sdk"
var sdk_ = __webpack_require__(6766);
// EXTERNAL MODULE: ./src/components/ExternalLink/index.tsx
var ExternalLink = __webpack_require__(3106);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./src/functions/explorer.ts
var explorer = __webpack_require__(3302);
// EXTERNAL MODULE: ./src/hooks/useActiveWeb3React.ts
var useActiveWeb3React = __webpack_require__(8269);
// EXTERNAL MODULE: ./src/state/application/hooks.ts
var hooks = __webpack_require__(4663);
;// CONCATENATED MODULE: ./src/components/Polling.tsx







function Polling() {
  const {
    chainId
  } = (0,useActiveWeb3React/* useActiveWeb3React */.a)();
  const blockNumber = (0,hooks/* useBlockNumber */.Ov)();
  const {
    0: isMounted,
    1: setIsMounted
  } = (0,external_react_.useState)(true);
  (0,external_react_.useEffect)(() => {
    const timer1 = setTimeout(() => setIsMounted(true), 1000); // this will clear Timeout when component unmount like in willComponentUnmount

    return () => {
      setIsMounted(false);
      clearTimeout(timer1);
    };
  }, [blockNumber] // useEffect will run only one time
  // if you pass a value to array, like this [data] than clearTimeout will run every time this value changes (useEffect re-run)
  );
  return /*#__PURE__*/jsx_runtime_.jsx(ExternalLink/* default */.Z, {
    href: chainId && blockNumber ? (0,explorer/* getExplorerLink */.E)(chainId, blockNumber.toString(), 'block') : '',
    className: `${!isMounted ? 'text-high-emphesis' : 'text-low-emphesis'}`,
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: `flex items-center space-x-2`,
      children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
        children: blockNumber
      }), /*#__PURE__*/jsx_runtime_.jsx("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        className: `h-6 w-6 ${!isMounted ? 'animate-spin' : ''}`,
        fill: "none",
        viewBox: "0 0 24 24",
        stroke: "currentColor",
        children: /*#__PURE__*/jsx_runtime_.jsx("path", {
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: "2",
          d: "M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"
        })
      })]
    })
  });
}
// EXTERNAL MODULE: external "@lingui/react"
var react_ = __webpack_require__(2339);
;// CONCATENATED MODULE: ./src/components/Footer/index.tsx









const Footer = () => {
  const {
    chainId
  } = (0,useActiveWeb3React/* default */.Z)();
  const {
    i18n
  } = (0,react_.useLingui)();
  return (
    /*#__PURE__*/
    // <footer className="absolute bottom-0 flex items-center justify-between w-screen h-20 p-4 mx-auto text-center text-low-emphesis">
    jsx_runtime_.jsx("footer", {
      className: "flex-shrink-0 w-full",
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex items-center justify-between h-20 px-4",
        children: [chainId && chainId in constants/* ANALYTICS_URL */.fi && /*#__PURE__*/jsx_runtime_.jsx(ExternalLink/* default */.Z, {
          id: `analytics-nav-link`,
          href: constants/* ANALYTICS_URL */.fi[chainId] || 'https://analytics.sushi.com',
          className: "text-low-emphesis",
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "flex items-center space-x-2",
            children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
              children: i18n._(
              /*i18n*/
              i18n._("Analytics"))
            }), /*#__PURE__*/jsx_runtime_.jsx("svg", {
              xmlns: "http://www.w3.org/2000/svg",
              className: "w-6 h-6",
              fill: "none",
              viewBox: "0 0 24 24",
              stroke: "currentColor",
              children: /*#__PURE__*/jsx_runtime_.jsx("path", {
                strokeLinecap: "round",
                strokeLinejoin: "round",
                strokeWidth: "2",
                d: "M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"
              })
            })]
          })
        }), chainId && chainId === sdk_.ChainId.MATIC && /*#__PURE__*/jsx_runtime_.jsx(ExternalLink/* default */.Z, {
          id: `polygon-bridge-link`,
          href: "https://wallet.matic.network/bridge/",
          className: "text-low-emphesis",
          children: i18n._(
          /*i18n*/
          i18n._("Matic Bridge"))
        }), chainId && chainId === sdk_.ChainId.HARMONY && /*#__PURE__*/jsx_runtime_.jsx(ExternalLink/* default */.Z, {
          id: `harmony-bridge-link`,
          href: " https://bridge.harmony.one/tokens",
          className: "text-low-emphesis",
          children: i18n._(
          /*i18n*/
          i18n._("Harmony Bridge"))
        }), /*#__PURE__*/jsx_runtime_.jsx(Polling, {})]
      })
    })
  );
};

/* harmony default export */ var components_Footer = (Footer);

/***/ }),

/***/ 9282:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": function() { return /* binding */ Header; }
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
// EXTERNAL MODULE: external "@sushiswap/sdk"
var sdk_ = __webpack_require__(6766);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./src/constants/index.ts
var constants = __webpack_require__(8532);
// EXTERNAL MODULE: ./src/components/ExternalLink/index.tsx
var ExternalLink = __webpack_require__(3106);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: external "@lingui/core"
var core_ = __webpack_require__(7421);
// EXTERNAL MODULE: external "@headlessui/react"
var react_ = __webpack_require__(4025);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/solid/esm/index.js + 230 modules
var esm = __webpack_require__(3802);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./src/functions/index.ts
var functions = __webpack_require__(7735);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(6731);
;// CONCATENATED MODULE: ./src/components/LanguageSwitch/index.tsx











const LANGUAGES = {
  en: {
    flag: '/images/flags/en-flag.png',
    language:
    /*i18n*/
    core_.i18n._("English")
  },
  de: {
    flag: '/images/flags/de-flag.png',
    language:
    /*i18n*/
    core_.i18n._("German")
  },
  it: {
    flag: '/images/flags/it-flag.png',
    language:
    /*i18n*/
    core_.i18n._("Italian")
  },
  ru: {
    flag: '/images/flags/ru-flag.png',
    language:
    /*i18n*/
    core_.i18n._("Russian")
  },
  ro: {
    flag: '/images/flags/ro-flag.png',
    language:
    /*i18n*/
    core_.i18n._("Romanian")
  },
  vi: {
    flag: '/images/flags/vi-flag.png',
    language:
    /*i18n*/
    core_.i18n._("Vietnamese")
  },
  'zh-CN': {
    flag: '/images/flags/ch-flag.png',
    language:
    /*i18n*/
    core_.i18n._("Chinese"),
    dialect: '简'
  },
  'zh-TW': {
    flag: '/images/flags/ch-flag.png',
    language:
    /*i18n*/
    core_.i18n._("Chinese"),
    dialect: '繁'
  },
  es: {
    flag: '/images/flags/es-flag.png',
    language:
    /*i18n*/
    core_.i18n._("Spanish")
  },
  'es-AR': {
    flag: '/images/flags/es-flag.png',
    language:
    /*i18n*/
    core_.i18n._("Spanish"),
    dialect: 'AR'
  },
  ko: {
    flag: '/images/flags/ko-flag.png',
    language:
    /*i18n*/
    core_.i18n._("Korean")
  },
  ja: {
    flag: '/images/flags/ja-flag.png',
    language:
    /*i18n*/
    core_.i18n._("Japanese")
  },
  fr: {
    flag: '/images/flags/fr-flag.png',
    language:
    /*i18n*/
    core_.i18n._("French")
  }
};
function LangSwitcher() {
  const {
    locale,
    locales,
    asPath
  } = (0,router_.useRouter)();
  return /*#__PURE__*/jsx_runtime_.jsx(react_.Menu, {
    as: "div",
    className: "relative inline-block text-right",
    children: ({
      open
    }) => /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
      children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(react_.Menu.Button, {
          className: "inline-flex justify-center w-full px-4 py-2 text-sm font-bold bg-transparent border rounded shadow-sm text-primary border-dark-800 hover:bg-dark-900 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-dark-700 focus:ring-dark-800",
          children: [/*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
            src: LANGUAGES[locale].flag,
            alt: LANGUAGES[locale].language,
            width: 20,
            height: 20
          }), /*#__PURE__*/jsx_runtime_.jsx(esm/* ChevronDownIcon */.v4q, {
            className: "w-5 h-5 ml-2 -mr-1",
            "aria-hidden": "true"
          })]
        })
      }), /*#__PURE__*/jsx_runtime_.jsx(react_.Transition, {
        show: open,
        as: external_react_.Fragment,
        enter: "transition ease-out duration-100",
        enterFrom: "transform opacity-0 scale-95",
        enterTo: "transform opacity-100 scale-100",
        leave: "transition ease-in duration-75",
        leaveFrom: "transform opacity-100 scale-100",
        leaveTo: "transform opacity-0 scale-95",
        children: /*#__PURE__*/jsx_runtime_.jsx(react_.Menu.Items, {
          className: "absolute right-0 w-[161px] mt-2 origin-top-right divide-y divide-dark-600 rounded shadow-lg bg-dark-800 ring-1 ring-black ring-opacity-5 focus:outline-none",
          children: /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "p-2 space-y-2",
            children: locales.map(locale => {
              const {
                flag,
                language,
                dialect
              } = LANGUAGES[locale];
              return /*#__PURE__*/jsx_runtime_.jsx(react_.Menu.Item, {
                children: ({
                  active
                }) => /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                  href: asPath,
                  locale: locale,
                  children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
                    href: "#",
                    className: (0,functions/* classNames */.AK)(active ? 'bg-dark-700 text-high-emphesis' : 'text-primary', 'group flex items-center px-4 py-2 text-sm hover:bg-dark-700 focus:bg-dark-700 rounded'),
                    children: [/*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
                      className: "inline w-3 h-3 mr-1 align-middle",
                      src: flag,
                      width: 20,
                      height: 20,
                      alt: language,
                      "aria-hidden": "true"
                    }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                      className: "ml-4",
                      children: language
                    }), dialect && /*#__PURE__*/jsx_runtime_.jsx("sup", {
                      children: /*#__PURE__*/jsx_runtime_.jsx("small", {
                        children: dialect
                      })
                    })]
                  })
                })
              }, locale);
            })
          })
        })
      })]
    })
  });
}
// EXTERNAL MODULE: ./src/functions/styling.ts
var styling = __webpack_require__(1769);
// EXTERNAL MODULE: external "@lingui/react"
var external_lingui_react_ = __webpack_require__(2339);
// EXTERNAL MODULE: ./src/components/NavLink/index.tsx
var NavLink = __webpack_require__(3233);
;// CONCATENATED MODULE: ./src/components/Header/More.tsx










const items = i18n => [{
  name: i18n._(
  /*i18n*/
  i18n._("Docs")),
  description: i18n._(
  /*i18n*/
  i18n._("Documentation for users of Sushi.")),
  href: 'https://docs.sushi.com',
  external: true
}, {
  name: i18n._(
  /*i18n*/
  i18n._("Dev")),
  description: i18n._(
  /*i18n*/
  i18n._("Documentation for developers of Sushi.")),
  href: 'https://dev.sushi.com',
  external: true
}, {
  name: i18n._(
  /*i18n*/
  i18n._("Open Source")),
  description: i18n._(
  /*i18n*/
  i18n._("Sushi is a supporter of Open Source.")),
  href: 'https://github.com/sushiswap',
  external: true
}, {
  name: i18n._(
  /*i18n*/
  i18n._("Tools")),
  description: i18n._(
  /*i18n*/
  i18n._("Tools to optimize your workflow.")),
  href: '/tools',
  external: false
}, {
  name: i18n._(
  /*i18n*/
  i18n._("Discord")),
  description: i18n._(
  /*i18n*/
  i18n._("Join the community on Discord.")),
  href: 'https://discord.gg/NVPXN4e',
  external: true
}, {
  name: i18n._(
  /*i18n*/
  i18n._("Vesting")),
  description: i18n._(
  /*i18n*/
  i18n._("Weekly unlocks from the vesting period.")),
  href: '/vesting',
  external: false
}];

function Menu() {
  const {
    i18n
  } = (0,external_lingui_react_.useLingui)();
  const solutions = items(i18n);
  return /*#__PURE__*/jsx_runtime_.jsx(react_.Popover, {
    className: "relative ml-auto md:m-0",
    children: ({
      open
    }) => /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
      children: [/*#__PURE__*/jsx_runtime_.jsx(react_.Popover.Button, {
        className: (0,styling/* classNames */.A)(open ? 'text-primary' : 'text-secondary', 'focus:outline-none hover:text-high-emphesis'),
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("svg", {
          width: "16px",
          height: "16px",
          className: "inline-flex items-center w-5 h-5 ml-2",
          viewBox: "0 0 24 24",
          fill: "none",
          xmlns: "http://www.w3.org/2000/svg",
          children: [/*#__PURE__*/jsx_runtime_.jsx("path", {
            d: "M12 13C12.5523 13 13 12.5523 13 12C13 11.4477 12.5523 11 12 11C11.4477 11 11 11.4477 11 12C11 12.5523 11.4477 13 12 13Z",
            stroke: "currentColor",
            strokeWidth: "2",
            strokeLinecap: "round",
            strokeLinejoin: "round"
          }), /*#__PURE__*/jsx_runtime_.jsx("path", {
            d: "M19 13C19.5523 13 20 12.5523 20 12C20 11.4477 19.5523 11 19 11C18.4477 11 18 11.4477 18 12C18 12.5523 18.4477 13 19 13Z",
            stroke: "currentColor",
            strokeWidth: "2",
            strokeLinecap: "round",
            strokeLinejoin: "round"
          }), /*#__PURE__*/jsx_runtime_.jsx("path", {
            d: "M5 13C5.55228 13 6 12.5523 6 12C6 11.4477 5.55228 11 5 11C4.44772 11 4 11.4477 4 12C4 12.5523 4.44772 13 5 13Z",
            stroke: "currentColor",
            strokeWidth: "2",
            strokeLinecap: "round",
            strokeLinejoin: "round"
          })]
        })
      }), /*#__PURE__*/jsx_runtime_.jsx(react_.Transition, {
        show: open,
        as: external_react_.Fragment,
        enter: "transition ease-out duration-200",
        enterFrom: "opacity-0 translate-y-1",
        enterTo: "opacity-100 translate-y-0",
        leave: "transition ease-in duration-150",
        leaveFrom: "opacity-100 translate-y-0",
        leaveTo: "opacity-0 translate-y-1",
        children: /*#__PURE__*/jsx_runtime_.jsx(react_.Popover.Panel, {
          static: true,
          className: "absolute z-50 w-screen max-w-xs px-2 mt-3 transform -translate-x-full bottom-12 lg:top-12 left-full sm:px-0",
          children: /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "overflow-hidden rounded-lg shadow-lg ring-1 ring-black ring-opacity-5",
            children: /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: "relative grid gap-6 px-5 py-6 bg-dark-900 sm:gap-8 sm:p-8",
              children: solutions.map(item => item.external ? /*#__PURE__*/(0,jsx_runtime_.jsxs)(ExternalLink/* default */.Z, {
                href: item.href,
                className: "block p-3 -m-3 transition duration-150 ease-in-out rounded-md hover:bg-dark-800",
                children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
                  className: "text-base font-medium text-high-emphesis",
                  children: item.name
                }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                  className: "mt-1 text-sm text-secondary",
                  children: item.description
                })]
              }, item.name) : /*#__PURE__*/jsx_runtime_.jsx(NavLink/* default */.Z, {
                href: item.href,
                children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
                  className: "block p-3 -m-3 transition duration-150 ease-in-out rounded-md hover:bg-dark-800",
                  children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
                    className: "text-base font-medium text-high-emphesis",
                    children: item.name
                  }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                    className: "mt-1 text-sm text-secondary",
                    children: item.description
                  })]
                })
              }, item.name))
            })
          })
        })
      })]
    })
  });
}
// EXTERNAL MODULE: ./src/components/QuestionHelper/index.tsx
var QuestionHelper = __webpack_require__(5068);
// EXTERNAL MODULE: ./src/constants/networks.ts
var networks = __webpack_require__(4965);
// EXTERNAL MODULE: ./src/modals/NetworkModal/index.tsx
var NetworkModal = __webpack_require__(8828);
// EXTERNAL MODULE: ./src/hooks/useActiveWeb3React.ts
var useActiveWeb3React = __webpack_require__(8269);
// EXTERNAL MODULE: ./src/state/application/hooks.ts
var hooks = __webpack_require__(4663);
;// CONCATENATED MODULE: ./src/components/Web3Network/index.tsx









function Web3Network() {
  const {
    chainId
  } = (0,useActiveWeb3React/* useActiveWeb3React */.a)();
  const toggleNetworkModal = (0,hooks/* useNetworkModalToggle */.o)();
  if (!chainId) return null;
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "flex items-center rounded bg-dark-900 hover:bg-dark-800 p-0.5 whitespace-nowrap text-sm font-bold cursor-pointer select-none pointer-events-auto",
    onClick: () => toggleNetworkModal(),
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "grid items-center grid-flow-col px-3 py-2 space-x-2 text-sm rounded-lg pointer-events-auto auto-cols-max bg-dark-1000 text-secondary",
      children: [/*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
        src: networks/* NETWORK_ICON */.w[chainId],
        alt: "Switch Network",
        className: "rounded-md",
        width: "22px",
        height: "22px"
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "text-primary",
        children: networks/* NETWORK_LABEL */.z[chainId]
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx(NetworkModal/* default */.Z, {})]
  });
}

/* harmony default export */ var components_Web3Network = (Web3Network);
// EXTERNAL MODULE: ./src/components/Web3Status/index.tsx + 7 modules
var Web3Status = __webpack_require__(531);
// EXTERNAL MODULE: ./src/state/wallet/hooks.ts
var wallet_hooks = __webpack_require__(2319);
;// CONCATENATED MODULE: ./src/components/Header/index.tsx


















 // import { ExternalLink, NavLink } from "./Link";
// import { ReactComponent as Burger } from "../assets/images/burger.svg";

function AppBar() {
  var _useETHBalances;

  const {
    i18n
  } = (0,external_lingui_react_.useLingui)();
  const {
    account,
    chainId,
    library
  } = (0,useActiveWeb3React/* useActiveWeb3React */.a)();
  const userEthBalance = (_useETHBalances = (0,wallet_hooks/* useETHBalances */.AE)(account ? [account] : [])) === null || _useETHBalances === void 0 ? void 0 : _useETHBalances[account !== null && account !== void 0 ? account : ''];
  return (
    /*#__PURE__*/
    //     // <header className="flex flex-row justify-between w-screen flex-nowrap">
    jsx_runtime_.jsx("header", {
      className: "flex-shrink-0 w-full",
      children: /*#__PURE__*/jsx_runtime_.jsx(react_.Popover, {
        as: "nav",
        className: "z-10 w-full bg-transparent header-border-b",
        children: ({
          open
        }) => /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "px-4 py-4",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "flex items-center justify-between",
              children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: "flex items-center",
                children: [/*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
                  src: "/logo.png",
                  alt: "Sushi",
                  width: "32px",
                  height: "32px"
                }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                  className: "hidden sm:block sm:ml-4",
                  children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                    className: "flex space-x-2",
                    children: [/*#__PURE__*/jsx_runtime_.jsx(NavLink/* default */.Z, {
                      href: "/swap",
                      children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                        id: `swap-nav-link`,
                        className: "p-2 text-baseline text-primary hover:text-high-emphesis focus:text-high-emphesis md:p-3 whitespace-nowrap",
                        children: i18n._(
                        /*i18n*/
                        i18n._("Swap"))
                      })
                    }), /*#__PURE__*/jsx_runtime_.jsx(NavLink/* default */.Z, {
                      href: "/pool",
                      children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                        id: `pool-nav-link`,
                        className: "p-2 text-baseline text-primary hover:text-high-emphesis focus:text-high-emphesis md:p-3 whitespace-nowrap",
                        children: i18n._(
                        /*i18n*/
                        i18n._("Pool"))
                      })
                    }), chainId && [sdk_.ChainId.MAINNET, sdk_.ChainId.MATIC, sdk_.ChainId.BSC].includes(chainId) && /*#__PURE__*/jsx_runtime_.jsx(NavLink/* default */.Z, {
                      href: '/migrate',
                      children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                        id: `migrate-nav-link`,
                        className: "p-2 text-baseline text-primary hover:text-high-emphesis focus:text-high-emphesis md:p-3 whitespace-nowrap",
                        children: i18n._(
                        /*i18n*/
                        i18n._("Migrate"))
                      })
                    }), chainId && [sdk_.ChainId.MAINNET, sdk_.ChainId.MATIC, sdk_.ChainId.XDAI, sdk_.ChainId.HARMONY].includes(chainId) && /*#__PURE__*/jsx_runtime_.jsx(NavLink/* default */.Z, {
                      href: '/farm',
                      children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                        id: `farm-nav-link`,
                        className: "p-2 text-baseline text-primary hover:text-high-emphesis focus:text-high-emphesis md:p-3 whitespace-nowrap",
                        children: i18n._(
                        /*i18n*/
                        i18n._("Farm"))
                      })
                    }), chainId && [sdk_.ChainId.MAINNET, sdk_.ChainId.KOVAN, sdk_.ChainId.BSC, sdk_.ChainId.MATIC].includes(chainId) && /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                      children: [/*#__PURE__*/jsx_runtime_.jsx(NavLink/* default */.Z, {
                        href: '/lend',
                        children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                          id: `lend-nav-link`,
                          className: "p-2 text-baseline text-primary hover:text-high-emphesis focus:text-high-emphesis md:p-3 whitespace-nowrap",
                          children: i18n._(
                          /*i18n*/
                          i18n._("Lend"))
                        })
                      }), /*#__PURE__*/jsx_runtime_.jsx(NavLink/* default */.Z, {
                        href: '/borrow',
                        children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                          id: `borrow-nav-link`,
                          className: "p-2 text-baseline text-primary hover:text-high-emphesis focus:text-high-emphesis md:p-3 whitespace-nowrap",
                          children: i18n._(
                          /*i18n*/
                          i18n._("Borrow"))
                        })
                      })]
                    }), chainId === sdk_.ChainId.MAINNET && /*#__PURE__*/jsx_runtime_.jsx(NavLink/* default */.Z, {
                      href: '/stake',
                      children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                        id: `stake-nav-link`,
                        className: "p-2 text-baseline text-primary hover:text-high-emphesis focus:text-high-emphesis md:p-3 whitespace-nowrap",
                        children: i18n._(
                        /*i18n*/
                        i18n._("Stake"))
                      })
                    }), chainId === sdk_.ChainId.MAINNET && /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                      href: '/miso',
                      children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                        id: `stake-nav-link`,
                        className: "p-2 text-baseline text-primary hover:text-high-emphesis focus:text-high-emphesis md:p-3 whitespace-nowrap",
                        children: i18n._(
                        /*i18n*/
                        i18n._("Miso"))
                      })
                    })]
                  })
                })]
              }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "fixed bottom-0 left-0 z-10 flex flex-row items-center justify-center w-full p-4 lg:w-auto bg-dark-1000 lg:relative lg:p-0 lg:bg-transparent",
                children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                  className: "flex items-center justify-between w-full space-x-2 sm:justify-end",
                  children: [chainId && [sdk_.ChainId.MAINNET].includes(chainId) && library && library.provider.isMetaMask && /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                    children: /*#__PURE__*/jsx_runtime_.jsx(QuestionHelper/* default */.Z, {
                      text: i18n._(
                      /*i18n*/
                      i18n._("Add xSUSHI to your MetaMask wallet")),
                      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
                        className: "hidden p-0.5 rounded-md cursor-pointer sm:inline-flex bg-dark-900 hover:bg-dark-800",
                        onClick: () => {
                          if (library && library.provider.isMetaMask && library.provider.request) {
                            const params = {
                              type: 'ERC20',
                              options: {
                                address: '0x8798249c2e607446efb7ad49ec89dd1865ff4272',
                                symbol: 'XSUSHI',
                                decimals: 18,
                                image: 'https://raw.githubusercontent.com/sushiswap/assets/master/blockchains/ethereum/assets/0x8798249c2E607446EfB7Ad49eC89dD1865Ff4272/logo.png'
                              }
                            };
                            library.provider.request({
                              method: 'wallet_watchAsset',
                              params
                            }).then(success => {
                              if (success) {
                                console.log('Successfully added XSUSHI to MetaMask');
                              } else {
                                throw new Error('Something went wrong.');
                              }
                            }).catch(console.error);
                          }
                        },
                        children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
                          src: "/images/tokens/xsushi-square.jpg",
                          alt: "xSUSHI",
                          width: "38px",
                          height: "38px",
                          objectFit: "contain",
                          className: "rounded-md"
                        })
                      })
                    })
                  }), chainId && chainId in sdk_.SUSHI_ADDRESS && library && library.provider.isMetaMask && /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                    children: /*#__PURE__*/jsx_runtime_.jsx(QuestionHelper/* default */.Z, {
                      text: i18n._(
                      /*i18n*/
                      i18n._("Add SUSHI to your MetaMask wallet")),
                      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
                        className: "hidden rounded-md cursor-pointer sm:inline-flex bg-dark-900 hover:bg-dark-800 p-0.5",
                        onClick: () => {
                          const params = {
                            type: 'ERC20',
                            options: {
                              address: sdk_.SUSHI_ADDRESS[chainId],
                              symbol: 'SUSHI',
                              decimals: 18,
                              image: 'https://raw.githubusercontent.com/sushiswap/assets/master/blockchains/ethereum/assets/0x6B3595068778DD592e39A122f4f5a5cF09C90fE2/logo.png'
                            }
                          };

                          if (library && library.provider.isMetaMask && library.provider.request) {
                            library.provider.request({
                              method: 'wallet_watchAsset',
                              params
                            }).then(success => {
                              if (success) {
                                console.log('Successfully added SUSHI to MetaMask');
                              } else {
                                throw new Error('Something went wrong.');
                              }
                            }).catch(console.error);
                          }
                        },
                        children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
                          src: "/images/tokens/sushi-square.jpg",
                          alt: "SUSHI",
                          width: "38px",
                          height: "38px",
                          objectFit: "contain",
                          className: "rounded-md"
                        })
                      })
                    })
                  }), library && library.provider.isMetaMask && /*#__PURE__*/jsx_runtime_.jsx("div", {
                    className: "hidden sm:inline-block",
                    children: /*#__PURE__*/jsx_runtime_.jsx(components_Web3Network, {})
                  }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                    className: "w-auto flex items-center rounded bg-dark-900 hover:bg-dark-800 p-0.5 whitespace-nowrap text-sm font-bold cursor-pointer select-none pointer-events-auto",
                    children: [account && chainId && userEthBalance && /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                        className: "px-3 py-2 text-primary text-bold",
                        children: [userEthBalance === null || userEthBalance === void 0 ? void 0 : userEthBalance.toSignificant(4), " ", sdk_.NATIVE[chainId].symbol]
                      })
                    }), /*#__PURE__*/jsx_runtime_.jsx(Web3Status/* default */.Z, {})]
                  }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                    className: "hidden md:block",
                    children: /*#__PURE__*/jsx_runtime_.jsx(LangSwitcher, {})
                  }), /*#__PURE__*/jsx_runtime_.jsx(Menu, {})]
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "flex -mr-2 sm:hidden",
                children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(react_.Popover.Button, {
                  className: "inline-flex items-center justify-center p-2 rounded-md text-primary hover:text-high-emphesis focus:outline-none",
                  children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
                    className: "sr-only",
                    children: i18n._(
                    /*i18n*/
                    i18n._("Open main menu"))
                  }), open ? /*#__PURE__*/jsx_runtime_.jsx("svg", {
                    className: "block w-6 h-6",
                    "aria-hidden": "true",
                    xmlns: "http://www.w3.org/2000/svg",
                    viewBox: "0 0 24 24",
                    stroke: "currentColor",
                    children: /*#__PURE__*/jsx_runtime_.jsx("path", {
                      strokeLinecap: "round",
                      strokeLinejoin: "round",
                      strokeWidth: "2",
                      d: "M6 18L18 6M6 6l12 12"
                    })
                  }) :
                  /*#__PURE__*/
                  // <X title="Close" className="block w-6 h-6" aria-hidden="true" />
                  jsx_runtime_.jsx("svg", {
                    className: "block w-6 h-6",
                    "aria-hidden": "true",
                    xmlns: "http://www.w3.org/2000/svg",
                    fill: "none",
                    viewBox: "0 0 24 24",
                    stroke: "currentColor",
                    children: /*#__PURE__*/jsx_runtime_.jsx("path", {
                      strokeLinecap: "round",
                      strokeLinejoin: "round",
                      strokeWidth: 2,
                      d: "M4 6h16M4 12h16M4 18h16"
                    })
                  }) // <Burger title="Burger" className="block w-6 h-6" aria-hidden="true" />
                  ]
                })
              })]
            })
          }), /*#__PURE__*/jsx_runtime_.jsx(react_.Popover.Panel, {
            className: "sm:hidden",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "flex flex-col px-4 pt-2 pb-3 space-y-1",
              children: [/*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                href: '/swap',
                children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                  id: `swap-nav-link`,
                  className: "p-2 text-baseline text-primary hover:text-high-emphesis focus:text-high-emphesis md:p-3 whitespace-nowrap",
                  children: i18n._(
                  /*i18n*/
                  i18n._("Swap"))
                })
              }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                href: '/pool',
                children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                  id: `pool-nav-link`,
                  className: "p-2 text-baseline text-primary hover:text-high-emphesis focus:text-high-emphesis md:p-3 whitespace-nowrap",
                  children: i18n._(
                  /*i18n*/
                  i18n._("Pool"))
                })
              }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                href: '/migrate',
                children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                  id: `migrate-nav-link`,
                  className: "p-2 text-baseline text-primary hover:text-high-emphesis focus:text-high-emphesis md:p-3 whitespace-nowrap",
                  children: i18n._(
                  /*i18n*/
                  i18n._("Migrate"))
                })
              }), chainId && [sdk_.ChainId.MAINNET, sdk_.ChainId.MATIC, sdk_.ChainId.HARMONY, sdk_.ChainId.XDAI].includes(chainId) && /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                href: '/farm',
                children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
                  id: `farm-nav-link`,
                  className: "p-2 text-baseline text-primary hover:text-high-emphesis focus:text-high-emphesis md:p-3 whitespace-nowrap",
                  children: [' ', i18n._(
                  /*i18n*/
                  i18n._("Farm"))]
                })
              }), chainId && [sdk_.ChainId.MAINNET, sdk_.ChainId.KOVAN, sdk_.ChainId.BSC, sdk_.ChainId.MATIC].includes(chainId) && /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                children: [/*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                  href: '/lend',
                  children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                    id: `lend-nav-link`,
                    className: "p-2 text-baseline text-primary hover:text-high-emphesis focus:text-high-emphesis md:p-3 whitespace-nowrap",
                    children: i18n._(
                    /*i18n*/
                    i18n._("Lend"))
                  })
                }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                  href: '/borrow',
                  children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                    id: `borrow-nav-link`,
                    className: "p-2 text-baseline text-primary hover:text-high-emphesis focus:text-high-emphesis md:p-3 whitespace-nowrap",
                    children: i18n._(
                    /*i18n*/
                    i18n._("Borrow"))
                  })
                })]
              }), chainId === sdk_.ChainId.MAINNET && /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                href: '/stake',
                children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                  id: `stake-nav-link`,
                  className: "p-2 text-baseline text-primary hover:text-high-emphesis focus:text-high-emphesis md:p-3 whitespace-nowrap",
                  children: i18n._(
                  /*i18n*/
                  i18n._("Stake"))
                })
              }), chainId && [sdk_.ChainId.MAINNET, sdk_.ChainId.BSC, sdk_.ChainId.XDAI, sdk_.ChainId.FANTOM, sdk_.ChainId.MATIC].includes(chainId) && /*#__PURE__*/jsx_runtime_.jsx(ExternalLink/* default */.Z, {
                id: `analytics-nav-link`,
                href: constants/* ANALYTICS_URL */.fi[chainId] || 'https://analytics.sushi.com',
                className: "p-2 text-baseline text-primary hover:text-high-emphesis focus:text-high-emphesis md:p-3 whitespace-nowrap",
                children: i18n._(
                /*i18n*/
                i18n._("Analytics"))
              }), chainId === sdk_.ChainId.MAINNET && /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                href: '/miso',
                children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                  id: `stake-nav-link`,
                  className: "p-2 text-baseline text-primary hover:text-high-emphesis focus:text-high-emphesis md:p-3 whitespace-nowrap",
                  children: i18n._(
                  /*i18n*/
                  i18n._("Miso"))
                })
              })]
            })
          })]
        })
      })
    })
  );
}

/* harmony default export */ var Header = (AppBar);

/***/ }),

/***/ 5068:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _heroicons_react_solid__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3802);
/* harmony import */ var _Tooltip__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3349);





const QuestionHelper = ({
  children,
  text
}) => {
  const {
    0: show,
    1: setShow
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
  const open = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(() => setShow(true), [setShow]);
  const close = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(() => setShow(false), [setShow]);

  if (children) {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Tooltip__WEBPACK_IMPORTED_MODULE_3__/* .default */ .ZP, {
      text: text,
      show: show,
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "flex items-center justify-center outline-none",
        onClick: open,
        onMouseEnter: open,
        onMouseLeave: close,
        children: children
      })
    });
  }

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
    className: "ml-1",
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Tooltip__WEBPACK_IMPORTED_MODULE_3__/* .default */ .ZP, {
      text: text,
      show: show,
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "flex items-center justify-center outline-none cursor-help hover:text-primary",
        onClick: open,
        onMouseEnter: open,
        onMouseLeave: close,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_heroicons_react_solid__WEBPACK_IMPORTED_MODULE_2__/* .QuestionMarkCircleIcon */ .zqj, {
          width: 16,
          height: 16
        })
      })
    })
  });
};

/* harmony default export */ __webpack_exports__["Z"] = (QuestionHelper);

/***/ }),

/***/ 3349:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "ud": function() { return /* binding */ MouseoverTooltip; },
  "ZP": function() { return /* binding */ Tooltip; }
});

// UNUSED EXPORTS: MouseoverTooltipContent, TooltipContent

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(9914);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: external "@reach/portal"
var portal_ = __webpack_require__(6303);
var portal_default = /*#__PURE__*/__webpack_require__.n(portal_);
// EXTERNAL MODULE: ./src/hooks/useInterval.ts
var useInterval = __webpack_require__(2269);
// EXTERNAL MODULE: external "react-popper"
var external_react_popper_ = __webpack_require__(7755);
;// CONCATENATED MODULE: ./src/components/Popover/index.tsx




function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






const PopoverContainer = external_styled_components_default().div.withConfig({
  displayName: "Popover__PopoverContainer",
  componentId: "sc-nuqeh6-0"
})(["z-index:9999;visibility:", ";opacity:", ";transition:visibility 150ms linear,opacity 150ms linear;border-radius:8px;"], props => props.show ? 'visible' : 'hidden', props => props.show ? 1 : 0);
const ReferenceElement = external_styled_components_default().div.withConfig({
  displayName: "Popover__ReferenceElement",
  componentId: "sc-nuqeh6-1"
})(["display:inline-block;"]);
const Arrow = external_styled_components_default().div.withConfig({
  displayName: "Popover__Arrow",
  componentId: "sc-nuqeh6-2"
})(["width:8px;height:8px;z-index:9998;::before{position:absolute;width:8px;height:8px;z-index:9998;content:'';transform:rotate(45deg);}&.arrow-top{bottom:-5px;::before{border-top:none;border-left:none;}}&.arrow-bottom{top:-5px;::before{border-bottom:none;border-right:none;}}&.arrow-left{right:-5px;::before{border-bottom:none;border-left:none;}}&.arrow-right{left:-5px;::before{border-right:none;border-top:none;}}"]);
function Popover_Popover({
  content,
  show,
  children,
  placement = 'auto'
}) {
  var _attributes$popper$da, _attributes$popper;

  const {
    0: referenceElement,
    1: setReferenceElement
  } = (0,external_react_.useState)(null);
  const {
    0: popperElement,
    1: setPopperElement
  } = (0,external_react_.useState)(null);
  const {
    0: arrowElement,
    1: setArrowElement
  } = (0,external_react_.useState)(null);
  const {
    styles,
    update,
    attributes
  } = (0,external_react_popper_.usePopper)(referenceElement, popperElement, {
    placement,
    strategy: 'fixed',
    modifiers: [{
      name: 'offset',
      options: {
        offset: [8, 8]
      }
    }, {
      name: 'arrow',
      options: {
        element: arrowElement
      }
    }]
  });
  const updateCallback = (0,external_react_.useCallback)(() => {
    update && update();
  }, [update]);
  (0,useInterval/* default */.Z)(updateCallback, show ? 100 : null);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(ReferenceElement, {
      ref: setReferenceElement,
      children: children
    }), /*#__PURE__*/jsx_runtime_.jsx((portal_default()), {
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(PopoverContainer, _objectSpread(_objectSpread({
        show: show,
        ref: setPopperElement,
        style: styles.popper
      }, attributes.popper), {}, {
        children: [content, /*#__PURE__*/jsx_runtime_.jsx(Arrow, _objectSpread({
          className: `arrow-${(_attributes$popper$da = (_attributes$popper = attributes.popper) === null || _attributes$popper === void 0 ? void 0 : _attributes$popper['data-popper-placement']) !== null && _attributes$popper$da !== void 0 ? _attributes$popper$da : ''}`,
          ref: setArrowElement,
          style: styles.arrow
        }, attributes.arrow))]
      }))
    })]
  });
}
;// CONCATENATED MODULE: ./src/components/Tooltip/index.tsx



function Tooltip_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function Tooltip_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { Tooltip_ownKeys(Object(source), true).forEach(function (key) { Tooltip_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { Tooltip_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function Tooltip_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }




const TooltipContainer = external_styled_components_default().div.withConfig({
  displayName: "Tooltip__TooltipContainer",
  componentId: "sc-epu4js-0"
})(["width:256px;padding:0.6rem 1rem;font-weight:400;word-break:break-word;"]);

function Tooltip(_ref) {
  let {
    text
  } = _ref,
      rest = _objectWithoutProperties(_ref, ["text"]);

  return /*#__PURE__*/jsx_runtime_.jsx(Popover_Popover, Tooltip_objectSpread({
    content: /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "w-[228px] px-2 py-1 font-medium bg-dark-700 border border-gray-600 rounded text-sm",
      children: text
    })
  }, rest));
} // export default function Tooltip({ text, ...rest }: TooltipProps) {
//   return (
//     <Popover content={<TooltipContainer>{text}</TooltipContainer>} {...rest} />
//   );
// }

function TooltipContent(_ref2) {
  let {
    content
  } = _ref2,
      rest = _objectWithoutProperties(_ref2, ["content"]);

  return /*#__PURE__*/_jsx(Popover, Tooltip_objectSpread({
    content: /*#__PURE__*/_jsx(TooltipContainer, {
      children: content
    })
  }, rest));
}
function MouseoverTooltip(_ref3) {
  let {
    children
  } = _ref3,
      rest = _objectWithoutProperties(_ref3, ["children"]);

  const {
    0: show,
    1: setShow
  } = (0,external_react_.useState)(false);
  const open = (0,external_react_.useCallback)(() => setShow(true), [setShow]);
  const close = (0,external_react_.useCallback)(() => setShow(false), [setShow]);
  return /*#__PURE__*/jsx_runtime_.jsx(Tooltip, Tooltip_objectSpread(Tooltip_objectSpread({}, rest), {}, {
    show: show,
    children: /*#__PURE__*/jsx_runtime_.jsx("div", {
      onMouseEnter: open,
      onMouseLeave: close,
      children: children
    })
  }));
}
function MouseoverTooltipContent(_ref4) {
  let {
    content,
    children
  } = _ref4,
      rest = _objectWithoutProperties(_ref4, ["content", "children"]);

  const {
    0: show,
    1: setShow
  } = useState(false);
  const open = useCallback(() => setShow(true), [setShow]);
  const close = useCallback(() => setShow(false), [setShow]);
  return /*#__PURE__*/_jsx(TooltipContent, Tooltip_objectSpread(Tooltip_objectSpread({}, rest), {}, {
    show: show,
    content: content,
    children: /*#__PURE__*/_jsx("div", {
      style: {
        display: 'inline-block',
        lineHeight: 0,
        padding: '0.25rem'
      },
      onMouseEnter: open,
      onMouseLeave: close,
      children: children
    })
  }));
}

/***/ }),

/***/ 531:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": function() { return /* binding */ Web3Status; }
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./src/connectors/index.ts + 1 modules
var connectors = __webpack_require__(1378);
// EXTERNAL MODULE: ./src/state/transactions/hooks.tsx
var hooks = __webpack_require__(9123);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./src/components/Loader/index.tsx
var Loader = __webpack_require__(4419);
// EXTERNAL MODULE: ./src/constants/index.ts
var constants = __webpack_require__(8532);
// EXTERNAL MODULE: external "@web3-react/core"
var core_ = __webpack_require__(417);
// EXTERNAL MODULE: ./src/state/application/hooks.ts
var application_hooks = __webpack_require__(4663);
// EXTERNAL MODULE: ./src/components/Button/index.tsx
var Button = __webpack_require__(7603);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/outline/esm/index.js + 230 modules
var esm = __webpack_require__(6049);
// EXTERNAL MODULE: external "copy-to-clipboard"
var external_copy_to_clipboard_ = __webpack_require__(8929);
var external_copy_to_clipboard_default = /*#__PURE__*/__webpack_require__.n(external_copy_to_clipboard_);
;// CONCATENATED MODULE: ./src/hooks/useCopyClipboard.ts


function useCopyClipboard(timeout = 500) {
  const {
    0: isCopied,
    1: setIsCopied
  } = (0,external_react_.useState)(false);
  const staticCopy = (0,external_react_.useCallback)(text => {
    const didCopy = external_copy_to_clipboard_default()(text);
    setIsCopied(didCopy);
  }, []);
  (0,external_react_.useEffect)(() => {
    if (isCopied) {
      const hide = setTimeout(() => {
        setIsCopied(false);
      }, timeout);
      return () => {
        clearTimeout(hide);
      };
    }

    return undefined;
  }, [isCopied, setIsCopied, timeout]);
  return [isCopied, staticCopy];
}
// EXTERNAL MODULE: ./src/functions/index.ts
var functions = __webpack_require__(7735);
// EXTERNAL MODULE: ./src/components/Typography/index.tsx
var Typography = __webpack_require__(3130);
// EXTERNAL MODULE: external "@lingui/react"
var react_ = __webpack_require__(2339);
;// CONCATENATED MODULE: ./src/components/AccountDetails/Copy.tsx










const CopyHelper = ({
  className,
  toCopy,
  children
}) => {
  const [isCopied, setCopied] = useCopyClipboard();
  const {
    i18n
  } = (0,react_.useLingui)();
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: (0,functions/* classNames */.AK)('flex items-center flex-shrink-0 space-x-1 no-underline cursor-pointer whitespace-nowrap hover:no-underline focus:no-underline active:no-underline text-blue opacity-80 hover:opacity-100 focus:opacity-100', className),
    onClick: () => setCopied(toCopy),
    children: [isCopied && /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "flex items-center space-x-1 whitespace-nowrap",
      children: [/*#__PURE__*/jsx_runtime_.jsx(Typography/* default */.Z, {
        variant: "sm",
        children: i18n._(
        /*i18n*/
        i18n._("Copied"))
      }), /*#__PURE__*/jsx_runtime_.jsx(esm/* CheckCircleIcon */.rE2, {
        width: 16,
        height: 16
      })]
    }), !isCopied && /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
      children: [children, /*#__PURE__*/jsx_runtime_.jsx(esm/* ClipboardCopyIcon */.dqY, {
        width: 16,
        height: 16
      })]
    })]
  });
};

/* harmony default export */ var Copy = (CopyHelper);
// EXTERNAL MODULE: ./src/components/ExternalLink/index.tsx
var ExternalLink = __webpack_require__(3106);
// EXTERNAL MODULE: external "react-feather"
var external_react_feather_ = __webpack_require__(9337);
// EXTERNAL MODULE: ./src/components/ModalHeader/index.tsx
var ModalHeader = __webpack_require__(7144);
// EXTERNAL MODULE: external "@sushiswap/sdk"
var sdk_ = __webpack_require__(6766);
// EXTERNAL MODULE: ./src/state/transactions/actions.ts
var actions = __webpack_require__(7219);
// EXTERNAL MODULE: ./src/functions/explorer.ts
var explorer = __webpack_require__(3302);
// EXTERNAL MODULE: ./src/hooks/useActiveWeb3React.ts
var useActiveWeb3React = __webpack_require__(8269);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(79);
;// CONCATENATED MODULE: ./src/components/AccountDetails/Transaction.tsx


















const calculateSecondsUntilDeadline = tx => {
  var _tx$archer;

  if (tx !== null && tx !== void 0 && (_tx$archer = tx.archer) !== null && _tx$archer !== void 0 && _tx$archer.deadline && tx !== null && tx !== void 0 && tx.addedTime) {
    const millisecondsUntilUntilDeadline = tx.archer.deadline * 1000 - Date.now();
    return millisecondsUntilUntilDeadline < 0 ? -1 : Math.ceil(millisecondsUntilUntilDeadline / 1000);
  }

  return -1;
};

const Transaction = ({
  hash
}) => {
  var _tx$receipt, _tx$receipt2;

  const {
    i18n
  } = (0,react_.useLingui)();
  const {
    chainId
  } = (0,useActiveWeb3React/* useActiveWeb3React */.a)();
  const allTransactions = (0,hooks/* useAllTransactions */.kf)();
  const dispatch = (0,external_react_redux_.useDispatch)();
  const tx = allTransactions === null || allTransactions === void 0 ? void 0 : allTransactions[hash];
  const summary = tx === null || tx === void 0 ? void 0 : tx.summary;
  const pending = !(tx !== null && tx !== void 0 && tx.receipt);
  const success = !pending && tx && (((_tx$receipt = tx.receipt) === null || _tx$receipt === void 0 ? void 0 : _tx$receipt.status) === 1 || typeof ((_tx$receipt2 = tx.receipt) === null || _tx$receipt2 === void 0 ? void 0 : _tx$receipt2.status) === 'undefined');
  const archer = tx === null || tx === void 0 ? void 0 : tx.archer;
  const secondsUntilDeadline = (0,external_react_.useMemo)(() => calculateSecondsUntilDeadline(tx), [tx]);
  const mined = (tx === null || tx === void 0 ? void 0 : tx.receipt) && tx.receipt.status !== 1337;
  const cancelled = (tx === null || tx === void 0 ? void 0 : tx.receipt) && tx.receipt.status === 1337;
  const expired = secondsUntilDeadline === -1;
  const cancelPending = (0,external_react_.useCallback)(() => {
    var _process$env$NEXT_PUB;

    const relayURI = constants/* ARCHER_RELAY_URI */.HB[chainId];
    if (!relayURI) return;
    const body = JSON.stringify({
      method: 'archer_cancelTx',
      tx: archer === null || archer === void 0 ? void 0 : archer.rawTransaction
    });
    fetch(relayURI, {
      method: 'POST',
      body,
      headers: {
        Authorization: (_process$env$NEXT_PUB = "") !== null && _process$env$NEXT_PUB !== void 0 ? _process$env$NEXT_PUB : '',
        'Content-Type': 'application/json'
      }
    }).then(() => {
      dispatch((0,actions/* finalizeTransaction */.Aw)({
        chainId,
        hash,
        receipt: {
          blockHash: '',
          blockNumber: 0,
          contractAddress: '',
          from: '',
          status: 1337,
          to: '',
          transactionHash: '',
          transactionIndex: 0
        }
      }));
    }).catch(err => console.error(err));
  }, [dispatch, chainId, archer, hash]);
  if (!chainId) return null;
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "flex flex-col gap-2 bg-dark-800 rounded py-1 px-3 w-full",
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(ExternalLink/* default */.Z, {
      href: (0,explorer/* getExplorerLink */.E)(chainId, hash, 'transaction'),
      className: "flex items-center gap-2",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(Typography/* default */.Z, {
        variant: "sm",
        className: "flex items-center hover:underline py-0.5",
        children: [summary !== null && summary !== void 0 ? summary : hash, " \u2197"]
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: (0,functions/* classNames */.AK)(pending ? 'text-primary' : success ? 'text-green' : cancelled ? 'text-red' : 'text-red'),
        children: pending ? /*#__PURE__*/jsx_runtime_.jsx(Loader/* default */.Z, {}) : success ? /*#__PURE__*/jsx_runtime_.jsx(esm/* CheckCircleIcon */.rE2, {
          width: 16,
          height: 16
        }) : cancelled ? /*#__PURE__*/jsx_runtime_.jsx(esm/* XCircleIcon */.oOx, {
          width: 16,
          height: 16
        }) : /*#__PURE__*/jsx_runtime_.jsx(esm/* ExclamationIcon */.SI8, {
          width: 16,
          height: 16
        })
      })]
    }), archer && /*#__PURE__*/(0,jsx_runtime_.jsxs)(Typography/* default */.Z, {
      variant: "sm",
      weight: 400,
      className: "flex justify-between items-center text-decoration-none pb-1",
      children: [`#${archer.nonce} - Tip ${sdk_.CurrencyAmount.fromRawAmount(sdk_.Ether.onChain(sdk_.ChainId.MAINNET), archer.ethTip).toSignificant(6)} ETH`, pending ? /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [secondsUntilDeadline >= 60 ? /*#__PURE__*/(0,jsx_runtime_.jsxs)("span", {
          className: "text-high-emphesis",
          children: ["\uD83D\uDD51 ", `${Math.ceil(secondsUntilDeadline / 60)} mins`, " "]
        }) : /*#__PURE__*/(0,jsx_runtime_.jsxs)("span", {
          className: "text-high-emphesis",
          children: ["\uD83D\uDD51 ", `<1 min`, " "]
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "cursor-pointer flex items-center",
          onClick: cancelPending,
          children: i18n._(
          /*i18n*/
          i18n._("Cancel"))
        })]
      }) : cancelled ? /*#__PURE__*/jsx_runtime_.jsx("span", {
        className: "text-red",
        children: i18n._(
        /*i18n*/
        i18n._("Cancelled"))
      }) : !mined && expired && /*#__PURE__*/jsx_runtime_.jsx("span", {
        className: "text-red",
        children: i18n._(
        /*i18n*/
        i18n._("Expired"))
      })]
    })]
  });
};

/* harmony default export */ var AccountDetails_Transaction = (Transaction);
;// CONCATENATED MODULE: ./src/components/AccountDetails/index.tsx





















const WalletIcon = ({
  size,
  src,
  alt,
  children
}) => {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "flex flex-row flex-nowrap items-end md:items-center justify-center mr-2",
    children: [/*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
      src: src,
      alt: alt,
      width: size,
      height: size
    }), children]
  });
};

function renderTransactions(transactions) {
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "flex flex-col flex-nowrap gap-2",
    children: transactions.map((hash, i) => {
      return /*#__PURE__*/jsx_runtime_.jsx(AccountDetails_Transaction, {
        hash: hash
      }, i);
    })
  });
}

const AccountDetails = ({
  toggleWalletModal,
  pendingTransactions,
  confirmedTransactions,
  ENSName,
  openOptions
}) => {
  const {
    i18n
  } = (0,react_.useLingui)();
  const {
    chainId,
    account,
    connector
  } = (0,useActiveWeb3React/* useActiveWeb3React */.a)();
  const dispatch = (0,external_react_redux_.useDispatch)();

  function formatConnectorName() {
    const {
      ethereum
    } = window;
    const isMetaMask = !!(ethereum && ethereum.isMetaMask);
    const name = Object.keys(constants/* SUPPORTED_WALLETS */.Vp).filter(k => constants/* SUPPORTED_WALLETS */.Vp[k].connector === connector && (connector !== connectors/* injected */.Lj || isMetaMask === (k === 'METAMASK'))).map(k => constants/* SUPPORTED_WALLETS */.Vp[k].name)[0];
    return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "font-medium text-baseline text-secondary",
      children: ["Connected with ", name]
    });
  }

  function getStatusIcon() {
    if (connector === connectors/* injected */.Lj) {
      return null; // return <IconWrapper size={16}>{/* <Identicon /> */}</IconWrapper>
    } else if (connector === connectors/* walletconnect */.Lw) {
      return /*#__PURE__*/jsx_runtime_.jsx(WalletIcon, {
        src: "/wallet-connect.png",
        alt: "Wallet Connect",
        size: 16
      });
    } else if (connector === connectors/* walletlink */.H5) {
      return /*#__PURE__*/jsx_runtime_.jsx(WalletIcon, {
        src: "/coinbase.svg",
        alt: "Coinbase",
        size: 16
      });
    } else if (connector === connectors/* fortmatic */.pp) {
      return /*#__PURE__*/jsx_runtime_.jsx(WalletIcon, {
        src: "/formatic.png",
        alt: "Fortmatic",
        size: 16
      });
    } else if (connector === connectors/* portis */.yO) {
      return /*#__PURE__*/jsx_runtime_.jsx(WalletIcon, {
        src: "/portnis.png",
        alt: "Portis",
        size: 16,
        children: /*#__PURE__*/jsx_runtime_.jsx(Button/* default */.ZP, {
          onClick: () => {
            connectors/* portis.portis.showPortis */.yO.portis.showPortis();
          },
          children: "Show Portis"
        })
      });
    } else if (connector === connectors/* torus */.ux) {
      return /*#__PURE__*/jsx_runtime_.jsx(WalletIcon, {
        src: "/torus.png",
        alt: "Torus",
        size: 16
      });
    }

    return null;
  }

  const clearAllTransactionsCallback = (0,external_react_.useCallback)(() => {
    if (chainId) dispatch((0,actions/* clearAllTransactions */.fY)({
      chainId
    }));
  }, [dispatch, chainId]);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "space-y-3",
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "space-y-3",
      children: [/*#__PURE__*/jsx_runtime_.jsx(ModalHeader/* default */.Z, {
        title: "Account",
        onClose: toggleWalletModal
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "space-y-3",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex items-center justify-between",
          children: [formatConnectorName(), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "flex space-x-3",
            children: [connector !== connectors/* injected */.Lj && connector !== connectors/* walletlink */.H5 && connector !== connectors/* binance */.Oh && /*#__PURE__*/jsx_runtime_.jsx(Button/* default */.ZP, {
              variant: "outlined",
              color: "gray",
              size: "xs",
              onClick: () => {
                ;
                connector.close();
              },
              children: i18n._(
              /*i18n*/
              i18n._("Disconnect"))
            }), /*#__PURE__*/jsx_runtime_.jsx(Button/* default */.ZP, {
              variant: "outlined",
              color: "gray",
              size: "xs",
              onClick: () => {
                openOptions();
              },
              children: i18n._(
              /*i18n*/
              i18n._("Change"))
            })]
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          id: "web3-account-identifier-row",
          className: "flex flex-col justify-center space-y-3",
          children: [ENSName ? /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "bg-dark-800",
            children: [getStatusIcon(), /*#__PURE__*/jsx_runtime_.jsx(Typography/* default */.Z, {
              children: ENSName
            })]
          }) : /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "bg-dark-800 py-2 px-3 rounded",
            children: [getStatusIcon(), /*#__PURE__*/jsx_runtime_.jsx(Typography/* default */.Z, {
              children: account && (0,functions/* shortenAddress */.Xn)(account)
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "flex items-center space-x-3 gap-2",
            children: [chainId && account && /*#__PURE__*/jsx_runtime_.jsx(ExternalLink/* default */.Z, {
              color: "blue",
              startIcon: /*#__PURE__*/jsx_runtime_.jsx(external_react_feather_.ExternalLink, {
                size: 16
              }),
              href: chainId && (0,explorer/* getExplorerLink */.E)(chainId, ENSName || account, 'address'),
              children: /*#__PURE__*/jsx_runtime_.jsx(Typography/* default */.Z, {
                variant: "sm",
                children: i18n._(
                /*i18n*/
                i18n._("View on explorer"))
              })
            }), account && /*#__PURE__*/jsx_runtime_.jsx(Copy, {
              toCopy: account,
              children: /*#__PURE__*/jsx_runtime_.jsx(Typography/* default */.Z, {
                variant: "sm",
                children: i18n._(
                /*i18n*/
                i18n._("Copy Address"))
              })
            })]
          })]
        })]
      })]
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "space-y-2",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex items-center justify-between",
        children: [/*#__PURE__*/jsx_runtime_.jsx(Typography/* default */.Z, {
          weight: 700,
          children: i18n._(
          /*i18n*/
          i18n._("Recent Transactions"))
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          children: /*#__PURE__*/jsx_runtime_.jsx(Button/* default */.ZP, {
            variant: "outlined",
            color: "gray",
            size: "xs",
            onClick: clearAllTransactionsCallback,
            children: i18n._(
            /*i18n*/
            i18n._("Clear all"))
          })
        })]
      }), !!pendingTransactions.length || !!confirmedTransactions.length ? /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [renderTransactions(pendingTransactions), renderTransactions(confirmedTransactions)]
      }) : /*#__PURE__*/jsx_runtime_.jsx(Typography/* default */.Z, {
        variant: "sm",
        className: "text-secondary",
        children: i18n._(
        /*i18n*/
        i18n._("Your transactions will appear here..."))
      })]
    })]
  });
};

/* harmony default export */ var components_AccountDetails = (AccountDetails);
// EXTERNAL MODULE: ./src/state/application/actions.ts
var application_actions = __webpack_require__(434);
// EXTERNAL MODULE: ./src/components/Modal/index.tsx
var Modal = __webpack_require__(1441);
// EXTERNAL MODULE: ./src/connectors/Fortmatic.ts
var Fortmatic = __webpack_require__(9108);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(9914);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
;// CONCATENATED MODULE: ./src/modals/WalletModal/Option.tsx





const SubHeader = external_styled_components_default().div.withConfig({
  displayName: "Option__SubHeader",
  componentId: "sc-1melv9r-0"
})(["margin-top:10px;font-size:12px;"]);
function Option({
  link = null,
  clickable = true,
  size,
  onClick = null,
  color,
  header,
  subheader = null,
  icon,
  active = false,
  id
}) {
  const content = /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    onClick: onClick,
    className: `flex items-center justify-between w-full p-3 rounded cursor-pointer ${!active ? 'bg-dark-800 hover:bg-dark-700' : 'bg-dark-1000'}`,
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex items-center",
        children: [active && /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "w-4 h-4 mr-4 rounded-full",
          style: {
            background: color
          }
        }), header]
      }), subheader && /*#__PURE__*/jsx_runtime_.jsx(SubHeader, {
        children: subheader
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
      src: icon,
      alt: 'Icon',
      width: "32px",
      height: "32px"
    })]
  });

  if (link) {
    return /*#__PURE__*/jsx_runtime_.jsx("a", {
      href: link,
      children: content
    });
  }

  return !active ? content : /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "w-full p-px rounded bg-gradient-to-r from-blue to-pink",
    children: content
  });
}
// EXTERNAL MODULE: ./src/components/Dots/index.tsx
var Dots = __webpack_require__(8561);
// EXTERNAL MODULE: external "polished"
var external_polished_ = __webpack_require__(7158);
;// CONCATENATED MODULE: ./src/modals/WalletModal/PendingView.tsx










const PendingSection = external_styled_components_default().div.withConfig({
  displayName: "PendingView__PendingSection",
  componentId: "sc-1qnlplp-0"
})(["align-items:center;justify-content:center;width:100%;& > *{width:100%;}"]);
const StyledLoader = external_styled_components_default()(Loader/* default */.Z).withConfig({
  displayName: "PendingView__StyledLoader",
  componentId: "sc-1qnlplp-1"
})(["margin-right:1rem;"]);
const LoadingMessage = external_styled_components_default().div.withConfig({
  displayName: "PendingView__LoadingMessage",
  componentId: "sc-1qnlplp-2"
})(["align-items:center;justify-content:flex-start;margin-bottom:20px;& > *{padding:1rem;}"]);
const ErrorGroup = external_styled_components_default().div.withConfig({
  displayName: "PendingView__ErrorGroup",
  componentId: "sc-1qnlplp-3"
})(["align-items:center;justify-content:flex-start;"]);
const ErrorButton = external_styled_components_default().div.withConfig({
  displayName: "PendingView__ErrorButton",
  componentId: "sc-1qnlplp-4"
})(["border-radius:8px;font-size:12px;margin-left:1rem;padding:0.5rem;font-weight:600;user-select:none;&:hover{cursor:pointer;}"]);
const LoadingWrapper = external_styled_components_default().div.withConfig({
  displayName: "PendingView__LoadingWrapper",
  componentId: "sc-1qnlplp-5"
})(["align-items:center;justify-content:center;"]);
function PendingView({
  connector,
  error = false,
  setPendingError,
  tryActivation
}) {
  var _window, _window$ethereum;

  const isMetamask = (_window = window) === null || _window === void 0 ? void 0 : (_window$ethereum = _window.ethereum) === null || _window$ethereum === void 0 ? void 0 : _window$ethereum.isMetaMask;
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(PendingSection, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(LoadingMessage, {
      error: error,
      children: /*#__PURE__*/jsx_runtime_.jsx(LoadingWrapper, {
        children: error ? /*#__PURE__*/(0,jsx_runtime_.jsxs)(ErrorGroup, {
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            children: "Error connecting."
          }), /*#__PURE__*/jsx_runtime_.jsx(ErrorButton, {
            onClick: () => {
              setPendingError(false);
              connector && tryActivation(connector);
            },
            children: "Try Again"
          })]
        }) : /*#__PURE__*/jsx_runtime_.jsx(Dots/* default */.Z, {
          children: "Initializing"
        })
      })
    }), Object.keys(constants/* SUPPORTED_WALLETS */.Vp).map(key => {
      const option = constants/* SUPPORTED_WALLETS */.Vp[key];

      if (option.connector === connector) {
        if (option.connector === connectors/* injected */.Lj) {
          if (isMetamask && option.name !== 'MetaMask') {
            return null;
          }

          if (!isMetamask && option.name === 'MetaMask') {
            return null;
          }
        }

        return /*#__PURE__*/jsx_runtime_.jsx(Option, {
          id: `connect-${key}`,
          clickable: false,
          color: option.color,
          header: option.name,
          subheader: option.description,
          icon: '/images/wallets/' + option.iconName
        }, key);
      }

      return null;
    })]
  });
}
// EXTERNAL MODULE: external "react-ga"
var external_react_ga_ = __webpack_require__(9831);
var external_react_ga_default = /*#__PURE__*/__webpack_require__.n(external_react_ga_);
// EXTERNAL MODULE: external "@web3-react/walletconnect-connector"
var walletconnect_connector_ = __webpack_require__(9650);
// EXTERNAL MODULE: external "react-device-detect"
var external_react_device_detect_ = __webpack_require__(2047);
// EXTERNAL MODULE: ./src/hooks/usePrevious.ts
var usePrevious = __webpack_require__(4751);
;// CONCATENATED MODULE: ./src/modals/WalletModal/index.tsx























const CloseIcon = external_styled_components_default().div.withConfig({
  displayName: "WalletModal__CloseIcon",
  componentId: "sc-ljfs0f-0"
})(["position:absolute;right:0;top:0;&:hover{cursor:pointer;opacity:0.6;}"]);
const HeaderRow = external_styled_components_default().div.withConfig({
  displayName: "WalletModal__HeaderRow",
  componentId: "sc-ljfs0f-1"
})(["margin-bottom:1rem;"]);
const UpperSection = external_styled_components_default().div.withConfig({
  displayName: "WalletModal__UpperSection",
  componentId: "sc-ljfs0f-2"
})(["position:relative;h5{margin:0;margin-bottom:0.5rem;font-size:1rem;font-weight:400;}h5:last-child{margin-bottom:0px;}h4{margin-top:0;font-weight:500;}"]);
const OptionGrid = external_styled_components_default().div.withConfig({
  displayName: "WalletModal__OptionGrid",
  componentId: "sc-ljfs0f-3"
})(["display:grid;grid-gap:10px;grid-template-columns:1fr;"]);
const HoverText = external_styled_components_default().div.withConfig({
  displayName: "WalletModal__HoverText",
  componentId: "sc-ljfs0f-4"
})([":hover{cursor:pointer;}"]);
const WALLET_VIEWS = {
  OPTIONS: 'options',
  OPTIONS_SECONDARY: 'options_secondary',
  ACCOUNT: 'account',
  PENDING: 'pending'
};
function WalletModal({
  pendingTransactions,
  confirmedTransactions,
  ENSName
}) {
  // console.log({ ENSName })
  // important that these are destructed from the account-specific web3-react context
  const {
    active,
    account,
    connector,
    activate,
    error,
    deactivate
  } = (0,core_.useWeb3React)();
  const {
    i18n
  } = (0,react_.useLingui)();
  const {
    0: walletView,
    1: setWalletView
  } = (0,external_react_.useState)(WALLET_VIEWS.ACCOUNT);
  const {
    0: pendingWallet,
    1: setPendingWallet
  } = (0,external_react_.useState)();
  const {
    0: pendingError,
    1: setPendingError
  } = (0,external_react_.useState)();
  const walletModalOpen = (0,application_hooks/* useModalOpen */.oL)(application_actions/* ApplicationModal.WALLET */.Lk.WALLET);
  const toggleWalletModal = (0,application_hooks/* useWalletModalToggle */.mq)();
  const previousAccount = (0,usePrevious/* default */.Z)(account); // close on connection, when logged out before

  (0,external_react_.useEffect)(() => {
    if (account && !previousAccount && walletModalOpen) {
      toggleWalletModal();
    }
  }, [account, previousAccount, toggleWalletModal, walletModalOpen]); // always reset to account view

  (0,external_react_.useEffect)(() => {
    if (walletModalOpen) {
      setPendingError(false);
      setWalletView(WALLET_VIEWS.ACCOUNT);
    }
  }, [walletModalOpen]); // close modal when a connection is successful

  const activePrevious = (0,usePrevious/* default */.Z)(active);
  const connectorPrevious = (0,usePrevious/* default */.Z)(connector);
  (0,external_react_.useEffect)(() => {
    if (walletModalOpen && (active && !activePrevious || connector && connector !== connectorPrevious && !error)) {
      setWalletView(WALLET_VIEWS.ACCOUNT);
    }
  }, [setWalletView, active, error, connector, walletModalOpen, activePrevious, connectorPrevious]);

  const tryActivation = async connector => {
    var _conn$walletConnectPr, _conn$walletConnectPr2;

    let name = '';
    let conn = typeof connector === 'function' ? await connector() : connector;
    Object.keys(constants/* SUPPORTED_WALLETS */.Vp).map(key => {
      if (connector === constants/* SUPPORTED_WALLETS */.Vp[key].connector) {
        return name = constants/* SUPPORTED_WALLETS */.Vp[key].name;
      }

      return true;
    }); // log selected wallet

    external_react_ga_default().event({
      category: 'Wallet',
      action: 'Change Wallet',
      label: name
    });
    setPendingWallet(conn); // set wallet for pending view

    setWalletView(WALLET_VIEWS.PENDING); // if the connector is walletconnect and the user has already tried to connect, manually reset the connector

    if (conn instanceof walletconnect_connector_.WalletConnectConnector && (_conn$walletConnectPr = conn.walletConnectProvider) !== null && _conn$walletConnectPr !== void 0 && (_conn$walletConnectPr2 = _conn$walletConnectPr.wc) !== null && _conn$walletConnectPr2 !== void 0 && _conn$walletConnectPr2.uri) {
      conn.walletConnectProvider = undefined;
    }

    conn && activate(conn, undefined, true).catch(error => {
      if (error instanceof core_.UnsupportedChainIdError) {
        activate(conn); // a little janky...can't use setError because the connector isn't set
      } else {
        setPendingError(true);
      }
    });
  }; // close wallet modal if fortmatic modal is active


  (0,external_react_.useEffect)(() => {
    connectors/* fortmatic.on */.pp.on(Fortmatic/* OVERLAY_READY */.P, () => {
      toggleWalletModal();
    });
  }, [toggleWalletModal]); // get wallets user can switch too, depending on device/browser

  function getOptions() {
    const isMetamask = window.ethereum && window.ethereum.isMetaMask;
    return Object.keys(constants/* SUPPORTED_WALLETS */.Vp).map(key => {
      const option = constants/* SUPPORTED_WALLETS */.Vp[key]; // check for mobile options

      if (external_react_device_detect_.isMobile) {
        // disable portis on mobile for now
        if (option.connector === connectors/* portis */.yO) {
          return null;
        }

        if (!window.web3 && !window.ethereum && option.mobile) {
          return /*#__PURE__*/jsx_runtime_.jsx(Option, {
            onClick: () => {
              option.connector !== connector && !option.href && tryActivation(option.connector);
            },
            id: `connect-${key}`,
            active: option.connector && option.connector === connector,
            color: option.color,
            link: option.href,
            header: option.name,
            subheader: null,
            icon: '/images/wallets/' + option.iconName
          }, key);
        }

        return null;
      } // overwrite injected when needed


      if (option.connector === connectors/* injected */.Lj) {
        // don't show injected if there's no injected provider
        if (!(window.web3 || window.ethereum)) {
          if (option.name === 'MetaMask') {
            return /*#__PURE__*/jsx_runtime_.jsx(Option, {
              id: `connect-${key}`,
              color: '#E8831D',
              header: 'Install Metamask',
              subheader: null,
              link: 'https://metamask.io/',
              icon: "/images/wallets/metamask.png"
            }, key);
          } else {
            return null; // dont want to return install twice
          }
        } // don't return metamask if injected provider isn't metamask
        else if (option.name === 'MetaMask' && !isMetamask) {
            return null;
          } // likewise for generic
          else if (option.name === 'Injected' && isMetamask) {
              return null;
            }
      } // return rest of options


      return !external_react_device_detect_.isMobile && !option.mobileOnly && /*#__PURE__*/jsx_runtime_.jsx(Option, {
        id: `connect-${key}`,
        onClick: () => {
          option.connector === connector ? setWalletView(WALLET_VIEWS.ACCOUNT) : !option.href && tryActivation(option.connector);
        },
        active: option.connector === connector,
        color: option.color,
        link: option.href,
        header: option.name,
        subheader: null // use option.descriptio to bring back multi-line
        ,
        icon: '/images/wallets/' + option.iconName
      }, key);
    });
  }

  function getModalContent() {
    if (error) {
      return /*#__PURE__*/(0,jsx_runtime_.jsxs)(UpperSection, {
        children: [/*#__PURE__*/jsx_runtime_.jsx(CloseIcon, {
          onClick: toggleWalletModal,
          children: /*#__PURE__*/jsx_runtime_.jsx(esm/* XIcon */.b0D, {
            width: "24px",
            height: "24px"
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(HeaderRow, {
          style: {
            paddingLeft: 0,
            paddingRight: 0
          },
          children: error instanceof core_.UnsupportedChainIdError ? i18n._(
          /*i18n*/
          i18n._("Wrong Network")) : i18n._(
          /*i18n*/
          i18n._("Error connecting"))
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          children: [error instanceof core_.UnsupportedChainIdError ? /*#__PURE__*/jsx_runtime_.jsx("h5", {
            children: i18n._(
            /*i18n*/
            i18n._("Please connect to the appropriate Ethereum network."))
          }) : i18n._(
          /*i18n*/
          i18n._("Error connecting. Try refreshing the page.")), /*#__PURE__*/jsx_runtime_.jsx("div", {
            style: {
              marginTop: '1rem'
            }
          }), /*#__PURE__*/jsx_runtime_.jsx(Button/* ButtonError */.Kd, {
            error: true,
            size: "sm",
            onClick: deactivate,
            children: i18n._(
            /*i18n*/
            i18n._("Disconnect"))
          })]
        })]
      });
    }

    if (account && walletView === WALLET_VIEWS.ACCOUNT) {
      return /*#__PURE__*/jsx_runtime_.jsx(components_AccountDetails, {
        toggleWalletModal: toggleWalletModal,
        pendingTransactions: pendingTransactions,
        confirmedTransactions: confirmedTransactions,
        ENSName: ENSName,
        openOptions: () => setWalletView(WALLET_VIEWS.OPTIONS)
      });
    }

    return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "flex flex-col space-y-4",
      children: [/*#__PURE__*/jsx_runtime_.jsx(ModalHeader/* default */.Z, {
        title: "Select a Wallet",
        onClose: toggleWalletModal
      }), walletView === WALLET_VIEWS.ACCOUNT && /*#__PURE__*/jsx_runtime_.jsx(HeaderRow, {
        children: /*#__PURE__*/jsx_runtime_.jsx(HoverText, {
          children: i18n._(
          /*i18n*/
          i18n._("Connect to a wallet"))
        })
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col space-y-6",
        children: [walletView === WALLET_VIEWS.PENDING ? /*#__PURE__*/jsx_runtime_.jsx(PendingView, {
          connector: pendingWallet,
          error: pendingError,
          setPendingError: setPendingError,
          tryActivation: tryActivation
        }) : /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "flex flex-col space-y-5 overflow-y-auto",
          children: getOptions()
        }), walletView !== WALLET_VIEWS.PENDING && /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex flex-col text-center",
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "text-secondary",
            children: i18n._(
            /*i18n*/
            i18n._("New to Ethereum?"))
          }), /*#__PURE__*/jsx_runtime_.jsx(ExternalLink/* default */.Z, {
            href: "https://ethereum.org/wallets/",
            color: "blue",
            children: i18n._(
            /*i18n*/
            i18n._("Learn more about wallets"))
          })]
        })]
      })]
    });
  }

  return /*#__PURE__*/jsx_runtime_.jsx(Modal/* default */.Z, {
    isOpen: walletModalOpen,
    onDismiss: toggleWalletModal,
    minHeight: false,
    maxHeight: 90,
    children: getModalContent()
  });
}
// EXTERNAL MODULE: ./src/components/Web3Connect/index.tsx
var Web3Connect = __webpack_require__(1394);
// EXTERNAL MODULE: ./src/functions/format.ts
var format = __webpack_require__(8277);
// EXTERNAL MODULE: ./src/hooks/useENSName.ts
var useENSName = __webpack_require__(7816);
;// CONCATENATED MODULE: ./src/components/Web3Status/index.tsx

















const IconWrapper = external_styled_components_default().div.withConfig({
  displayName: "Web3Status__IconWrapper",
  componentId: "sc-ii8b62-0"
})(["display:flex;flex-flow:column nowrap;align-items:center;justify-content:center;& > *{height:", ";width:", ";}"], ({
  size
}) => size ? size + 'px' : '32px', ({
  size
}) => size ? size + 'px' : '32px'); // we want the latest one to come first, so return negative if a is after b

function newTransactionsFirst(a, b) {
  return b.addedTime - a.addedTime;
}

const SOCK = /*#__PURE__*/jsx_runtime_.jsx("span", {
  role: "img",
  "aria-label": "has socks emoji",
  style: {
    marginTop: -4,
    marginBottom: -4
  },
  children: "\uD83E\uDDE6"
}); // eslint-disable-next-line react/prop-types


function StatusIcon({
  connector
}) {
  if (connector === connectors/* injected */.Lj) {
    return /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
      src: "/chef.svg",
      alt: "Injected (MetaMask etc...)",
      width: 20,
      height: 20
    }); // return <Identicon />
  } else if (connector === connectors/* walletconnect */.Lw) {
    return /*#__PURE__*/jsx_runtime_.jsx(IconWrapper, {
      size: 16,
      children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
        src: "/images/wallets/wallet-connect.png",
        alt: 'Wallet Connect',
        width: "16px",
        height: "16px"
      })
    });
  } else if (connector.constructor.name === 'LatticeConnector') {
    return /*#__PURE__*/jsx_runtime_.jsx(IconWrapper, {
      size: 16,
      children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
        src: "/images/wallets/lattice.png",
        alt: 'Lattice',
        width: "16px",
        height: "16px"
      })
    });
  } else if (connector === connectors/* walletlink */.H5) {
    return /*#__PURE__*/jsx_runtime_.jsx(IconWrapper, {
      size: 16,
      children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
        src: "/images/wallets/coinbase.svg",
        alt: 'Coinbase Wallet',
        width: "16px",
        height: "16px"
      })
    });
  } else if (connector === connectors/* fortmatic */.pp) {
    return /*#__PURE__*/jsx_runtime_.jsx(IconWrapper, {
      size: 16,
      children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
        src: "/images/wallets/fortmatic.png",
        alt: 'Fortmatic',
        width: "16px",
        height: "16px"
      })
    });
  } else if (connector === connectors/* portis */.yO) {
    return /*#__PURE__*/jsx_runtime_.jsx(IconWrapper, {
      size: 16,
      children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
        src: "/images/wallets/portis.png",
        alt: 'Portis',
        width: "16px",
        height: "16px"
      })
    });
  }

  return null;
}

function Web3StatusInner() {
  const {
    i18n
  } = (0,react_.useLingui)();
  const {
    account,
    connector
  } = (0,core_.useWeb3React)();
  const {
    ENSName
  } = (0,useENSName/* default */.Z)(account !== null && account !== void 0 ? account : undefined);
  const allTransactions = (0,hooks/* useAllTransactions */.kf)();
  const sortedRecentTransactions = (0,external_react_.useMemo)(() => {
    const txs = Object.values(allTransactions);
    return txs.filter(hooks/* isTransactionRecent */.mH).sort(newTransactionsFirst);
  }, [allTransactions]);
  const pending = sortedRecentTransactions.filter(tx => {
    if (tx.receipt) {
      return false;
    } else if (tx.archer && tx.archer.deadline * 1000 - Date.now() < 0) {
      return false;
    } else {
      return true;
    }
  }).map(tx => tx.hash);
  const hasPendingTransactions = !!pending.length;
  const toggleWalletModal = (0,application_hooks/* useWalletModalToggle */.mq)();

  if (account) {
    return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      id: "web3-status-connected",
      className: "flex items-center px-3 py-2 text-sm rounded-lg bg-dark-1000 text-secondary",
      onClick: toggleWalletModal,
      children: [hasPendingTransactions ? /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex items-center justify-between",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "pr-2",
          children: [pending === null || pending === void 0 ? void 0 : pending.length, " ", i18n._(
          /*i18n*/
          i18n._("Pending"))]
        }), ' ', /*#__PURE__*/jsx_runtime_.jsx(Loader/* default */.Z, {
          stroke: "white"
        })]
      }) : /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "mr-2",
        children: ENSName || (0,format/* shortenAddress */.Xn)(account)
      }), !hasPendingTransactions && connector && /*#__PURE__*/jsx_runtime_.jsx(StatusIcon, {
        connector: connector
      })]
    });
  } else {
    return /*#__PURE__*/jsx_runtime_.jsx(Web3Connect/* default */.Z, {
      style: {
        paddingTop: '6px',
        paddingBottom: '6px'
      }
    });
  }
}

function Web3Status() {
  const {
    active,
    account
  } = (0,core_.useWeb3React)();
  const contextNetwork = (0,core_.useWeb3React)(constants/* NetworkContextName */.AQ);
  const {
    ENSName
  } = (0,useENSName/* default */.Z)(account !== null && account !== void 0 ? account : undefined);
  const allTransactions = (0,hooks/* useAllTransactions */.kf)();
  const sortedRecentTransactions = (0,external_react_.useMemo)(() => {
    const txs = Object.values(allTransactions);
    return txs.filter(hooks/* isTransactionRecent */.mH).sort(newTransactionsFirst);
  }, [allTransactions]);
  const pending = sortedRecentTransactions.filter(tx => !tx.receipt).map(tx => tx.hash);
  const confirmed = sortedRecentTransactions.filter(tx => tx.receipt).map(tx => tx.hash);

  if (!contextNetwork.active && !active) {
    return null;
  }

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(Web3StatusInner, {}), /*#__PURE__*/jsx_runtime_.jsx(WalletModal, {
      ENSName: ENSName !== null && ENSName !== void 0 ? ENSName : undefined,
      pendingTransactions: pending,
      confirmedTransactions: confirmed
    })]
  });
}

/***/ }),

/***/ 4965:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "w": function() { return /* binding */ NETWORK_ICON; },
/* harmony export */   "z": function() { return /* binding */ NETWORK_LABEL; }
/* harmony export */ });
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6766);
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__);

const Arbitrum = '/images/networks/arbitrum-network.jpg';
const Avalanche = '/images/networks/avalanche-network.jpg';
const Bsc = '/images/networks/bsc-network.jpg';
const Fantom = '/images/networks/fantom-network.jpg';
const Goerli = '/images/networks/goerli-network.jpg';
const Harmony = '/images/networks/harmonyone-network.jpg';
const Heco = '/images/networks/heco-network.jpg';
const Kovan = '/images/networks/kovan-network.jpg';
const Mainnet = '/images/networks/mainnet-network.jpg';
const Matic = '/images/networks/matic-network.jpg';
const Moonbeam = '/images/networks/moonbeam-network.jpg';
const OKEx = '/images/networks/okex-network.jpg';
const Polygon = '/images/networks/polygon-network.jpg';
const Rinkeby = '/images/networks/rinkeby-network.jpg';
const Ropsten = '/images/networks/ropsten-network.jpg';
const xDai = '/images/networks/xdai-network.jpg';
const Celo = '/images/networks/celo-network.jpg';
const NETWORK_ICON = {
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET]: Mainnet,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.ROPSTEN]: Ropsten,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.RINKEBY]: Rinkeby,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId["GÖRLI"]]: Goerli,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.KOVAN]: Kovan,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.FANTOM]: Fantom,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.FANTOM_TESTNET]: Fantom,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.BSC]: Bsc,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.BSC_TESTNET]: Bsc,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC]: Polygon,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC_TESTNET]: Matic,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.XDAI]: xDai,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.ARBITRUM]: Arbitrum,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.ARBITRUM_TESTNET]: Arbitrum,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MOONBEAM_TESTNET]: Moonbeam,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.AVALANCHE]: Avalanche,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.AVALANCHE_TESTNET]: Avalanche,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HECO]: Heco,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HECO_TESTNET]: Heco,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HARMONY]: Harmony,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HARMONY_TESTNET]: Harmony,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.OKEX]: OKEx,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.OKEX_TESTNET]: OKEx,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.CELO]: Celo
};
const NETWORK_LABEL = {
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET]: 'Ethereum',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.RINKEBY]: 'Rinkeby',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.ROPSTEN]: 'Ropsten',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId["GÖRLI"]]: 'Görli',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.KOVAN]: 'Kovan',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.FANTOM]: 'Fantom',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.FANTOM_TESTNET]: 'Fantom Testnet',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC]: 'Polygon (Matic)',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC_TESTNET]: 'Matic Testnet',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.XDAI]: 'xDai',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.ARBITRUM]: 'Arbitrum',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.ARBITRUM_TESTNET]: 'Arbitrum Testnet',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.BSC]: 'BSC',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.BSC_TESTNET]: 'BSC Testnet',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MOONBEAM_TESTNET]: 'Moonbase',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.AVALANCHE]: 'Avalanche',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.AVALANCHE_TESTNET]: 'Fuji',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HECO]: 'HECO',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HECO_TESTNET]: 'HECO Testnet',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HARMONY]: 'Harmony',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HARMONY_TESTNET]: 'Harmony Testnet',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.OKEX]: 'OKEx',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.OKEX_TESTNET]: 'OKEx',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.CELO]: 'Celo'
};

/***/ }),

/***/ 451:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": function() { return /* binding */ useDebounce; }
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
 // modified from https://usehooks.com/useDebounce/

function useDebounce(value, delay) {
  const {
    0: debouncedValue,
    1: setDebouncedValue
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(value);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    // Update debounced value after delay
    const handler = setTimeout(() => {
      setDebouncedValue(value);
    }, delay); // Cancel the timeout if value changes (also on delay change or unmount)
    // This is how we prevent debounced value from updating if value is changed ...
    // .. within the delay period. Timeout gets cleared and restarted.

    return () => {
      clearTimeout(handler);
    };
  }, [value, delay]);
  return debouncedValue;
}

/***/ }),

/***/ 7816:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": function() { return /* binding */ useENSName; }
/* harmony export */ });
/* harmony import */ var ethers_lib_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1674);
/* harmony import */ var ethers_lib_utils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(ethers_lib_utils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _useContract__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6699);
/* harmony import */ var _functions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7735);
/* harmony import */ var _useDebounce__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(451);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _state_multicall_hooks__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(879);






/**
 * Does a reverse lookup for an address to find its ENS name.
 * Note this is not the same as looking up an ENS name to find an address.
 */

function useENSName(address) {
  var _resolverAddress$resu, _name$result$, _name$result;

  const debouncedAddress = (0,_useDebounce__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z)(address, 200);
  const ensNodeArgument = (0,react__WEBPACK_IMPORTED_MODULE_4__.useMemo)(() => {
    if (!debouncedAddress || !(0,ethers_lib_utils__WEBPACK_IMPORTED_MODULE_0__.isAddress)(debouncedAddress)) return [undefined];

    try {
      return debouncedAddress ? [(0,ethers_lib_utils__WEBPACK_IMPORTED_MODULE_0__.namehash)(`${debouncedAddress.toLowerCase().substr(2)}.addr.reverse`)] : [undefined];
    } catch (error) {
      return [undefined];
    }
  }, [debouncedAddress]);
  const registrarContract = (0,_useContract__WEBPACK_IMPORTED_MODULE_1__/* .useENSRegistrarContract */ .zb)(false);
  const resolverAddress = (0,_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_5__/* .useSingleCallResult */ .Wk)(registrarContract, 'resolver', ensNodeArgument);
  const resolverAddressResult = (_resolverAddress$resu = resolverAddress.result) === null || _resolverAddress$resu === void 0 ? void 0 : _resolverAddress$resu[0];
  const resolverContract = (0,_useContract__WEBPACK_IMPORTED_MODULE_1__/* .useENSResolverContract */ .uU)(resolverAddressResult && !(0,_functions__WEBPACK_IMPORTED_MODULE_2__/* .isZero */ .Fr)(resolverAddressResult) ? resolverAddressResult : undefined, false);
  const name = (0,_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_5__/* .useSingleCallResult */ .Wk)(resolverContract, 'name', ensNodeArgument);
  const changed = debouncedAddress !== address;
  return {
    ENSName: changed ? null : (_name$result$ = (_name$result = name.result) === null || _name$result === void 0 ? void 0 : _name$result[0]) !== null && _name$result$ !== void 0 ? _name$result$ : null,
    loading: changed || resolverAddress.loading || name.loading
  };
}

/***/ }),

/***/ 2269:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": function() { return /* binding */ useInterval; }
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

function useInterval(callback, delay, leading = true) {
  const savedCallback = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(); // Remember the latest callback.

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    savedCallback.current = callback;
  }, [callback]); // Set up the interval.

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    function tick() {
      const current = savedCallback.current;
      current && current();
    }

    if (delay !== null) {
      if (leading) tick();
      const id = setInterval(tick, delay);
      return () => clearInterval(id);
    }

    return undefined;
  }, [delay, leading]);
}

/***/ }),

/***/ 4751:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": function() { return /* binding */ usePrevious; }
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
 // modified from https://usehooks.com/usePrevious/

function usePrevious(value) {
  // The ref object is a generic container whose current property is mutable ...
  // ... and can hold any value, similar to an instance property on a class
  const ref = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(); // Store current value in ref

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    ref.current = value;
  }, [value]); // Only re-run if value changes
  // Return previous value (happens before update in useEffect above)

  return ref.current;
}

/***/ }),

/***/ 8828:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "b": function() { return /* binding */ SUPPORTED_NETWORKS; },
/* harmony export */   "Z": function() { return /* binding */ NetworkModal; }
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constants_networks__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4965);
/* harmony import */ var _state_application_hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4663);
/* harmony import */ var _state_application_actions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(434);
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6766);
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5675);
/* harmony import */ var _components_Modal__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1441);
/* harmony import */ var _components_ModalHeader__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7144);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var cookie_cutter__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8760);
/* harmony import */ var cookie_cutter__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(cookie_cutter__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8269);












const SUPPORTED_NETWORKS = {
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_4__.ChainId.MAINNET]: {
    chainId: '0x1',
    chainName: 'Ethereum',
    nativeCurrency: {
      name: 'Ethereum',
      symbol: 'ETH',
      decimals: 18
    },
    rpcUrls: ['https://mainnet.infura.io/v3'],
    blockExplorerUrls: ['https://etherscan.com']
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_4__.ChainId.FANTOM]: {
    chainId: '0xfa',
    chainName: 'Fantom',
    nativeCurrency: {
      name: 'Fantom',
      symbol: 'FTM',
      decimals: 18
    },
    rpcUrls: ['https://rpcapi.fantom.network'],
    blockExplorerUrls: ['https://ftmscan.com']
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_4__.ChainId.BSC]: {
    chainId: '0x38',
    chainName: 'Binance Smart Chain',
    nativeCurrency: {
      name: 'Binance Coin',
      symbol: 'BNB',
      decimals: 18
    },
    rpcUrls: ['https://bsc-dataseed.binance.org'],
    blockExplorerUrls: ['https://bscscan.com']
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_4__.ChainId.MATIC]: {
    chainId: '0x89',
    chainName: 'Matic',
    nativeCurrency: {
      name: 'Matic',
      symbol: 'MATIC',
      decimals: 18
    },
    rpcUrls: ['https://rpc-mainnet.maticvigil.com'],
    // ['https://matic-mainnet.chainstacklabs.com/'],
    blockExplorerUrls: ['https://explorer-mainnet.maticvigil.com']
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_4__.ChainId.HECO]: {
    chainId: '0x80',
    chainName: 'Heco',
    nativeCurrency: {
      name: 'Heco Token',
      symbol: 'HT',
      decimals: 18
    },
    rpcUrls: ['https://http-mainnet.hecochain.com'],
    blockExplorerUrls: ['https://hecoinfo.com']
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_4__.ChainId.XDAI]: {
    chainId: '0x64',
    chainName: 'xDai',
    nativeCurrency: {
      name: 'xDai Token',
      symbol: 'xDai',
      decimals: 18
    },
    rpcUrls: ['https://rpc.xdaichain.com'],
    blockExplorerUrls: ['https://blockscout.com/poa/xdai']
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_4__.ChainId.HARMONY]: {
    chainId: '0x63564C40',
    chainName: 'Harmony',
    nativeCurrency: {
      name: 'One Token',
      symbol: 'ONE',
      decimals: 18
    },
    rpcUrls: ['https://api.harmony.one', 'https://s1.api.harmony.one', 'https://s2.api.harmony.one', 'https://s3.api.harmony.one'],
    blockExplorerUrls: ['https://explorer.harmony.one/']
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_4__.ChainId.AVALANCHE]: {
    chainId: '0xA86A',
    chainName: 'Avalanche',
    nativeCurrency: {
      name: 'Avalanche Token',
      symbol: 'AVAX',
      decimals: 18
    },
    rpcUrls: ['https://api.avax.network/ext/bc/C/rpc'],
    blockExplorerUrls: ['https://cchain.explorer.avax.network']
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_4__.ChainId.OKEX]: {
    chainId: '0x42',
    chainName: 'OKEx',
    nativeCurrency: {
      name: 'OKEx Token',
      symbol: 'OKT',
      decimals: 18
    },
    rpcUrls: ['https://exchainrpc.okex.org'],
    blockExplorerUrls: ['https://www.oklink.com/okexchain']
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_4__.ChainId.ARBITRUM]: {
    chainId: '0xA4B1',
    chainName: 'Arbitrum',
    nativeCurrency: {
      name: 'Ethereum',
      symbol: 'ETH',
      decimals: 18
    },
    rpcUrls: ['https://arb1.arbitrum.io/rpc'],
    blockExplorerUrls: ['https://mainnet-arb-explorer.netlify.app']
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_4__.ChainId.CELO]: {
    chainId: '0xA4EC',
    chainName: 'Celo',
    nativeCurrency: {
      name: 'Celo',
      symbol: 'CELO',
      decimals: 18
    },
    rpcUrls: ['https://forno.celo.org'],
    blockExplorerUrls: ['https://explorer.celo.org']
  }
};
function NetworkModal() {
  const {
    chainId,
    library,
    account
  } = (0,_hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_10__/* .useActiveWeb3React */ .a)();
  const networkModalOpen = (0,_state_application_hooks__WEBPACK_IMPORTED_MODULE_2__/* .useModalOpen */ .oL)(_state_application_actions__WEBPACK_IMPORTED_MODULE_3__/* .ApplicationModal.NETWORK */ .Lk.NETWORK);
  const toggleNetworkModal = (0,_state_application_hooks__WEBPACK_IMPORTED_MODULE_2__/* .useNetworkModalToggle */ .o)();
  if (!chainId) return null;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Modal__WEBPACK_IMPORTED_MODULE_6__/* .default */ .Z, {
    isOpen: networkModalOpen,
    onDismiss: toggleNetworkModal,
    maxWidth: 672,
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ModalHeader__WEBPACK_IMPORTED_MODULE_7__/* .default */ .Z, {
      onClose: toggleNetworkModal,
      title: "Select a Network"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
      className: "mb-6 text-lg text-primary",
      children: ["You are currently browsing ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
        className: "font-bold text-pink",
        children: "SUSHI"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), " on the ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
        className: "font-bold text-blue",
        children: _constants_networks__WEBPACK_IMPORTED_MODULE_1__/* .NETWORK_LABEL */ .z[chainId]
      }), " network"]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
      className: "grid grid-flow-row-dense grid-cols-1 gap-5 overflow-y-auto md:grid-cols-2",
      children: [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_4__.ChainId.MAINNET, _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_4__.ChainId.MATIC, _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_4__.ChainId.FANTOM, // ChainId.ARBITRUM,
      _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_4__.ChainId.OKEX, _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_4__.ChainId.HECO, _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_4__.ChainId.BSC, _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_4__.ChainId.XDAI, _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_4__.ChainId.HARMONY, _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_4__.ChainId.AVALANCHE, _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_4__.ChainId.CELO].map((key, i) => {
        if (chainId === key) {
          return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
            className: "w-full col-span-1 p-px rounded bg-gradient-to-r from-blue to-pink",
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
              className: "flex items-center w-full h-full p-3 space-x-3 rounded bg-dark-1000",
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_5__.default, {
                src: _constants_networks__WEBPACK_IMPORTED_MODULE_1__/* .NETWORK_ICON */ .w[key],
                alt: `Switch to ${_constants_networks__WEBPACK_IMPORTED_MODULE_1__/* .NETWORK_LABEL */ .z[key]} Network`,
                className: "rounded-md",
                width: "32px",
                height: "32px"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "font-bold text-primary",
                children: _constants_networks__WEBPACK_IMPORTED_MODULE_1__/* .NETWORK_LABEL */ .z[key]
              })]
            })
          }, i);
        }

        return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
          onClick: () => {
            toggleNetworkModal();
            const params = SUPPORTED_NETWORKS[key];
            cookie_cutter__WEBPACK_IMPORTED_MODULE_9___default().set('chainId', key);

            if (key === _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_4__.ChainId.MAINNET) {
              library === null || library === void 0 ? void 0 : library.send('wallet_switchEthereumChain', [{
                chainId: '0x1'
              }, account]);
            } else {
              library === null || library === void 0 ? void 0 : library.send('wallet_addEthereumChain', [params, account]);
            }
          },
          className: "flex items-center w-full col-span-1 p-3 space-x-3 rounded cursor-pointer bg-dark-800 hover:bg-dark-700",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_5__.default, {
            src: _constants_networks__WEBPACK_IMPORTED_MODULE_1__/* .NETWORK_ICON */ .w[key],
            alt: "Switch Network",
            className: "rounded-md",
            width: "32px",
            height: "32px"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "font-bold text-primary",
            children: _constants_networks__WEBPACK_IMPORTED_MODULE_1__/* .NETWORK_LABEL */ .z[key]
          })]
        }, i);
      })
    })]
  });
}

/***/ })

};
;