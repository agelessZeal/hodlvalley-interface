exports.id = 1441;
exports.ids = [1441];
exports.modules = {

/***/ 1441:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": function() { return /* binding */ Modal; }
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _reach_dialog_styles_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6938);
/* harmony import */ var _reach_dialog_styles_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_reach_dialog_styles_css__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _reach_dialog__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(617);
/* harmony import */ var _reach_dialog__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_reach_dialog__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_spring__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6821);
/* harmony import */ var react_spring__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_spring__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9914);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_device_detect__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2047);
/* harmony import */ var react_device_detect__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_device_detect__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var polished__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7158);
/* harmony import */ var polished__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(polished__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_use_gesture__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8189);
/* harmony import */ var react_use_gesture__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_use_gesture__WEBPACK_IMPORTED_MODULE_8__);




function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }









const AnimatedDialogOverlay = (0,react_spring__WEBPACK_IMPORTED_MODULE_3__.animated)(_reach_dialog__WEBPACK_IMPORTED_MODULE_2__.DialogOverlay);
const StyledDialogOverlay = styled_components__WEBPACK_IMPORTED_MODULE_4___default()(AnimatedDialogOverlay).withConfig({
  displayName: "Modal__StyledDialogOverlay",
  componentId: "sc-170vgfd-0"
})(["backdrop-filter:blur(10px);&[data-reach-dialog-overlay]{z-index:10;background-color:transparent;overflow:hidden;display:flex;align-items:center;justify-content:center;background-color:rgba(0,0,0,0.425);}"]);
const AnimatedDialogContent = (0,react_spring__WEBPACK_IMPORTED_MODULE_3__.animated)(_reach_dialog__WEBPACK_IMPORTED_MODULE_2__.DialogContent); // destructure to not pass custom props to Dialog DOM element

const StyledDialogContent = styled_components__WEBPACK_IMPORTED_MODULE_4___default()((_ref) => {
  let {
    minHeight,
    maxHeight,
    maxWidth,
    mobile,
    isOpen
  } = _ref,
      rest = _objectWithoutProperties(_ref, ["minHeight", "maxHeight", "maxWidth", "mobile", "isOpen"]);

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(AnimatedDialogContent, _objectSpread({}, rest));
}).attrs({
  'aria-label': 'dialog'
}).withConfig({
  displayName: "Modal__StyledDialogContent",
  componentId: "sc-170vgfd-1"
})(["overflow-y:auto;&[data-reach-dialog-content]{display:flex;align-self:", ";margin:4rem 0.5rem;padding:0;background-color:#000;box-shadow:0 4px 8px 0 ", ";width:100vw;border-radius:10px;overflow-y:auto;overflow-x:hidden;", " ", " ", " @media (min-width:640px){width:65vw;margin:0;}}"], ({
  mobile
}) => mobile ? 'flex-end' : 'center', () => (0,polished__WEBPACK_IMPORTED_MODULE_7__.transparentize)(0.95, '#000'), ({
  maxWidth
}) => maxWidth && (0,styled_components__WEBPACK_IMPORTED_MODULE_4__.css)(["max-width:", "px;"], maxWidth), ({
  maxHeight
}) => maxHeight && (0,styled_components__WEBPACK_IMPORTED_MODULE_4__.css)(["max-height:", "vh;"], maxHeight), ({
  minHeight
}) => minHeight && (0,styled_components__WEBPACK_IMPORTED_MODULE_4__.css)(["min-height:", "vh;"], minHeight));
function Modal({
  isOpen,
  onDismiss,
  minHeight = false,
  maxHeight = 90,
  initialFocusRef,
  children,
  padding = 5,
  maxWidth = 420
}) {
  const fadeTransition = (0,react_spring__WEBPACK_IMPORTED_MODULE_3__.useTransition)(isOpen, null, {
    config: {
      duration: 200
    },
    from: {
      opacity: 0
    },
    enter: {
      opacity: 1
    },
    leave: {
      opacity: 0
    }
  });
  const [{
    y
  }, set] = (0,react_spring__WEBPACK_IMPORTED_MODULE_3__.useSpring)(() => ({
    y: 0,
    config: {
      mass: 1,
      tension: 210,
      friction: 20
    }
  }));
  const bind = (0,react_use_gesture__WEBPACK_IMPORTED_MODULE_8__.useGesture)({
    onDrag: state => {
      set({
        y: state.down ? state.movement[1] : 0
      });

      if (state.movement[1] > 300 || state.velocity > 3 && state.direction[1] > 0) {
        onDismiss();
      }
    }
  });
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
    children: fadeTransition.map(({
      item,
      key,
      props
    }) => item && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledDialogOverlay, {
      style: props,
      onDismiss: onDismiss,
      initialFocusRef: initialFocusRef,
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledDialogContent, _objectSpread(_objectSpread({}, react_device_detect__WEBPACK_IMPORTED_MODULE_6__.isMobile ? _objectSpread(_objectSpread({}, bind()), {}, {
        style: {
          transform: y.interpolate(y => `translateY(${y > 0 ? y : 0}px)`)
        }
      }) : {}), {}, {
        "aria-label": "dialog content",
        minHeight: minHeight,
        maxHeight: maxHeight,
        maxWidth: maxWidth,
        mobile: react_device_detect__WEBPACK_IMPORTED_MODULE_6__.isMobile,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
          className: "w-full p-px rounded bg-gradient-to-r from-blue to-pink",
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: `flex flex-col h-full w-full bg-dark-900 rounded p-6 overflow-y-auto`,
            children: [!initialFocusRef && react_device_detect__WEBPACK_IMPORTED_MODULE_6__.isMobile ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
              tabIndex: 1
            }) : null, children]
          })
        })
      }))
    }, key))
  });
}

/***/ })

};
;