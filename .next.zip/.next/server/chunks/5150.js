exports.id = 5150;
exports.ids = [5150];
exports.modules = {

/***/ 1291:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": function() { return /* binding */ CardHeader; },
/* harmony export */   "D6": function() { return /* binding */ BorrowCardHeader; },
/* harmony export */   "L4": function() { return /* binding */ LendCardHeader; }
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _functions_styling__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1769);



function CardHeader({
  className,
  children
}) {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
    className: (0,_functions_styling__WEBPACK_IMPORTED_MODULE_2__/* .classNames */ .A)('flex items-center rounded-t px-4 sm:px-8 py-4 sm:py-6', className),
    children: children
  });
}
function BorrowCardHeader({
  children
}) {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CardHeader, {
    className: "border-b-8 bg-dark-pink border-pink",
    children: children
  });
}
function LendCardHeader({
  children
}) {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CardHeader, {
    className: "border-b-8 bg-dark-blue border-blue",
    children: children
  });
}

/***/ }),

/***/ 2212:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": function() { return /* binding */ Card; }
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);




function Card({
  header = undefined,
  footer = undefined,
  backgroundImage = '',
  title = '',
  description = '',
  children,
  className
}) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
    className: `relative ${className}`,
    style: {
      borderRadius: '10px',
      backgroundImage: `url(${backgroundImage})`,
      backgroundRepeat: 'no-repeat',
      backgroundSize: 'contain',
      backgroundPosition: 'center bottom'
    },
    children: [header && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
      children: header
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
      className: "px-2 py-4 sm:p-8",
      children: [title && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "mb-4 text-2xl text-high-emphesis",
        children: title
      }), description && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "text-base text-secondary",
        children: description
      }), children]
    }), footer && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
      children: footer
    })]
  });
}

/***/ }),

/***/ 6659:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);


const Main = ({
  children
}) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("main", {
  className: "flex flex-col items-center justify-start flex-grow w-full h-full px-4 py-4 sm:py-8 md:py-12",
  style: {
    height: 'max-content'
  },
  children: children
});

/* harmony default export */ __webpack_exports__["Z"] = (Main);

/***/ }),

/***/ 1522:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": function() { return /* binding */ components_Popups; }
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
// EXTERNAL MODULE: ./src/state/application/hooks.ts
var hooks = __webpack_require__(4663);
// EXTERNAL MODULE: ./src/state/user/hooks.tsx
var user_hooks = __webpack_require__(181);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: external "react-feather"
var external_react_feather_ = __webpack_require__(9337);
// EXTERNAL MODULE: ./src/components/Row/index.tsx
var Row = __webpack_require__(7745);
// EXTERNAL MODULE: ./src/components/ExternalLink/index.tsx
var ExternalLink = __webpack_require__(3106);
// EXTERNAL MODULE: ./src/functions/explorer.ts
var explorer = __webpack_require__(3302);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(9914);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
// EXTERNAL MODULE: ./src/hooks/index.ts + 2 modules
var src_hooks = __webpack_require__(9202);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/outline/esm/index.js + 230 modules
var esm = __webpack_require__(6049);
;// CONCATENATED MODULE: ./src/components/Popups/TransactionPopup.tsx










const RowNoFlex = external_styled_components_default()(Row/* AutoRow */.BA).withConfig({
  displayName: "TransactionPopup__RowNoFlex",
  componentId: "sc-45dfo1-0"
})(["flex-wrap:nowrap;"]);
function TransactionPopup({
  hash,
  success,
  summary
}) {
  const {
    chainId
  } = (0,src_hooks/* useActiveWeb3React */.aQ)();
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(RowNoFlex, {
    style: {
      zIndex: 1000
    },
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "pr-4",
      children: success ? /*#__PURE__*/jsx_runtime_.jsx(external_react_feather_.CheckCircle, {
        className: "text-2xl text-green"
      }) : /*#__PURE__*/jsx_runtime_.jsx(external_react_feather_.AlertCircle, {
        className: "text-2xl text-red"
      })
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "flex flex-col gap-1",
      children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "font-bold text-high-emphesis",
        children: summary !== null && summary !== void 0 ? summary : "Hash: " + hash.slice(0, 8) + "..." + hash.slice(58, 65)
      }), chainId && hash && /*#__PURE__*/jsx_runtime_.jsx(ExternalLink/* default */.Z, {
        className: "text-blue hover:underline p-0 md:p-0",
        href: (0,explorer/* getExplorerLink */.E)(chainId, hash, "transaction"),
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex flex-row items-center gap-1",
          children: ["View on explorer ", /*#__PURE__*/jsx_runtime_.jsx(esm/* ExternalLinkIcon */.h0n, {
            width: 20,
            height: 20
          })]
        })
      })]
    })]
  });
}
// EXTERNAL MODULE: external "react-spring"
var external_react_spring_ = __webpack_require__(6821);
;// CONCATENATED MODULE: ./src/components/Popups/PopupItem.tsx



function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }







const Popup = external_styled_components_default().div.withConfig({
  displayName: "PopupItem__Popup",
  componentId: "sc-15jb6mv-0"
})(["display:inline-block;width:100%;padding:1em;position:relative;border-radius:10px;padding:20px;padding-right:35px;overflow:hidden;"]);
const AnimatedFader = (0,external_react_spring_.animated)((_ref) => {
  let {
    children
  } = _ref,
      rest = _objectWithoutProperties(_ref, ["children"]);

  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "h-[3px] bg-dark-800 w-full",
    children: /*#__PURE__*/jsx_runtime_.jsx("div", _objectSpread(_objectSpread({
      className: "h-[3px] bg-gradient-to-r from-blue to-pink "
    }, rest), {}, {
      children: children
    }))
  });
});
function PopupItem({
  removeAfterMs,
  content,
  popKey
}) {
  const removePopup = (0,hooks/* useRemovePopup */.J3)();
  const removeThisPopup = (0,external_react_.useCallback)(() => removePopup(popKey), [popKey, removePopup]);
  (0,external_react_.useEffect)(() => {
    if (removeAfterMs === null) return undefined;
    const timeout = setTimeout(() => {
      removeThisPopup();
    }, removeAfterMs);
    return () => {
      clearTimeout(timeout);
    };
  }, [removeAfterMs, removeThisPopup]);
  let popupContent;

  if ("txn" in content) {
    const {
      txn: {
        hash,
        success,
        summary
      }
    } = content;
    popupContent = /*#__PURE__*/jsx_runtime_.jsx(TransactionPopup, {
      hash: hash,
      success: success,
      summary: summary
    });
  }

  const faderStyle = (0,external_react_spring_.useSpring)({
    from: {
      width: "100%"
    },
    to: {
      width: "0%"
    },
    config: {
      duration: removeAfterMs !== null && removeAfterMs !== void 0 ? removeAfterMs : undefined
    }
  });
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "mb-4",
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "w-full relative rounded overflow-hidden bg-dark-700",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-row p-4",
        children: [popupContent, /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "hover:text-white cursor-pointer",
          children: /*#__PURE__*/jsx_runtime_.jsx(esm/* XIcon */.b0D, {
            width: 24,
            height: 24,
            onClick: removeThisPopup
          })
        })]
      }), removeAfterMs !== null ? /*#__PURE__*/jsx_runtime_.jsx(AnimatedFader, {
        style: faderStyle
      }) : null]
    })
  });
}
;// CONCATENATED MODULE: ./src/components/Popups/index.tsx







const Popups = () => {
  const activePopups = (0,hooks/* useActivePopups */.iT)();
  const urlWarningActive = (0,user_hooks/* useURLWarningVisible */.wm)();
  if (activePopups.length === 0) return /*#__PURE__*/jsx_runtime_.jsx("span", {});
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      className: `hidden md:block fixed right-[36px] max-w-[355px] w-full z-3 flex flex-col ${urlWarningActive ? 'top-[108px]' : 'top-[88px]'}`,
      children: activePopups.map(item => /*#__PURE__*/jsx_runtime_.jsx(PopupItem, {
        content: item.content,
        popKey: item.key,
        removeAfterMs: item.removeAfterMs
      }, item.key))
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "fixed md:hidden left-4 right-4 top-[88px] fit-content mb-[20px]",
      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "h-[99%] overflow-x-auto overflow-y-hidden flex flex-col gap-4",
        style: {
          WebkitOverflowScrolling: 'touch'
        },
        children: activePopups // reverse so new items up front
        .slice(0).reverse().map(item => /*#__PURE__*/jsx_runtime_.jsx(PopupItem, {
          content: item.content,
          popKey: item.key,
          removeAfterMs: item.removeAfterMs
        }, item.key))
      })
    })]
  });
};

/* harmony default export */ var components_Popups = (Popups);

/***/ }),

/***/ 1746:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "M": function() { return /* reexport */ CHAINLINK_MAPPING; }
});

// UNUSED EXPORTS: CHAINLINK_TOKENS

;// CONCATENATED MODULE: ./src/constants/chainlink/tokens/bsc.ts
const BSC_CHAINLINK_TOKENS = [{
  symbol: 'ADA',
  name: 'Cardano Token',
  address: '0x3EE2200Efb3400fAbB9AacF31297cBdD1d435D47',
  decimals: 18
}, {
  symbol: 'BUSD',
  name: 'BUSD Token',
  address: '0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56',
  decimals: 18
}, {
  symbol: 'BAND',
  name: 'Band Protocol Token',
  address: '0xAD6cAEb32CD2c308980a548bD0Bc5AA4306c6c18',
  decimals: 18
}, {
  symbol: 'BCH',
  name: 'Bitcoin Cash Token',
  address: '0x8fF795a6F4D97E7887C79beA79aba5cc76444aDf',
  decimals: 18
}, {
  symbol: 'BTCB',
  name: 'BTCB Token',
  address: '0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c',
  decimals: 18
}, {
  symbol: 'BUSD-T',
  name: 'BUSD-T',
  address: '0x55d398326f99059fF775485246999027B3197955',
  decimals: 18
}, {
  symbol: 'CREAM',
  name: 'Cream',
  address: '0xd4CB328A82bDf5f03eB737f37Fa6B370aef3e888',
  decimals: 18
}, {
  symbol: 'DAI',
  name: 'Dai Token',
  address: '0x1AF3F329e8BE154074D8769D1FFa4eE058B1DBc3',
  decimals: 18
}, {
  symbol: 'DOT',
  name: 'Polkadot Token',
  address: '0x7083609fCE4d1d8Dc0C979AAb8c869Ea2C873402',
  decimals: 18
}, {
  symbol: 'EOS',
  name: 'EOS Token',
  address: '0x56b6fB708fC5732DEC1Afc8D8556423A2EDcCbD6',
  decimals: 18
}, {
  symbol: 'LINK',
  name: 'ChainLink Token',
  address: '0xF8A0BF9cF54Bb92F17374d9e9A321E6a111a51bD',
  decimals: 18
}, {
  symbol: 'LTC',
  name: 'Litecoin Token',
  address: '0x4338665CBB7B2485A8855A139b75D5e34AB0DB94',
  decimals: 18
}, {
  symbol: 'SXP',
  name: 'Swipe',
  address: '0x47bead2563dcbf3bf2c9407fea4dc236faba485a',
  decimals: 18
}, {
  symbol: 'UNI',
  name: 'Uniswap',
  address: '0xBf5140A22578168FD562DCcF235E5D43A02ce9B1',
  decimals: 18
}, {
  symbol: 'USDC',
  name: 'USD Coin',
  address: '0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d',
  decimals: 18
}, {
  symbol: 'XRP',
  name: 'XRP Token',
  address: '0x1D2F0da169ceB9fC7B3144628dB156f3F6c60dBE',
  decimals: 18
}, {
  symbol: 'XTZ',
  name: 'Tezos Token',
  address: '0x16939ef78684453bfDFb47825F8a5F714f12623a',
  decimals: 18
}, {
  symbol: 'XVS',
  name: 'Venus',
  address: '0xcF6BB5389c92Bdda8a3747Ddb454cB7a64626C63',
  decimals: 18
}, {
  symbol: 'YFI',
  name: 'yearn.finance',
  address: '0x88f1A5ae2A3BF98AEAF342D26B30a79438c9142e',
  decimals: 18
}, {
  symbol: 'WBNB',
  name: 'Wrapped BNB',
  address: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c',
  decimals: 18
}, {
  symbol: 'WETH',
  name: 'Wrapped Ether',
  address: '0x2170Ed0880ac9A755fd29B2688956BD959F933F8',
  decimals: 18
}, {
  symbol: 'COIN',
  name: 'coin_artist',
  address: '0x87b008E57F640D94Ee44Fd893F0323AF933F9195',
  decimals: 18
}, {
  symbol: 'RAMP',
  name: 'RAMP DEFI',
  address: '0x8519EA49c997f50cefFa444d240fB655e89248Aa',
  decimals: 18
}, {
  symbol: 'VAI',
  name: 'VAI Stablecoin',
  address: '0x4BD17003473389A42DAF6a0a729f6Fdb328BbBd7',
  decimals: 18
}, {
  symbol: 'ONT',
  name: 'Binance-Peg Ontology Token',
  address: '0xFd7B3A77848f1C2D67E05E54d78d174a0C850335',
  decimals: 18
}, {
  symbol: 'FIL',
  name: 'Binance-Peg Filecoin',
  address: '0x0D8Ce2A99Bb6e3B7Db580eD848240e4a0F9aE153',
  decimals: 18
}, {
  symbol: 'DOGE',
  name: 'Binance-Peg Dogecoin',
  address: '0xba2ae424d960c26247dd6c32edc70b295c744c43',
  decimals: 8
}, {
  symbol: 'ICE',
  name: 'IceToken',
  address: '0xf16e81dce15B08F326220742020379B855B87DF9',
  decimals: 18
}, {
  symbol: 'EOS',
  name: 'Binance-Peg EOS Token',
  address: '0x56b6fB708fC5732DEC1Afc8D8556423A2EDcCbD6',
  decimals: 18
}, {
  symbol: 'XTZ',
  name: 'Binance-Peg Tezos Token',
  address: '0x16939ef78684453bfDFb47825F8a5F714f12623a',
  decimals: 18
}, {
  symbol: 'CAKE',
  name: 'PancakeSwap Token',
  address: '0x0E09FaBB73Bd3Ade0a17ECC321fD13a19e81cE82',
  decimals: 18
}];
/* harmony default export */ var bsc = (BSC_CHAINLINK_TOKENS);
// EXTERNAL MODULE: external "@sushiswap/sdk"
var sdk_ = __webpack_require__(6766);
;// CONCATENATED MODULE: ./src/constants/chainlink/tokens/heco.ts
const HECO_CHAINLINK_TOKENS = [{
  symbol: 'AAVE',
  name: 'AAVE Token',
  address: '0x202b4936fE1a82A4965220860aE46d7d3939Bb25',
  decimals: 18
}, {
  symbol: 'ETH',
  name: 'Ethereum',
  address: '0x64FF637fB478863B7468bc97D30a5bF3A428a1fD',
  decimals: 18
}, {
  symbol: 'HBCH',
  name: 'HBCH Token',
  address: '0xeF3CEBD77E0C52cb6f60875d9306397B5Caca375',
  decimals: 18
}, {
  symbol: 'HBTC',
  name: 'HBTC Token',
  address: '0x66a79D23E58475D2738179Ca52cd0b41d73f0BEa',
  decimals: 18
}, {
  symbol: 'HDOT',
  name: 'HDOT Token',
  address: '0xA2c49cEe16a5E5bDEFDe931107dc1fae9f7773E3',
  decimals: 18
}, {
  symbol: 'HT',
  name: 'Huobi Token',
  address: '0x5545153CCFcA01fbd7Dd11C0b23ba694D9509A6F',
  decimals: 18
}, {
  symbol: 'HUSD',
  name: 'HUSD Token',
  address: '0x0298c2b32eaE4da002a15f36fdf7615BEa3DA047',
  decimals: 18
}, {
  symbol: 'HLTC',
  name: 'HLTC Token',
  address: '0xecb56cf772B5c9A6907FB7d32387Da2fCbfB63b4',
  decimals: 18
}, {
  symbol: 'MDX',
  name: 'MDX Token',
  address: '0x25D2e80cB6B86881Fd7e07dd263Fb79f4AbE033c',
  decimals: 18
}, {
  symbol: 'SNX',
  name: 'SNX Token',
  address: '0x777850281719d5a96C29812ab72f822E0e09F3Da',
  decimals: 18
}, {
  symbol: 'UNI',
  name: 'UNI Token',
  address: '0x22C54cE8321A4015740eE1109D9cBc25815C46E6',
  decimals: 18
}, {
  symbol: 'USDTHECO',
  name: 'USDTHECO Token',
  address: '0xa71EdC38d189767582C38A3145b5873052c3e47a',
  decimals: 18
}];
/* harmony default export */ var heco = (HECO_CHAINLINK_TOKENS);
;// CONCATENATED MODULE: ./src/constants/chainlink/tokens/kovan.ts
const KOVAN_CHAINLINK_TOKENS = [{
  symbol: 'WETH',
  name: 'Wrapped Ether',
  address: '0xd0A1E359811322d97991E03f863a0C30C2cF029C',
  decimals: 18
}, {
  symbol: 'ZRX',
  name: '0x Protocol Token',
  address: '0x162c44e53097e7B5aaE939b297ffFD6Bf90D1EE3',
  decimals: 18
}, {
  symbol: 'USDC',
  name: 'USD Coin USDC',
  address: '0xb7a4F3E9097C08dA09517b5aB877F7a917224ede',
  decimals: 6
}, {
  symbol: 'DAI',
  name: 'Dai Stablecoin',
  address: '0x4F96Fe3b7A6Cf9725f59d353F723c1bDb64CA6Aa',
  decimals: 18
}, {
  symbol: 'USDT',
  name: 'Tether USD',
  address: '0x07de306FF27a2B630B1141956844eB1552B956B5',
  decimals: 6
}, {
  symbol: 'COMP',
  name: 'Compound',
  address: '0x61460874a7196d6a22D1eE4922473664b3E95270',
  decimals: 18
}, {
  symbol: 'BAT',
  name: 'Basic Attention Token',
  address: '0x482dC9bB08111CB875109B075A40881E48aE02Cd',
  decimals: 18
}, {
  symbol: 'WBTC',
  name: 'Wrapped BTC',
  address: '0xd3A691C852CDB01E281545A27064741F0B7f6825',
  decimals: 8
}, {
  symbol: 'REP',
  name: 'Reputation',
  address: '0x50DD65531676F718B018De3dc48F92B53D756996',
  decimals: 18
}];
/* harmony default export */ var kovan = (KOVAN_CHAINLINK_TOKENS);
;// CONCATENATED MODULE: ./src/constants/chainlink/tokens/mainnet.ts
const MAINNET_CHAINLINK_TOKENS = [{
  symbol: '1INCH',
  name: '1INCH Token',
  address: '0x111111111117dC0aa78b770fA6A738034120C302',
  decimals: 18
}, {
  symbol: 'AAVE',
  name: 'Aave Token',
  address: '0x7Fc66500c84A76Ad7e9c93437bFc5Ac33E2DDaE9',
  decimals: 18
}, {
  symbol: 'ADX',
  name: 'AdEx Network',
  address: '0xADE00C28244d5CE17D72E40330B1c318cD12B7c3',
  decimals: 18
}, {
  symbol: 'AKRO',
  name: 'Akropolis',
  address: '0x8Ab7404063Ec4DBcfd4598215992DC3F8EC853d7',
  decimals: 18
}, {
  symbol: 'ALPHA',
  name: 'AlphaToken',
  address: '0xa1faa113cbE53436Df28FF0aEe54275c13B40975',
  decimals: 18
}, {
  symbol: 'AMP',
  name: 'Amp',
  address: '0xfF20817765cB7f73d4bde2e66e067E58D11095C2',
  decimals: 18
}, {
  symbol: 'ANKR',
  name: 'Ankr Network',
  address: '0x8290333ceF9e6D528dD5618Fb97a76f268f3EDD4',
  decimals: 18
}, {
  symbol: 'ANT',
  name: 'Aragon Network Token',
  address: '0xa117000000f279D81A1D3cc75430fAA017FA5A2e',
  decimals: 18
}, {
  symbol: 'AUCTION',
  name: 'Bounce Token',
  address: '0xA9B1Eb5908CfC3cdf91F9B8B3a74108598009096',
  decimals: 18
}, {
  symbol: 'BADGER',
  name: 'Badger',
  address: '0x3472A5A71965499acd81997a54BBA8D852C6E53d',
  decimals: 18
}, {
  symbol: 'BAL',
  name: 'Balancer',
  address: '0xba100000625a3754423978a60c9317c58a424e3D',
  decimals: 18
}, {
  symbol: 'BAND',
  name: 'BandToken',
  address: '0xBA11D00c5f74255f56a5E366F4F77f5A186d7f55',
  decimals: 18
}, {
  symbol: 'BAT',
  name: 'Basic Attention Token',
  address: '0x0D8775F648430679A709E98d2b0Cb6250d2887EF',
  decimals: 18
}, {
  symbol: 'BNT',
  name: 'Bancor',
  address: '0x1F573D6Fb3F13d689FF844B4cE37794d79a7FF1C',
  decimals: 18
}, {
  symbol: 'BOR',
  name: 'BoringDAO',
  address: '0x3c9d6c1C73b31c837832c72E04D3152f051fc1A9',
  decimals: 18
}, {
  symbol: 'BUSD',
  name: 'Binance USD',
  address: '0x4Fabb145d64652a948d72533023f6E7A623C7C53',
  decimals: 18
}, {
  symbol: 'BZRX',
  name: 'bZx Protocol Token',
  address: '0x56d811088235F11C8920698a204A5010a788f4b3',
  decimals: 18
}, {
  symbol: 'CEL',
  name: 'Celsius',
  address: '0xaaAEBE6Fe48E54f431b0C390CfaF0b017d09D42d',
  decimals: 4
}, {
  symbol: 'COMP',
  name: 'Compound',
  address: '0xc00e94Cb662C3520282E6f5717214004A7f26888',
  decimals: 18
}, {
  symbol: 'COVER',
  name: 'Cover Protocol Governance Token',
  address: '0x4688a8b1F292FDaB17E9a90c8Bc379dC1DBd8713',
  decimals: 18
}, {
  symbol: 'CREAM',
  name: 'Cream',
  address: '0x2ba592F78dB6436527729929AAf6c908497cB200',
  decimals: 18
}, {
  symbol: 'CRO',
  name: 'CRO',
  address: '0xA0b73E1Ff0B80914AB6fe0444E65848C4C34450b',
  decimals: 8
}, {
  symbol: 'CRV',
  name: 'Curve DAO Token',
  address: '0xD533a949740bb3306d119CC777fa900bA034cd52',
  decimals: 18
}, {
  symbol: 'DAI',
  name: 'Dai Stablecoin',
  address: '0x6B175474E89094C44Da98b954EedeAC495271d0F',
  decimals: 18
}, {
  symbol: 'DPI',
  name: 'DefiPulse Index',
  address: '0x1494CA1F11D487c2bBe4543E90080AeBa4BA3C2b',
  decimals: 18
}, {
  symbol: 'ENJ',
  name: 'Enjin Coin',
  address: '0xF629cBd94d3791C9250152BD8dfBDF380E2a3B9c',
  decimals: 18
}, {
  symbol: 'ETH',
  name: 'Ethereum',
  address: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
  decimals: 18
}, {
  symbol: 'FEI',
  name: 'Fei Money',
  address: '0x956F47F50A910163D8BF957Cf5846D573E7f87CA',
  decimals: 18
}, {
  symbol: 'FRONT',
  name: 'Frontier Token',
  address: '0xf8C3527CC04340b208C854E985240c02F7B7793f',
  decimals: 18
}, {
  symbol: 'FRX',
  name: 'Frax Share',
  address: '0x3432B6A60D23Ca0dFCa7761B7ab56459D9C964D0',
  decimals: 18
}, {
  symbol: 'FTM',
  name: 'Fantom Token',
  address: '0x4E15361FD6b4BB609Fa63C81A2be19d873717870',
  decimals: 18
}, {
  symbol: 'FTX Token',
  name: 'FTT',
  address: '0x50D1c9771902476076eCFc8B2A83Ad6b9355a4c9',
  decimals: 18
}, {
  symbol: 'GRT',
  name: 'Graph Token',
  address: '0xc944E90C64B2c07662A292be6244BDf05Cda44a7',
  decimals: 18
}, {
  symbol: 'HEGIC',
  name: 'Hegic',
  address: '0x584bC13c7D411c00c01A62e8019472dE68768430',
  decimals: 18
}, {
  symbol: 'HUSD',
  name: 'HUSD',
  address: '0xdF574c24545E5FfEcb9a659c229253D4111d87e1',
  decimals: 8
}, {
  symbol: 'INJ',
  name: 'Injective Token',
  address: '0xe28b3B32B6c345A34Ff64674606124Dd5Aceca30',
  decimals: 18
}, {
  symbol: 'KNC',
  name: 'Kyber Network Crystal',
  address: '0xdd974D5C2e2928deA5F71b9825b8b646686BD200',
  decimals: 18
}, {
  symbol: 'KP3R',
  name: 'Keep3rV1',
  address: '0x1cEB5cB57C4D4E2b2433641b95Dd330A33185A44',
  decimals: 18
}, {
  symbol: 'LINK',
  name: 'ChainLink Token',
  address: '0x514910771AF9Ca656af840dff83E8264EcF986CA',
  decimals: 18
}, {
  symbol: 'LRC',
  name: 'LoopringCoin V2',
  address: '0xBBbbCA6A901c926F240b89EacB641d8Aec7AEafD',
  decimals: 18
}, {
  symbol: 'MANA',
  name: 'Decentraland MANA',
  address: '0x0F5D2fB29fb7d3CFeE444a200298f468908cC942',
  decimals: 18
}, {
  symbol: 'MATIC',
  name: 'Matic Token',
  address: '0x7D1AfA7B718fb893dB30A3aBc0Cfc608AaCfeBB0',
  decimals: 18
}, {
  symbol: 'MKR',
  name: 'Maker',
  address: '0x9f8F72aA9304c8B593d555F12eF6589cC3A579A2',
  decimals: 18
}, {
  symbol: 'MLN',
  name: 'Melon Token',
  address: '0xec67005c4E498Ec7f55E092bd1d35cbC47C91892',
  decimals: 18
}, {
  symbol: 'MTA',
  name: 'Meta',
  address: '0xa3BeD4E1c75D00fa6f4E5E6922DB7261B5E9AcD2',
  decimals: 18
}, {
  symbol: 'NMR',
  name: 'Numeraire',
  address: '0x1776e1F26f98b1A5dF9cD347953a26dd3Cb46671',
  decimals: 18
}, {
  symbol: 'OCEAN',
  name: 'Ocean Token',
  address: '0x967da4048cD07aB37855c090aAF366e4ce1b9F48',
  decimals: 18
}, {
  symbol: 'OGN',
  name: 'OriginToken',
  address: '0x8207c1FfC5B6804F6024322CcF34F29c3541Ae26',
  decimals: 18
}, {
  symbol: 'OKB',
  name: 'OKB',
  address: '0x75231F58b43240C9718Dd58B4967c5114342a86c',
  decimals: 18
}, {
  symbol: 'OMG',
  name: 'OMGToken',
  address: '0xd26114cd6EE289AccF82350c8d8487fedB8A0C07',
  decimals: 18
}, {
  symbol: 'ORN',
  name: 'Orion Protocol',
  address: '0x0258F474786DdFd37ABCE6df6BBb1Dd5dfC4434a',
  decimals: 8
}, {
  symbol: 'OXT',
  name: 'Orchid',
  address: '0x4575f41308EC1483f3d399aa9a2826d74Da13Deb',
  decimals: 18
}, {
  symbol: 'PAX',
  name: 'Paxos Standard',
  address: '0x8E870D67F660D95d5be530380D0eC0bd388289E1',
  decimals: 18
}, {
  symbol: 'PAXG',
  name: 'Paxos Gold',
  address: '0x45804880De22913dAFE09f4980848ECE6EcbAf78',
  decimals: 18
}, {
  symbol: 'PERP',
  name: 'Perpetual',
  address: '0xbC396689893D065F41bc2C6EcbeE5e0085233447',
  decimals: 18
}, {
  symbol: 'RAI',
  name: 'Rai Reflex Index',
  address: '0x03ab458634910AaD20eF5f1C8ee96F1D6ac54919',
  decimals: 18
}, {
  symbol: 'RARI',
  name: 'Rarible',
  address: '0xFca59Cd816aB1eaD66534D82bc21E7515cE441CF',
  decimals: 18
}, {
  symbol: 'RCN',
  name: 'Ripio Credit Network Token',
  address: '0xF970b8E36e23F7fC3FD752EeA86f8Be8D83375A6',
  decimals: 18
}, {
  symbol: 'REN',
  name: 'Republic Token',
  address: '0x408e41876cCCDC0F92210600ef50372656052a38',
  decimals: 18
}, {
  symbol: 'REPv2',
  name: 'Reputation',
  address: '0x221657776846890989a759BA2973e427DfF5C9bB',
  decimals: 18
}, {
  symbol: 'RGT',
  name: 'Rari Governance Token',
  address: '0xD291E7a03283640FDc51b121aC401383A46cC623',
  decimals: 18
}, {
  symbol: 'RLC',
  name: 'iEx.ec Network Token',
  address: '0x607F4C5BB672230e8672085532f7e901544a7375',
  decimals: 9
}, {
  symbol: 'RUNE',
  name: 'THORChain ETH.RUNE',
  address: '0x3155BA85D5F96b2d030a4966AF206230e46849cb',
  decimals: 18
}, {
  symbol: 'SAND',
  name: 'SAND',
  address: '0x3845badAde8e6dFF049820680d1F14bD3903a5d0',
  decimals: 18
}, {
  symbol: 'SNX',
  name: 'Synthetix Network Token',
  address: '0xC011a73ee8576Fb46F5E1c5751cA3B9Fe0af2a6F',
  decimals: 18
}, {
  symbol: 'SRM',
  name: 'Serum',
  address: '0x476c5E26a75bd202a9683ffD34359C0CC15be0fF',
  decimals: 6
}, {
  symbol: 'sUSD',
  name: 'Synth sUSD',
  address: '0x57Ab1ec28D129707052df4dF418D58a2D46d5f51',
  decimals: 18
}, {
  symbol: 'SUSHI',
  name: 'SushiToken',
  address: '0x6B3595068778DD592e39A122f4f5a5cF09C90fE2',
  decimals: 18
}, {
  symbol: 'SXP',
  name: 'Swipe',
  address: '0x8CE9137d39326AD0cD6491fb5CC0CbA0e089b6A9',
  decimals: 18
}, {
  symbol: 'TOMOE',
  name: 'TomoChain',
  address: '0x05D3606d5c81EB9b7B18530995eC9B29da05FaBa',
  decimals: 18
}, {
  symbol: 'TRU',
  name: 'TrueFi',
  address: '0x4C19596f5aAfF459fA38B0f7eD92F11AE6543784',
  decimals: 8
}, {
  symbol: 'TRY',
  name: 'TRYfinance',
  address: '0xc12eCeE46ed65D970EE5C899FCC7AE133AfF9b03',
  decimals: 18
}, {
  symbol: 'TUSD',
  name: 'TrueUSD',
  address: '0x0000000000085d4780B73119b644AE5ecd22b376',
  decimals: 18
}, {
  symbol: 'UMA',
  name: 'UMA Voting Token v1',
  address: '0x04Fa0d235C4abf4BcF4787aF4CF447DE572eF828',
  decimals: 18
}, {
  symbol: 'UNI',
  name: 'Uniswap',
  address: '0x1f9840a85d5aF5bf1D1762F925BDADdC4201F984',
  decimals: 18
}, {
  symbol: 'USDC',
  name: 'USD Coin',
  address: '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48',
  decimals: 6
}, {
  symbol: 'USDK',
  name: 'USDK',
  address: '0x1c48f86ae57291F7686349F12601910BD8D470bb',
  decimals: 18
}, {
  symbol: 'USDT',
  name: 'Tether USD',
  address: '0xdAC17F958D2ee523a2206206994597C13D831ec7',
  decimals: 6
}, {
  symbol: 'UST',
  name: 'Wrapped UST Token',
  address: '0xa47c8bf37f92aBed4A126BDA807A7b7498661acD',
  decimals: 18
}, {
  symbol: 'WAVES',
  name: 'WAVES',
  address: '0x1cF4592ebfFd730c7dc92c1bdFFDfc3B9EfCf29a',
  decimals: 18
}, {
  symbol: 'WBTC',
  name: 'Wrapped BTC',
  address: '0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599',
  decimals: 8
}, {
  symbol: 'wNXM',
  name: 'Wrapped NXM',
  address: '0x0d438F3b5175Bebc262bF23753C1E53d03432bDE',
  decimals: 18
}, {
  symbol: 'WOM',
  name: 'WOM Token',
  address: '0xBd356a39BFf2cAda8E9248532DD879147221Cf76',
  decimals: 18
}, {
  symbol: 'xSUSHI',
  name: 'SushiBar',
  address: '0x8798249c2E607446EfB7Ad49eC89dD1865Ff4272',
  decimals: 18
}, {
  symbol: 'YFI',
  name: 'yearn.finance',
  address: '0x0bc529c00C6401aEF6D220BE8C6Ea1667F6Ad93e',
  decimals: 18
}, {
  symbol: 'YFII',
  name: 'YFII.finance',
  address: '0xa1d0E215a23d7030842FC67cE582a6aFa3CCaB83',
  decimals: 18
}, {
  symbol: 'ZRX',
  name: '0x Protocol Token',
  address: '0xE41d2489571d322189246DaFA5ebDe1F4699F498',
  decimals: 18
}, {
  symbol: 'HT',
  name: 'Huobi Token',
  address: '0x6f259637dcD74C767781E37Bc6133cd6A68aa161',
  decimals: 18
}, {
  symbol: 'RAMP',
  name: 'RAMP DEFI',
  address: '0x33D0568941C0C64ff7e0FB4fbA0B11BD37deEd9f',
  decimals: 18
}, {
  symbol: 'LON',
  name: 'Tokenlon Network Token',
  address: '0x0000000000095413afc295d19edeb1ad7b71c952',
  decimals: 18
}, {
  symbol: 'DNT',
  name: 'district0x',
  address: '0x0AbdAce70D3790235af448C88547603b945604ea',
  decimals: 18
}, {
  symbol: 'renZEC',
  name: 'renZEC',
  address: '0x1C5db575E2Ff833E46a2E9864C22F4B22E0B37C2',
  decimals: 18
}];
/* harmony default export */ var mainnet = (MAINNET_CHAINLINK_TOKENS);
;// CONCATENATED MODULE: ./src/constants/chainlink/tokens/matic.ts
const MATIC_CHAINLINK_TOKENS = [{
  symbol: 'AAVE',
  name: 'AAVE Token',
  address: '0xD6DF932A45C0f255f85145f286eA0b292B21C90B',
  decimals: 18
}, {
  symbol: 'DAI',
  name: 'Dai Stablecoin',
  address: '0x8f3Cf7ad23Cd3CaDbD9735AFf958023239c6A063',
  decimals: 18
}, {
  symbol: 'WETH',
  name: 'Wrapped Ethereum',
  address: '0x7ceB23fD6bC0adD59E62ac25578270cFf1b9f619',
  decimals: 18
}, {
  symbol: 'WMATIC',
  name: 'Wrapped Matic',
  address: '0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270',
  decimals: 18
}, {
  symbol: 'USDC',
  name: 'USD Coin',
  address: '0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174',
  decimals: 6
}, {
  symbol: 'USDT',
  name: 'Tether USD',
  address: '0xc2132D05D31c914a87C6611C10748AEb04B58e8F',
  decimals: 6
}, {
  symbol: 'WBTC',
  name: 'Wrapped Bitcoin',
  address: '0x1BFD67037B42Cf73acF2047067bd4F2C47D9BfD6',
  decimals: 8
}];
/* harmony default export */ var matic = (MATIC_CHAINLINK_TOKENS);
;// CONCATENATED MODULE: ./src/constants/chainlink/tokens/index.ts






const CHAINLINK_TOKENS = {
  [sdk_.ChainId.MAINNET]: mainnet,
  [sdk_.ChainId.KOVAN]: kovan,
  [sdk_.ChainId.BSC]: bsc,
  [sdk_.ChainId.HECO]: heco,
  [sdk_.ChainId.MATIC]: matic
};
;// CONCATENATED MODULE: ./src/constants/chainlink/mappings/bsc.ts
const BSC_CHAINLINK_MAPPING = {
  '0x2d5Fc41d1365fFe13d03d91E82e04Ca878D69f4B': {
    from: '0x3EE2200Efb3400fAbB9AacF31297cBdD1d435D47',
    to: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  '0xa767f745331D267c7751297D982b050c93985627': {
    from: '0x3EE2200Efb3400fAbB9AacF31297cBdD1d435D47',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  '0x3334bF7ec892Ca03D1378B51769b7782EAF318C4': {
    from: '0xAD6cAEb32CD2c308980a548bD0Bc5AA4306c6c18',
    to: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  '0x2a548935a323Bb7329a5E3F1667B979f16Bc890b': {
    from: '0x8fF795a6F4D97E7887C79beA79aba5cc76444aDf',
    to: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  '0x43d80f616DAf0b0B42a928EeD32147dC59027D41': {
    from: '0x8fF795a6F4D97E7887C79beA79aba5cc76444aDf',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  '0x0567F2323251f0Aab15c8dFb1967E4e8A7D42aeE': {
    from: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  '0x116EeB23384451C78ed366D4f67D5AD44eE771A0': {
    from: '0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c',
    to: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  '0x264990fbd0A4796A3E3d8E37C4d5F87a3aCa5Ebf': {
    from: '0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  '0x87Ea38c9F24264Ec1Fff41B04ec94a97Caf99941': {
    from: '0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56',
    to: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  '0xcBb98864Ef56E9042e7d2efef76141f15731B82f': {
    from: '0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  '0x6f55DFAf098a813d87BB4e6392275b502360Bb9D': {
    from: '0xd4CB328A82bDf5f03eB737f37Fa6B370aef3e888',
    to: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  '0x8EC213E7191488C7873cEC6daC8e97cdbAdb7B35': {
    from: '0x1AF3F329e8BE154074D8769D1FFa4eE058B1DBc3',
    to: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  '0x132d3C0B1D2cEa0BC552588063bdBb210FDeecfA': {
    from: '0x1AF3F329e8BE154074D8769D1FFa4eE058B1DBc3',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  '0xBA8683E9c3B1455bE6e18E7768e8cAD95Eb5eD49': {
    from: '0x7083609fCE4d1d8Dc0C979AAb8c869Ea2C873402',
    to: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  '0xC333eb0086309a16aa7c8308DfD32c8BBA0a2592': {
    from: '0x7083609fCE4d1d8Dc0C979AAb8c869Ea2C873402',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  '0xed93F3764334788f2f6628b30e505fe1fc5d1D7b': {
    from: '0x56b6fB708fC5732DEC1Afc8D8556423A2EDcCbD6',
    to: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  '0x63D407F32Aa72E63C7209ce1c2F5dA40b3AaE726': {
    from: '0x2170Ed0880ac9A755fd29B2688956BD959F933F8',
    to: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  '0x9ef1B8c0E4F7dc8bF5719Ea496883DC6401d5b2e': {
    from: '0x2170Ed0880ac9A755fd29B2688956BD959F933F8',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  '0xB38722F6A608646a538E882Ee9972D15c86Fc597': {
    from: '0xF8A0BF9cF54Bb92F17374d9e9A321E6a111a51bD',
    to: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  '0xca236E327F629f9Fc2c30A4E95775EbF0B89fac8': {
    from: '0xF8A0BF9cF54Bb92F17374d9e9A321E6a111a51bD',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  '0x4e5a43A79f53c0a8e83489648Ea7e429278f8b2D': {
    from: '0x4338665CBB7B2485A8855A139b75D5e34AB0DB94',
    to: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  '0x74E72F37A8c415c8f1a98Ed42E78Ff997435791D': {
    from: '0x4338665CBB7B2485A8855A139b75D5e34AB0DB94',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  '0xE188A9875af525d25334d75F3327863B2b8cd0F1': {
    from: '0x47BEAd2563dCBf3bF2c9407fEa4dC236fAbA485A',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  '0xb57f259E7C24e56a1dA00F66b55A5640d9f9E7e4': {
    from: '0xBf5140A22578168FD562DCcF235E5D43A02ce9B1',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  '0x45f86CA2A8BC9EBD757225B19a1A0D7051bE46Db': {
    from: '0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d',
    to: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  '0x51597f405303C4377E36123cBc172b13269EA163': {
    from: '0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  '0xD5c40f5144848Bd4EF08a9605d860e727b991513': {
    from: '0x55d398326f99059fF775485246999027B3197955',
    to: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  '0xB97Ad0E74fa7d920791E90258A6E2085088b4320': {
    from: '0x55d398326f99059fF775485246999027B3197955',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  '0x798A65D349B2B5E6645695912880b54dfFd79074': {
    from: '0x1D2F0da169ceB9fC7B3144628dB156f3F6c60dBE',
    to: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  '0x93A67D414896A280bF8FFB3b389fE3686E014fda': {
    from: '0x1D2F0da169ceB9fC7B3144628dB156f3F6c60dBE',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  '0x8264d6983B219be65C4D62f1c82B3A2999944cF2': {
    from: '0x16939ef78684453bfDFb47825F8a5F714f12623a',
    to: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  '0xBF63F430A79D4036A5900C19818aFf1fa710f206': {
    from: '0xcF6BB5389c92Bdda8a3747Ddb454cB7a64626C63',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  '0xF841761481DF19831cCC851A54D8350aE6022583': {
    from: '0x88f1A5ae2A3BF98AEAF342D26B30a79438c9142e',
    to: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // yfi-usd
  '0xD7eAa5Bf3013A96e3d515c055Dbd98DbdC8c620D': {
    from: '0x88f1A5ae2A3BF98AEAF342D26B30a79438c9142e',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // coin-usd
  '0x2d1AB79D059e21aE519d88F978cAF39d74E31AEB': {
    from: '0x87b008E57F640D94Ee44Fd893F0323AF933F9195',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // ramp-usd
  '0xD1225da5FC21d17CaE526ee4b6464787c6A71b4C': {
    from: '0x8519EA49c997f50cefFa444d240fB655e89248Aa',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // vai-usd
  '0x058316f8Bb13aCD442ee7A216C7b60CFB4Ea1B53': {
    from: '0x4BD17003473389A42DAF6a0a729f6Fdb328BbBd7',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // ont-usd
  '0x887f177CBED2cf555a64e7bF125E1825EB69dB82': {
    from: '0xFd7B3A77848f1C2D67E05E54d78d174a0C850335',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // fil-usd
  '0xE5dbFD9003bFf9dF5feB2f4F445Ca00fb121fb83': {
    from: '0x0D8Ce2A99Bb6e3B7Db580eD848240e4a0F9aE153',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // ice-usd
  // '': {
  //     from: '0xf16e81dce15B08F326220742020379B855B87DF9',
  //     to: '0x0000000000000000000000000000000000000001',
  //     decimals: 8,
  //     fromDecimals: 18,
  //     toDecimals: 8
  // }
  // doge-usd
  '0x3AB0A0d137D4F946fBB19eecc6e92E64660231C8': {
    from: '0xba2ae424d960c26247dd6c32edc70b295c744c43',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // eos-usd
  '0xd5508c8Ffdb8F15cE336e629fD4ca9AdB48f50F0': {
    from: '0x56b6fB708fC5732DEC1Afc8D8556423A2EDcCbD6',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // xtz-usd
  '0x9A18137ADCF7b05f033ad26968Ed5a9cf0Bf8E6b': {
    from: '0x16939ef78684453bfDFb47825F8a5F714f12623a',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // cake-usd
  '0xB6064eD41d4f67e353768aA239cA86f4F73665a1': {
    from: '0x0E09FaBB73Bd3Ade0a17ECC321fD13a19e81cE82',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  }
};
/* harmony default export */ var mappings_bsc = (BSC_CHAINLINK_MAPPING);
;// CONCATENATED MODULE: ./src/constants/chainlink/mappings/heco.ts
const HECO_CHAINLINK_MAPPING = {
  '0x8a054991B803F6a6958Ba9695Cc8D366C8a30a69': {
    from: '0x202b4936fE1a82A4965220860aE46d7d3939Bb25',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  '0x98b666722D9Def641D8D4836c7cA3c38317B6B98': {
    from: '0xeF3CEBD77E0C52cb6f60875d9306397B5Caca375',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  '0xD5c40f5144848Bd4EF08a9605d860e727b991513': {
    from: '0x66a79D23E58475D2738179Ca52cd0b41d73f0BEa',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  '0x0A7b23E981F16a429C8710C82f5fa5d01453A259': {
    from: '0xA2c49cEe16a5E5bDEFDe931107dc1fae9f7773E3',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  '0x5Fa530068e0F5046479c588775c157930EF0Dff0': {
    from: '0x64FF637fB478863B7468bc97D30a5bF3A428a1fD',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  '0x8EC213E7191488C7873cEC6daC8e97cdbAdb7B35': {
    from: '0x5545153CCFcA01fbd7Dd11C0b23ba694D9509A6F',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  '0x45f86CA2A8BC9EBD757225B19a1A0D7051bE46Db': {
    from: '0x0298c2b32eaE4da002a15f36fdf7615BEa3DA047',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  '0x87Ea38c9F24264Ec1Fff41B04ec94a97Caf99941': {
    from: '0xecb56cf772B5c9A6907FB7d32387Da2fCbfB63b4',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  '0xaC4600b8F42317eAF056Cceb06cFf987c294840B': {
    from: '0x25D2e80cB6B86881Fd7e07dd263Fb79f4AbE033c',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  '0x1797a410485FeD6B05d5b39A475ddB9C33898ee8': {
    from: '0x777850281719d5a96C29812ab72f822E0e09F3Da',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  '0x1E22E1eD4a96B4529D78cd4Bac55313809deF016': {
    from: '0x22C54cE8321A4015740eE1109D9cBc25815C46E6',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  '0xF0D3585D8dC9f1D1D1a7dd02b48C2630d9DD78eD': {
    from: '0xa71EdC38d189767582C38A3145b5873052c3e47a',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  }
};
/* harmony default export */ var mappings_heco = (HECO_CHAINLINK_MAPPING);
;// CONCATENATED MODULE: ./src/constants/chainlink/mappings/kovan.ts
const KOVAN_CHAINLINK_MAPPING = {
  '0xBc3f28Ccc21E9b5856E81E6372aFf57307E2E883': {
    from: '0x162c44e53097e7B5aaE939b297ffFD6Bf90D1EE3',
    to: '0xd0A1E359811322d97991E03f863a0C30C2cF029C',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  '0x24D6B177CF20166cd8F55CaaFe1c745B44F6c203': {
    from: '0x162c44e53097e7B5aaE939b297ffFD6Bf90D1EE3',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  '0x64EaC61A2DFda2c3Fa04eED49AA33D021AeC8838': {
    from: '0xb7a4F3E9097C08dA09517b5aB877F7a917224ede',
    to: '0xd0A1E359811322d97991E03f863a0C30C2cF029C',
    decimals: 18,
    fromDecimals: 6,
    toDecimals: 18
  },
  '0x9211c6b3BF41A10F78539810Cf5c64e1BB78Ec60': {
    from: '0xb7a4F3E9097C08dA09517b5aB877F7a917224ede',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 6,
    toDecimals: 8
  },
  '0x22B58f1EbEDfCA50feF632bD73368b2FdA96D541': {
    from: '0x4F96Fe3b7A6Cf9725f59d353F723c1bDb64CA6Aa',
    to: '0xd0A1E359811322d97991E03f863a0C30C2cF029C',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  '0x777A68032a88E5A84678A77Af2CD65A7b3c0775a': {
    from: '0x4F96Fe3b7A6Cf9725f59d353F723c1bDb64CA6Aa',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  '0x0bF499444525a23E7Bb61997539725cA2e928138': {
    from: '0x07de306FF27a2B630B1141956844eB1552B956B5',
    to: '0xd0A1E359811322d97991E03f863a0C30C2cF029C',
    decimals: 18,
    fromDecimals: 6,
    toDecimals: 18
  },
  '0x2ca5A90D34cA333661083F89D831f757A9A50148': {
    from: '0x07de306FF27a2B630B1141956844eB1552B956B5',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 6,
    toDecimals: 8
  },
  '0xECF93D14d25E02bA2C13698eeDca9aA98348EFb6': {
    from: '0x61460874a7196d6a22D1eE4922473664b3E95270',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  '0x0e4fcEC26c9f85c3D714370c98f43C4E02Fc35Ae': {
    from: '0x482dC9bB08111CB875109B075A40881E48aE02Cd',
    to: '0xd0A1E359811322d97991E03f863a0C30C2cF029C',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  '0xF7904a295A029a3aBDFFB6F12755974a958C7C25': {
    from: '0xd3A691C852CDB01E281545A27064741F0B7f6825',
    to: '0xd0A1E359811322d97991E03f863a0C30C2cF029C',
    decimals: 18,
    fromDecimals: 8,
    toDecimals: 18
  },
  '0x6135b13325bfC4B00278B4abC5e20bbce2D6580e': {
    from: '0xd3A691C852CDB01E281545A27064741F0B7f6825',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 8,
    toDecimals: 8
  },
  '0x3A7e6117F2979EFf81855de32819FBba48a63e9e': {
    from: '0x50DD65531676F718B018De3dc48F92B53D756996',
    to: '0xd0A1E359811322d97991E03f863a0C30C2cF029C',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  '0x8f4e77806EFEC092A279AC6A49e129e560B4210E': {
    from: '0x50DD65531676F718B018De3dc48F92B53D756996',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  }
};
/* harmony default export */ var mappings_kovan = (KOVAN_CHAINLINK_MAPPING);
;// CONCATENATED MODULE: ./src/constants/chainlink/mappings/mainnet.ts
const MAINNET_CHAINLINK_MAPPING = {
  // 1INCH / ETH
  '0x72AFAECF99C9d9C8215fF44C77B94B99C28741e8': {
    from: '0x111111111117dC0aa78b770fA6A738034120C302',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // 1INCH / USD
  '0xc929ad75B72593967DE83E7F7Cda0493458261D9': {
    from: '0x111111111117dC0aa78b770fA6A738034120C302',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // AAVE / ETH
  '0x6Df09E975c830ECae5bd4eD9d90f3A95a4f88012': {
    from: '0x7Fc66500c84A76Ad7e9c93437bFc5Ac33E2DDaE9',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // AAVE / USD
  '0x547a514d5e3769680Ce22B2361c10Ea13619e8a9': {
    from: '0x7Fc66500c84A76Ad7e9c93437bFc5Ac33E2DDaE9',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // ADX / USD
  '0x231e764B44b2C1b7Ca171fa8021A24ed520Cde10': {
    from: '0xADE00C28244d5CE17D72E40330B1c318cD12B7c3',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // AKRO / USD
  '0xB23D105dF4958B4b81757e12f2151B5b5183520B': {
    from: '0x8Ab7404063Ec4DBcfd4598215992DC3F8EC853d7',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // ALPHA / ETH
  '0x89c7926c7c15fD5BFDB1edcFf7E7fC8283B578F6': {
    from: '0xa1faa113cbE53436Df28FF0aEe54275c13B40975',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // AMP / USD
  '0x8797ABc4641dE76342b8acE9C63e3301DC35e3d8': {
    from: '0xfF20817765cB7f73d4bde2e66e067E58D11095C2',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // AMPL / ETH
  '0x492575FDD11a0fCf2C6C719867890a7648d526eB': {
    from: '0xD46bA6D942050d489DBd938a2C909A5d5039A161',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 9,
    toDecimals: 18
  },
  // AMPL / USD
  '0xe20CA8D7546932360e37E9D72c1a47334af57706': {
    from: '0xD46bA6D942050d489DBd938a2C909A5d5039A161',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 9,
    toDecimals: 8
  },
  // ANKR / USD
  '0x7eed379bf00005CfeD29feD4009669dE9Bcc21ce': {
    from: '0x8290333ceF9e6D528dD5618Fb97a76f268f3EDD4',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // ANT / ETH
  '0x8f83670260F8f7708143b836a2a6F11eF0aBac01': {
    from: '0xa117000000f279D81A1D3cc75430fAA017FA5A2e',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // AUCTION / USD
  '0xA6BCac72431A4178f07d016E1D912F56E6D989Ec': {
    from: '0xA9B1Eb5908CfC3cdf91F9B8B3a74108598009096',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // BADGER / ETH
  '0x58921Ac140522867bf50b9E009599Da0CA4A2379': {
    from: '0x3472A5A71965499acd81997a54BBA8D852C6E53d',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // BADGER / USD
  '0x66a47b7206130e6FF64854EF0E1EDfa237E65339': {
    from: '0x3472A5A71965499acd81997a54BBA8D852C6E53d',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // BAL / ETH
  '0xC1438AA3823A6Ba0C159CfA8D98dF5A994bA120b': {
    from: '0xba100000625a3754423978a60c9317c58a424e3D',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // BAND / ETH
  '0x0BDb051e10c9718d1C29efbad442E88D38958274': {
    from: '0xBA11D00c5f74255f56a5E366F4F77f5A186d7f55',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // BAND / USD
  '0x919C77ACc7373D000b329c1276C76586ed2Dd19F': {
    from: '0xBA11D00c5f74255f56a5E366F4F77f5A186d7f55',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // BAT / ETH
  '0x0d16d4528239e9ee52fa531af613AcdB23D88c94': {
    from: '0x0D8775F648430679A709E98d2b0Cb6250d2887EF',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // BAT / USD
  '0x9441D7556e7820B5ca42082cfa99487D56AcA958': {
    from: '0x0D8775F648430679A709E98d2b0Cb6250d2887EF',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // BCH / USD
  '0x9F0F69428F923D6c95B781F89E165C9b2df9789D': {
    from: '0x459086F2376525BdCebA5bDDA135e4E9d3FeF5bf',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 8,
    toDecimals: 8
  },
  // BNB / ETH
  '0xc546d2d06144F9DD42815b8bA46Ee7B8FcAFa4a2': {
    from: '0xB8c77482e45F1F44dE1745F52C74426C631bDD52',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // BNB / USD
  '0x14e613AC84a31f709eadbdF89C6CC390fDc9540A': {
    from: '0xB8c77482e45F1F44dE1745F52C74426C631bDD52',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // BNT / ETH
  '0xCf61d1841B178fe82C8895fe60c2EDDa08314416': {
    from: '0x1F573D6Fb3F13d689FF844B4cE37794d79a7FF1C',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // BNT / USD
  '0x1E6cF0D433de4FE882A437ABC654F58E1e78548c': {
    from: '0x1F573D6Fb3F13d689FF844B4cE37794d79a7FF1C',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // BOND / ETH
  '0xdd22A54e05410D8d1007c38b5c7A3eD74b855281': {
    from: '0x0391D2021f89DC339F60Fff84546EA23E337750f',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // BTC / ETH
  '0xdeb288F737066589598e9214E782fa5A8eD689e8': {
    from: '0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 8,
    toDecimals: 18
  },
  // BTC / USD
  '0xF4030086522a5bEEa4988F8cA5B36dbC97BeE88c': {
    from: '0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 8,
    toDecimals: 8
  },
  // BTM / USD
  '0x9fCCF42D21AB278e205e7Bb310D8979F8f4B5751': {
    from: '0xcB97e65F07DA24D46BcDD078EBebd7C6E6E3d750',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 8,
    toDecimals: 8
  },
  // bUSD / ETH
  '0x614715d2Af89E6EC99A233818275142cE88d1Cfd': {
    from: '0x4Fabb145d64652a948d72533023f6E7A623C7C53',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // bUSD / USD
  '0x833D8Eb16D306ed1FbB5D7A2E019e106B960965A': {
    from: '0x4Fabb145d64652a948d72533023f6E7A623C7C53',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // BZRX / ETH
  '0x8f7C7181Ed1a2BA41cfC3f5d064eF91b67daef66': {
    from: '0x56d811088235F11C8920698a204A5010a788f4b3',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // CEL / ETH
  '0x75FbD83b4bd51dEe765b2a01e8D3aa1B020F9d33': {
    from: '0xaaAEBE6Fe48E54f431b0C390CfaF0b017d09D42d',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 4,
    toDecimals: 18
  },
  // CELO / USD
  '0x10D35eFa5C26C3d994C511576641248405465AeF': {
    from: '0xE452E6Ea2dDeB012e20dB73bf5d3863A3Ac8d77a',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // COMP / ETH
  '0x1B39Ee86Ec5979ba5C322b826B3ECb8C79991699': {
    from: '0xc00e94Cb662C3520282E6f5717214004A7f26888',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // COMP / USD
  '0xdbd020CAeF83eFd542f4De03e3cF0C28A4428bd5': {
    from: '0xc00e94Cb662C3520282E6f5717214004A7f26888',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // COVER / ETH
  '0x7B6230EF79D5E97C11049ab362c0b685faCBA0C2': {
    from: '0x4688a8b1F292FDaB17E9a90c8Bc379dC1DBd8713',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // COVER / USD
  '0x0ad50393F11FfAc4dd0fe5F1056448ecb75226Cf': {
    from: '0x4688a8b1F292FDaB17E9a90c8Bc379dC1DBd8713',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // CREAM / ETH
  '0x82597CFE6af8baad7c0d441AA82cbC3b51759607': {
    from: '0x2ba592F78dB6436527729929AAf6c908497cB200',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // CRO / ETH
  '0xcA696a9Eb93b81ADFE6435759A29aB4cf2991A96': {
    from: '0xA0b73E1Ff0B80914AB6fe0444E65848C4C34450b',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 8,
    toDecimals: 18
  },
  // CRO / USD
  '0x00Cb80Cf097D9aA9A3779ad8EE7cF98437eaE050': {
    from: '0xA0b73E1Ff0B80914AB6fe0444E65848C4C34450b',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 8,
    toDecimals: 8
  },
  // CRV / ETH
  '0x8a12Be339B0cD1829b91Adc01977caa5E9ac121e': {
    from: '0xD533a949740bb3306d119CC777fa900bA034cd52',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // CRV / USD
  '0xCd627aA160A6fA45Eb793D19Ef54f5062F20f33f': {
    from: '0xD533a949740bb3306d119CC777fa900bA034cd52',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // DAI / ETH
  '0x773616E4d11A78F511299002da57A0a94577F1f4': {
    from: '0x6B175474E89094C44Da98b954EedeAC495271d0F',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // DAI / USD
  '0xAed0c38402a5d19df6E4c03F4E2DceD6e29c1ee9': {
    from: '0x6B175474E89094C44Da98b954EedeAC495271d0F',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // DIA / USD
  '0xeE636E1f7A0A846EEc2385E729CeA7D1b339D40D': {
    from: '0x84cA8bc7997272c7CfB4D0Cd3D55cd942B3c9419',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // DIGG / USD
  '0x418a6C98CD5B8275955f08F0b8C1c6838c8b1685': {
    from: '0x798D1bE841a82a273720CE31c822C61a67a601C3',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 9,
    toDecimals: 8
  },
  // DNT / ETH
  '0x1F9eB026e549a5f47A6aa834689053117239334A': {
    from: '0x0AbdAce70D3790235af448C88547603b945604ea',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // DOGE / USD
  '0x2465CefD3b488BE410b941b1d4b2767088e2A028': {
    from: '0x3832d2F059E55934220881F831bE501D180671A7',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 8,
    toDecimals: 8
  },
  // DPI / ETH
  '0x029849bbc0b1d93b85a8b6190e979fd38F5760E2': {
    from: '0x1494CA1F11D487c2bBe4543E90080AeBa4BA3C2b',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // DPI / USD
  '0xD2A593BF7594aCE1faD597adb697b5645d5edDB2': {
    from: '0x1494CA1F11D487c2bBe4543E90080AeBa4BA3C2b',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 8
  },
  // ENJ / ETH
  '0x24D9aB51950F3d62E9144fdC2f3135DAA6Ce8D1B': {
    from: '0xF629cBd94d3791C9250152BD8dfBDF380E2a3B9c',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // ETH / USD
  '0x5f4eC3Df9cbd43714FE2740f5E3616155c5b8419': {
    from: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // FEI / ETH
  '0x7F0D2c2838c6AC24443d13e23d99490017bDe370': {
    from: '0x956F47F50A910163D8BF957Cf5846D573E7f87CA',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // FIL / ETH
  '0x0606Be69451B1C9861Ac6b3626b99093b713E801': {
    from: '0x6e1A19F235bE7ED8E3369eF73b196C07257494DE',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // FIL / USD
  '0x1A31D42149e82Eb99777f903C08A2E41A00085d3': {
    from: '0x6e1A19F235bE7ED8E3369eF73b196C07257494DE',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // FRAX / ETH
  '0x14d04Fff8D21bd62987a5cE9ce543d2F1edF5D3E': {
    from: '0x853d955aCEf822Db058eb8505911ED77F175b99e',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // FRONT / USD
  '0xbf86e7B2565eAc3bFD80634176F31bd186566b06': {
    from: '0xf8C3527CC04340b208C854E985240c02F7B7793f',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // FTM / USD
  '0x2DE7E4a9488488e0058B95854CC2f7955B35dC9b': {
    from: '0x4E15361FD6b4BB609Fa63C81A2be19d873717870',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // FTT / ETH
  '0xF0985f7E2CaBFf22CecC5a71282a89582c382EFE': {
    from: '0x50D1c9771902476076eCFc8B2A83Ad6b9355a4c9',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // FXS / USD
  '0x6Ebc52C8C1089be9eB3945C4350B68B8E4C2233f': {
    from: '0x3432B6A60D23Ca0dFCa7761B7ab56459D9C964D0',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // GNO / ETH
  '0xA614953dF476577E90dcf4e3428960e221EA4727': {
    from: '0x6810e776880C02933D47DB1b9fc05908e5386b96',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // GRT / ETH
  '0x17D054eCac33D91F7340645341eFB5DE9009F1C1': {
    from: '0xc944E90C64B2c07662A292be6244BDf05Cda44a7',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // HEGIC / ETH
  '0xAf5E8D9Cd9fC85725A83BF23C52f1C39A71588a6': {
    from: '0x584bC13c7D411c00c01A62e8019472dE68768430',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // HEGIC / USD
  '0xBFC189aC214E6A4a35EBC281ad15669619b75534': {
    from: '0x584bC13c7D411c00c01A62e8019472dE68768430',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // HT / USD
  '0xE1329B3f6513912CAf589659777b66011AEE5880': {
    from: '0x6f259637dcD74C767781E37Bc6133cd6A68aa161',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // HUSD / ETH
  '0x1B61BAD1495161bCb6C03DDB0E41622c0270bB1A': {
    from: '0xdF574c24545E5FfEcb9a659c229253D4111d87e1',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 8,
    toDecimals: 18
  },
  // INJ / USD
  '0xaE2EbE3c4D20cE13cE47cbb49b6d7ee631Cd816e': {
    from: '0xe28b3B32B6c345A34Ff64674606124Dd5Aceca30',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // IOST / USD
  '0xd0935838935349401c73a06FCde9d63f719e84E5': {
    from: '0xFA1a856Cfa3409CFa145Fa4e20Eb270dF3EB21ab',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // JPY / USD
  '0xBcE206caE7f0ec07b545EddE332A47C2F75bbeb3': {
    from: '0x2370f9d504c7a6E775bf6E14B3F12846b594cD53',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // KNC / ETH
  '0x656c0544eF4C98A6a98491833A89204Abb045d6b': {
    from: '0xdd974D5C2e2928deA5F71b9825b8b646686BD200',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // KNC / USD
  '0xf8fF43E991A81e6eC886a3D281A2C6cC19aE70Fc': {
    from: '0xdd974D5C2e2928deA5F71b9825b8b646686BD200',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // KP3R / ETH
  '0xe7015CCb7E5F788B8c1010FC22343473EaaC3741': {
    from: '0x1cEB5cB57C4D4E2b2433641b95Dd330A33185A44',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // LDO / ETH
  '0x4e844125952D32AcdF339BE976c98E22F6F318dB': {
    from: '0x5A98FcBEA516Cf06857215779Fd812CA3beF1B32',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // LINK / ETH
  '0xDC530D9457755926550b59e8ECcdaE7624181557': {
    from: '0x514910771AF9Ca656af840dff83E8264EcF986CA',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // LINK / USD
  '0x2c1d072e956AFFC0D435Cb7AC38EF18d24d9127c': {
    from: '0x514910771AF9Ca656af840dff83E8264EcF986CA',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // LON / ETH
  '0x13A8F2cC27ccC2761ca1b21d2F3E762445f201CE': {
    from: '0x0000000000095413afC295d19EDeb1Ad7B71c952',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // LRC / ETH
  '0x160AC928A16C93eD4895C2De6f81ECcE9a7eB7b4': {
    from: '0xBBbbCA6A901c926F240b89EacB641d8Aec7AEafD',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // LRC / USD
  '0xFd33ec6ABAa1Bdc3D9C6C85f1D6299e5a1a5511F': {
    from: '0xBBbbCA6A901c926F240b89EacB641d8Aec7AEafD',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // MANA / ETH
  '0x82A44D92D6c329826dc557c5E1Be6ebeC5D5FeB9': {
    from: '0x0F5D2fB29fb7d3CFeE444a200298f468908cC942',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // MATIC / USD
  '0x7bAC85A8a13A4BcD8abb3eB7d6b4d632c5a57676': {
    from: '0x7D1AfA7B718fb893dB30A3aBc0Cfc608AaCfeBB0',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // MKR / ETH
  '0x24551a8Fb2A7211A25a17B1481f043A8a8adC7f2': {
    from: '0x9f8F72aA9304c8B593d555F12eF6589cC3A579A2',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // MATIC / USD
  '0xec1D1B3b0443256cc3860e24a46F108e699484Aa': {
    from: '0x9f8F72aA9304c8B593d555F12eF6589cC3A579A2',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // MLN / ETH
  '0xDaeA8386611A157B08829ED4997A8A62B557014C': {
    from: '0xec67005c4E498Ec7f55E092bd1d35cbC47C91892',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // MTA / ETH
  '0x98334b85De2A8b998Ba844c5521e73D68AD69C00': {
    from: '0xa3BeD4E1c75D00fa6f4E5E6922DB7261B5E9AcD2',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // MTA / USD
  '0xc751E86208F0F8aF2d5CD0e29716cA7AD98B5eF5': {
    from: '0xa3BeD4E1c75D00fa6f4E5E6922DB7261B5E9AcD2',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // NMR / ETH
  '0x9cB2A01A7E64992d32A34db7cEea4c919C391f6A': {
    from: '0x1776e1F26f98b1A5dF9cD347953a26dd3Cb46671',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // NMR / USD
  '0xcC445B35b3636bC7cC7051f4769D8982ED0d449A': {
    from: '0x1776e1F26f98b1A5dF9cD347953a26dd3Cb46671',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // NU / ETH
  '0xFd93C391f3a81565DaE1f6A66115C26f36A92d6D': {
    from: '0x4fE83213D56308330EC302a8BD641f1d0113A4Cc',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // OCEAN / ETH
  '0x9b0FC4bb9981e5333689d69BdBF66351B9861E62': {
    from: '0x967da4048cD07aB37855c090aAF366e4ce1b9F48',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // OCEAN / USD
  '0x7ece4e4E206eD913D991a074A19C192142726797': {
    from: '0x967da4048cD07aB37855c090aAF366e4ce1b9F48',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // OGN / ETH
  '0x2c881B6f3f6B5ff6C975813F87A4dad0b241C15b': {
    from: '0x8207c1FfC5B6804F6024322CcF34F29c3541Ae26',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // OKB / USD
  '0x22134617Ae0f6CA8D89451e5Ae091c94f7D743DC': {
    from: '0x75231F58b43240C9718Dd58B4967c5114342a86c',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // OMG / ETH
  '0x57C9aB3e56EE4a83752c181f241120a3DBba06a1': {
    from: '0xd26114cd6EE289AccF82350c8d8487fedB8A0C07',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // OMG / USD
  '0x7D476f061F8212A8C9317D5784e72B4212436E93': {
    from: '0xd26114cd6EE289AccF82350c8d8487fedB8A0C07',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // ORN / ETH
  '0xbA9B2a360eb8aBdb677d6d7f27E12De11AA052ef': {
    from: '0x0258F474786DdFd37ABCE6df6BBb1Dd5dfC4434a',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 8,
    toDecimals: 18
  },
  // OXT / USD
  '0xd75AAaE4AF0c398ca13e2667Be57AF2ccA8B5de6': {
    from: '0x4575f41308EC1483f3d399aa9a2826d74Da13Deb',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // PAX / ETH
  '0x3a08ebBaB125224b7b6474384Ee39fBb247D2200': {
    from: '0x8E870D67F660D95d5be530380D0eC0bd388289E1',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // PAXG / ETH
  '0x9B97304EA12EFed0FAd976FBeCAad46016bf269e': {
    from: '0x45804880De22913dAFE09f4980848ECE6EcbAf78',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // PERP / ETH
  '0x3b41D5571468904D4e53b6a8d93A6BaC43f02dC9': {
    from: '0xbC396689893D065F41bc2C6EcbeE5e0085233447',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // PUNDIX / USD
  '0x552dDBEf6f5a1316aec3E30Db6afCD433548dbF3': {
    from: '0x0FD10b9899882a6f2fcb5c371E17e70FdEe00C38',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // QQQ / USD
  '0x6b54e83f44047d2168a195ABA5e9b768762167b5': {
    from: '0x13B02c8dE71680e71F0820c996E4bE43c2F57d15',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // RAI / ETH
  '0x4ad7B025127e89263242aB68F0f9c4E5C033B489': {
    from: '0x03ab458634910AaD20eF5f1C8ee96F1D6ac54919',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // RAMP / USD
  '0x4EA6Ec4C1691C62623122B213572b2be5A618C0d': {
    from: '0x33D0568941C0C64ff7e0FB4fbA0B11BD37deEd9f',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // RARI / ETH
  '0x2a784368b1D492f458Bf919389F42c18315765F5': {
    from: '0xFca59Cd816aB1eaD66534D82bc21E7515cE441CF',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // RCN / BTC
  '0xEa0b3DCa635f4a4E77D9654C5c18836EE771566e': {
    from: '0xF970b8E36e23F7fC3FD752EeA86f8Be8D83375A6',
    to: '0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // REN / ETH
  '0x3147D7203354Dc06D9fd350c7a2437bcA92387a4': {
    from: '0x408e41876cCCDC0F92210600ef50372656052a38',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // REN / USD
  '0x0f59666EDE214281e956cb3b2D0d69415AfF4A01': {
    from: '0x408e41876cCCDC0F92210600ef50372656052a38',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // REP / ETH
  '0xD4CE430C3b67b3E2F7026D86E7128588629e2455': {
    from: '0x221657776846890989a759BA2973e427DfF5C9bB',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // REP / USD
  '0xF9FCC6E1186Acf6529B1c1949453f51B4B6eEE67': {
    from: '0x221657776846890989a759BA2973e427DfF5C9bB',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // RGT / ETH
  '0xc16935B445F4BDC172e408433c8f7101bbBbE368': {
    from: '0xD291E7a03283640FDc51b121aC401383A46cC623',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // RLC / ETH
  '0x4cba1e1fdc738D0fe8DB3ee07728E2Bc4DA676c6': {
    from: '0x607F4C5BB672230e8672085532f7e901544a7375',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 9,
    toDecimals: 18
  },
  // RUNE / ETH
  '0x875D60C44cfbC38BaA4Eb2dDB76A767dEB91b97e': {
    from: '0x3155BA85D5F96b2d030a4966AF206230e46849cb',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // RUNE / USD
  '0x48731cF7e84dc94C5f84577882c14Be11a5B7456': {
    from: '0x3155BA85D5F96b2d030a4966AF206230e46849cb',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // SAND / USD
  '0x35E3f7E558C04cE7eEE1629258EcbbA03B36Ec56': {
    from: '0x3845badAde8e6dFF049820680d1F14bD3903a5d0',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // SFI / ETH
  '0xeA286b2584F79Cd4D322Fe107d9683971c890596': {
    from: '0xb753428af26E81097e7fD17f40c88aaA3E04902c',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // SNX / ETH
  '0x79291A9d692Df95334B1a0B3B4AE6bC606782f8c': {
    from: '0xC011a73ee8576Fb46F5E1c5751cA3B9Fe0af2a6F',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // SNX / USD
  '0xDC3EA94CD0AC27d9A86C180091e7f78C683d3699': {
    from: '0x476c5E26a75bd202a9683ffD34359C0CC15be0fF',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // SRM / ETH
  '0x050c048c9a0CD0e76f166E2539F87ef2acCEC58f': {
    from: '0x476c5E26a75bd202a9683ffD34359C0CC15be0fF',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 6,
    toDecimals: 18
  },
  // STAKE / ETH
  '0xa1FFC11Eaa62d34C3B3272270AEcF9D879773B32': {
    from: '0x0Ae055097C6d159879521C384F1D2123D1f195e6',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // STMX / USD
  '0x00a773bD2cE922F866BB43ab876009fb959d7C29': {
    from: '0xbE9375C6a420D2eEB258962efB95551A5b722803',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // SUSD / ETH
  '0x8e0b7e6062272B5eF4524250bFFF8e5Bd3497757': {
    from: '0x57Ab1ec28D129707052df4dF418D58a2D46d5f51',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // SUSHI / ETH
  '0xe572CeF69f43c2E488b33924AF04BDacE19079cf': {
    from: '0x6B3595068778DD592e39A122f4f5a5cF09C90fE2',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // SWAP / ETH
  '0xffa4Bb3a24B60C0262DBAaD60d77a3c3fa6173e8': {
    from: '0xCC4304A31d09258b0029eA7FE63d032f52e44EFe',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // SXP / USD
  '0xFb0CfD6c19e25DB4a08D8a204a387cEa48Cc138f': {
    from: '0x8CE9137d39326AD0cD6491fb5CC0CbA0e089b6A9',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // TOMO / USD
  '0x3d44925a8E9F9DFd90390E58e92Ec16c996A331b': {
    from: '0x05D3606d5c81EB9b7B18530995eC9B29da05FaBa',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // TRIBE / ETH
  '0x84a24deCA415Acc0c395872a9e6a63E27D6225c8': {
    from: '0xc7283b66Eb1EB5FB86327f08e1B5816b0720212B',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // TRU / USD
  '0x26929b85fE284EeAB939831002e1928183a10fb1': {
    from: '0x4C19596f5aAfF459fA38B0f7eD92F11AE6543784',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 8,
    toDecimals: 8
  },
  // TRX / USD
  '0xacD0D1A29759CC01E8D925371B72cb2b5610EA25': {
    from: '0xE1Be5D3f34e89dE342Ee97E6e90D405884dA6c67',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 6,
    toDecimals: 8
  },
  // TRY / USD
  '0xB09fC5fD3f11Cf9eb5E1C5Dba43114e3C9f477b5': {
    from: '0xc12eCeE46ed65D970EE5C899FCC7AE133AfF9b03',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // TUSD / ETH
  '0x3886BA987236181D98F2401c507Fb8BeA7871dF2': {
    from: '0x0000000000085d4780B73119b644AE5ecd22b376',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // UMA / ETH
  '0xf817B69EA583CAFF291E287CaE00Ea329d22765C': {
    from: '0x04Fa0d235C4abf4BcF4787aF4CF447DE572eF828',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // UNI / ETH
  '0xD6aA3D25116d8dA79Ea0246c4826EB951872e02e': {
    from: '0x1f9840a85d5aF5bf1D1762F925BDADdC4201F984',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // UNI / USD
  '0x553303d460EE0afB37EdFf9bE42922D8FF63220e': {
    from: '0x1f9840a85d5aF5bf1D1762F925BDADdC4201F984',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // USDC / ETH
  '0x986b5E1e1755e3C2440e960477f25201B0a8bbD4': {
    from: '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 6,
    toDecimals: 18
  },
  // USDC / USD
  '0x8fFfFfd4AfB6115b954Bd326cbe7B4BA576818f6': {
    from: '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 6,
    toDecimals: 8
  },
  // USDCK / USD
  '0xfAC81Ea9Dd29D8E9b212acd6edBEb6dE38Cb43Af': {
    from: '0x1c48f86ae57291F7686349F12601910BD8D470bb',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // USDN / USD
  '0x7a8544894F7FD0C69cFcBE2b4b2E277B0b9a4355': {
    from: '0x674C6Ad92Fd080e4004b2312b45f796a192D27a0',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // USDT / ETH
  '0xEe9F2375b4bdF6387aa8265dD4FB8F16512A1d46': {
    from: '0xdAC17F958D2ee523a2206206994597C13D831ec7',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 6,
    toDecimals: 18
  },
  // USDT / USD
  '0x3E7d1eAB13ad0104d2750B8863b489D65364e32D': {
    from: '0xdAC17F958D2ee523a2206206994597C13D831ec7',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 6,
    toDecimals: 8
  },
  // UST / ETH
  '0xa20623070413d42a5C01Db2c8111640DD7A5A03a': {
    from: '0xa47c8bf37f92aBed4A126BDA807A7b7498661acD',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // VSP / ETH
  '0x99cd3337Aa0da455845d7aFE7781341fDAE4D2EF': {
    from: '0x1b40183EFB4Dd766f11bDa7A7c3AD8982e998421',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // WAVES / USD
  '0x9a79fdCd0E326dF6Fa34EA13c05d3106610798E9': {
    from: '0x1cF4592ebfFd730c7dc92c1bdFFDfc3B9EfCf29a',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // WNXM / ETH
  '0xe5Dc0A609Ab8bCF15d3f35cFaa1Ff40f521173Ea': {
    from: '0x0d438F3b5175Bebc262bF23753C1E53d03432bDE',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // WOM / ETH
  '0xcEBD2026d3C99F2a7CE028acf372C154aB4638a9': {
    from: '0xBd356a39BFf2cAda8E9248532DD879147221Cf76',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // WOO / ETH
  '0x926a93B44a887076eDd00257E5D42fafea313363': {
    from: '0x4691937a7508860F876c9c0a2a617E7d9E945D4B',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // XMR / USD
  '0xFA66458Cce7Dd15D8650015c4fce4D278271618F': {
    from: '0x465e07d6028830124BE2E4aA551fBe12805dB0f5',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // XRP / USD
  '0xCed2660c6Dd1Ffd856A5A82C67f3482d88C50b12': {
    from: '0xa2B0fDe6D710e201d0d608e924A484d1A5fEd57c',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // YFI / ETH
  '0x7c5d4F8345e66f68099581Db340cd65B078C41f4': {
    from: '0x0bc529c00C6401aEF6D220BE8C6Ea1667F6Ad93e',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // YFI / USD
  '0xA027702dbb89fbd58938e4324ac03B58d812b0E1': {
    from: '0x0bc529c00C6401aEF6D220BE8C6Ea1667F6Ad93e',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // YFII / ETH
  '0xaaB2f6b45B28E962B3aCd1ee4fC88aEdDf557756': {
    from: '0xa1d0E215a23d7030842FC67cE582a6aFa3CCaB83',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // ZEC / USD
  '0xd54B033D48d0475f19c5fccf7484E8A981848501': {
    from: '0x1C5db575E2Ff833E46a2E9864C22F4B22E0B37C2',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 8,
    toDecimals: 8
  },
  // ZRX / ETH
  '0x2Da4983a622a8498bb1a21FaE9D8F6C664939962': {
    from: '0xE41d2489571d322189246DaFA5ebDe1F4699F498',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // ZRX / USD
  '0x2885d15b8Af22648b98B122b22FDF4D2a56c6023': {
    from: '0xE41d2489571d322189246DaFA5ebDe1F4699F498',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // sCEX / USD
  '0x283D433435cFCAbf00263beEF6A362b7cc5ed9f2': {
    from: '0xeABACD844A196D7Faf3CE596edeBF9900341B420',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // sDEFI / USD
  '0xa8E875F94138B0C5b51d1e1d5dE35bbDdd28EA87': {
    from: '0xe1aFe1Fd76Fd88f78cBf599ea1846231B8bA3B6B',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // SUSD / USD
  '0xad35Bd71b9aFE6e4bDc266B345c198eaDEf9Ad94': {
    from: '0x57Ab1ec28D129707052df4dF418D58a2D46d5f51',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // XSUSHI / ETH (Not Chainlink)
  '0xAE51d1f913eDB0f80562F270017806f3e9566029': {
    from: '0x8798249c2E607446EfB7Ad49eC89dD1865Ff4272',
    to: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // AMZN / USD
  '0x8994115d287207144236c13Be5E2bDbf6357D9Fd': {
    from: '0x0cae9e4d663793c2a2A0b211c1Cf4bBca2B9cAa7',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // GOOGL / USD
  '0x36D39936BeA501755921beB5A382a88179070219': {
    from: '0x59A921Db27Dd6d4d974745B7FfC5c33932653442',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // MSFT / USD
  '0x021Fb44bfeafA0999C7b07C4791cf4B859C3b431': {
    from: '0x41BbEDd7286dAab5910a1f15d12CBda839852BD7',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // NFLX / USD
  '0x67C2e69c5272B94AF3C90683a9947C39Dc605ddE': {
    from: '0xC8d674114bac90148d11D3C1d33C61835a0F9DCD',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // TSLA / USD
  '0x1ceDaaB50936881B3e449e47e40A2cDAF5576A4a': {
    from: '0x21cA39943E91d704678F5D00b6616650F066fD63',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // FB / USD
  '0xCe1051646393087e706288C1B57Fd26446657A7f': {
    from: '0x0e99cC0535BB6251F6679Fa6E65d6d3b430e840B',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  }
};
/* harmony default export */ var mappings_mainnet = (MAINNET_CHAINLINK_MAPPING);
;// CONCATENATED MODULE: ./src/constants/chainlink/mappings/matic.ts
const MATIC_CHAINLINK_MAPPING = {
  // AAVE / ETH
  '0xbE23a3AA13038CfC28aFd0ECe4FdE379fE7fBfc4': {
    from: '0xD6DF932A45C0f255f85145f286eA0b292B21C90B',
    to: '0x7ceB23fD6bC0adD59E62ac25578270cFf1b9f619',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // BOND / USD
  '0x58527C2dCC755297bB81f9334b80b2B6032d8524': {
    from: '0xA041544fe2BE56CCe31Ebb69102B965E06aacE80',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // BTC / USD

  /*'0xc907E116054Ad103354f2D350FD2514433D57F6f': {
    from: '',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8,
  },*/
  // BZRX / USD
  '0x6b7D436583e5fE0874B7310b74D29A13af816860': {
    from: '0x54cFe73f2c7d0c4b62Ab869B473F5512Dc0944D2',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // CEL / USD
  '0xc9ECF45956f576681bDc01F79602A79bC2667B0c': {
    from: '0xD85d1e945766Fea5Eda9103F918Bd915FbCa63E6',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // CRV / ETH
  '0x1CF68C76803c9A415bE301f50E82e44c64B7F1D4': {
    from: '0xD533a949740bb3306d119CC777fa900bA034cd52',
    to: '0x7ceB23fD6bC0adD59E62ac25578270cFf1b9f619',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // DAI /ETH
  '0xFC539A559e170f848323e19dfD66007520510085': {
    from: '0x8f3Cf7ad23Cd3CaDbD9735AFf958023239c6A063',
    to: '0x7ceB23fD6bC0adD59E62ac25578270cFf1b9f619',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // DAI / USD
  '0x4746DeC9e833A82EC7C2C1356372CcF2cfcD2F3D': {
    from: '0x8f3Cf7ad23Cd3CaDbD9735AFf958023239c6A063',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // DOGE / USD
  '0xbaf9327b6564454F4a3364C33eFeEf032b4b4444': {
    from: '0x7C4A54f5d20b4023D6746F1f765f4DFe7C39a7e6',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // ETH / USD
  '0xF9680D99D6C9589e2a93a78A04A279e509205945': {
    from: '0x7ceB23fD6bC0adD59E62ac25578270cFf1b9f619',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // FXS / USD
  '0x6C0fe985D3cAcbCdE428b84fc9431792694d0f51': {
    from: '0x3e121107F6F22DA4911079845a470757aF4e1A1b',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // JPY / USD
  '0xD647a6fC9BC6402301583C91decC5989d8Bc382D': {
    from: '0x6AE7Dfc73E0dDE2aa99ac063DcF7e8A63265108c',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // LINK /ETH
  '0xb77fa460604b9C6435A235D057F7D319AC83cb53': {
    from: '0x53E0bca35eC356BD5ddDFebbD1Fc0fD03FaBad39',
    to: '0x7ceB23fD6bC0adD59E62ac25578270cFf1b9f619',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // LINK / USD
  '0xd9FFdb71EbE7496cC440152d43986Aae0AB76665': {
    from: '0x53E0bca35eC356BD5ddDFebbD1Fc0fD03FaBad39',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // MATIC / ETH
  '0x327e23A4855b6F663a28c5161541d69Af8973302': {
    from: '0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270',
    to: '0x7ceB23fD6bC0adD59E62ac25578270cFf1b9f619',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // MATIC / USD
  '0xAB594600376Ec9fD91F8e885dADF0CE036862dE0': {
    from: '0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // MFT / USD
  '0x6E53C1c22427258BE55aE985a65c0C87BB631F9C': {
    from: '0x91cA694d2B293f70Fe722fbA7d8A5259188959c3',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // MKR / ETH
  '0x807b59d12520830D1864286FA0271c27baa94197': {
    from: '0x6f7C932e7684666C9fd1d44527765433e01fF61d',
    to: '0x7ceB23fD6bC0adD59E62ac25578270cFf1b9f619',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // RCN / BTC
  '0x040DACDA344a026350f6884ec212c405a1616506': {
    from: '0x89C296Be2F904F3e99a6125815b4B78F5388d2dd',
    to: '0x1BFD67037B42Cf73acF2047067bd4F2C47D9BfD6',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // SAND / USD
  '0x3D49406EDd4D52Fb7FFd25485f32E073b529C924': {
    from: '0xC6d54D2f624bc83815b49d9c2203b1330B841cA0',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // SNX / USD
  '0xbF90A5D9B6EE9019028dbFc2a9E50056d5252894': {
    from: '0x50B728D8D964fd00C2d0AAD81718b71311feF68a',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // SUSHI / USD
  '0x49B0c695039243BBfEb8EcD054EB70061fd54aa0': {
    from: '0x0b3F868E0BE5597D5DB7fEB59E1CADBb0fdDa50a',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // UNI / ETH
  '0x162d8c5bF15eB6BEe003a1ffc4049C92114bc931': {
    from: '0xb33EaAd8d922B1083446DC23f610c2567fB5180f',
    to: '0x7ceB23fD6bC0adD59E62ac25578270cFf1b9f619',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  },
  // USDC / ETH
  '0xefb7e6be8356cCc6827799B6A7348eE674A80EaE': {
    from: '0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174',
    to: '0x7ceB23fD6bC0adD59E62ac25578270cFf1b9f619',
    decimals: 18,
    fromDecimals: 6,
    toDecimals: 18
  },
  // USDC / USD
  '0xfE4A8cc5b5B2366C1B58Bea3858e81843581b2F7': {
    from: '0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 6,
    toDecimals: 8
  },
  // USDT / ETH
  '0xf9d5AAC6E5572AEFa6bd64108ff86a222F69B64d': {
    from: '0xc2132D05D31c914a87C6611C10748AEb04B58e8F',
    to: '0x7ceB23fD6bC0adD59E62ac25578270cFf1b9f619',
    decimals: 18,
    fromDecimals: 6,
    toDecimals: 18
  },
  // USDT / USD
  '0x0A6513e40db6EB1b165753AD52E80663aeA50545': {
    from: '0xc2132D05D31c914a87C6611C10748AEb04B58e8F',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 6,
    toDecimals: 8
  },
  // WBTC / ETH
  '0xA338e0492B2F944E9F8C0653D3AD1484f2657a37': {
    from: '0x1BFD67037B42Cf73acF2047067bd4F2C47D9BfD6',
    to: '0x7ceB23fD6bC0adD59E62ac25578270cFf1b9f619',
    decimals: 8,
    fromDecimals: 8,
    toDecimals: 18
  },
  // WBTC / USD
  '0xc907E116054Ad103354f2D350FD2514433D57F6f': {
    from: '0x1BFD67037B42Cf73acF2047067bd4F2C47D9BfD6',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // YFI / ETH
  '0x9896A1eA7A00F5f32Ab131eBbeE07487B0af31D0': {
    from: '0xb8cb8a7F4C2885C03e57E973C74827909Fdc2032',
    to: '0x7ceB23fD6bC0adD59E62ac25578270cFf1b9f619',
    decimals: 18,
    fromDecimals: 18,
    toDecimals: 18
  }
};
/* harmony default export */ var mappings_matic = (MATIC_CHAINLINK_MAPPING);
;// CONCATENATED MODULE: ./src/constants/chainlink/mappings/xdai.ts
const XDAI_CHAINLINK_MAPPING = {
  // 1INCH / USD
  '0xFDF9EB5fafc11Efa65f6FD144898da39a7920Ae8': {
    from: '0x7f7440C5098462f833E123B44B8A03E1d9785BAb',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // AAVE / USD
  '0x2b481Dc923Aa050E009113Dca8dcb0daB4B68cDF': {
    from: '0xDF613aF6B44a31299E48131e9347F034347E2F00',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // ALPHA / USD
  '0x7969b8018928F3d9faaE9AC71744ed2C1486536F': {
    from: '0xD4576749f6cd3FA97F4De3eEeB9043f517468262',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // BAL / USD
  '0x1b723C855F7D2c2785F99486973271355e782d77': {
    from: '0x7eF541E2a22058048904fE5744f9c7E4C57AF717',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // BTC / USD
  '0x6C1d7e76EF7304a40e8456ce883BC56d3dEA3F7d': {
    from: '0x8e5bBbb09Ed1ebdE8674Cda39A0c169401db4252',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 8,
    toDecimals: 8
  },
  // COMP  / USD
  '0xBa95Bc8418Ebcdf8a690924E1d4aD5292139F2EA': {
    from: '0xDf6FF92bfDC1e8bE45177DC1f4845d391D3ad8fD',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // CREAM  / USD
  '0x3b681e9BF56eFe4b2a14196826230A5843fFF758': {
    from: '0x1939D3431CF0E44B1d63b86e2cE489E5a341B1Bf',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // CRV  / USD
  '0xC77B83ac3Dd2a761073bD0f281f7b880B2DDDe18': {
    from: '0x712b3d230F3C1c19db860d80619288b1F0BDd0Bd',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // DAI / USD
  '0x678df3415fc31947dA4324eC63212874be5a82f8': {
    from: '0xe91D153E0b41518A2Ce8Dd3D7944Fa863463a97d',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // DOT / USD
  '0x3c30c5c415B2410326297F0f65f5Cbb32f3aefCc': {
    from: '0xe51Cf68301B30b06c72d38f5314FA85c94C8e5f1',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // DPI / USD
  '0x53B1b13E7a5C0DE9A2BeFa1085Ec364BB27e439f': {
    from: '0xD3D47d5578e55C880505dC40648F7F9307C3e7A8',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // ETH / USD
  '0xa767f745331D267c7751297D982b050c93985627': {
    from: '0x6A023CCd1ff6F2045C3309768eAd9E68F978f6e1',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // FTT / USD
  '0x0CaE8f5c10931f0Ce87Ed9BbB71391C6E93C2C26': {
    from: '0x75886F00c1a20Ec1511111Fb4Ec3C51de65B1fe7',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // GRT / USD
  '0xeBbd67a84e33791F1bcFde74CDc22a71e332e2F1': {
    from: '0xFAdc59D012Ba3c110B08A15B7755A5cb7Cbe77D7',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // JPY / USD
  '0x2AfB993C670C01e9dA1550c58e8039C1D8b8A317': {
    from: '0x417602f4fbdd471A431Ae29fB5fe0A681964C11b',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // LINK / USD
  '0xed322A5ac55BAE091190dFf9066760b86751947B': {
    from: '0xE2e73A1c69ecF83F464EFCE6A5be353a37cA09b2',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // MKR / USD
  '0x51e4024255d0cBd1F4C79AEe6BDB6565Df2C5d1b': {
    from: '0x5fd896D248fbfa54d26855C267859eb1b4DAEe72',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // PERP / USD
  '0x76e76F7E73F3BD42E3c2b4282B50b36E78130B4A': {
    from: '0x7ecF26cd9A36990b8ea477853663092333f59979',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // REN / USD
  '0x27d4D36968a2BD1Cc3406D99cB1DF50561dBf2a4': {
    from: '0x0da1a02CDF84C44021671d183d616925164E08Aa',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // RUNE / USD
  '0x93e3510d9AF4cBac3Ff0EeD3bddb0f52cCE0Ef15': {
    from: '0x4c68041898bfEfbfCc4253fbE8eD30830E6eb767',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // SNX / USD
  '0x3b84d6e6976D5826500572600eB44f9f1753827b': {
    from: '0x3A00E08544d589E19a8e7D97D0294331341cdBF6',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // STAKE / USD
  '0x55f4b2D20d447dB498bCCCde60Fa9a51a3df6D72': {
    from: '0xb7D311E2Eb55F2f68a9440da38e7989210b9A05e',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // SUSHI / USD
  '0xC0a6Bf8d5D408B091D022C3C0653d4056D4B9c01': {
    from: '0x2995D1317DcD4f0aB89f4AE60F3f020A4F17C7CE',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // UMA / USD
  '0xF826E3ff8c0481D2e58DB9d301936F94Cd4fa916': {
    from: '0x5806212Bec491bEb309E3F5C1F911eaC6f24cd6b',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // UNI / USD
  '0xd98735d78266c62277Bb4dBf3e3bCdd3694782F4': {
    from: '0x4537e328Bf7e4eFA29D05CAeA260D7fE26af9D74',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  },
  // USDC / USD
  '0x26C31ac71010aF62E6B486D1132E266D6298857D': {
    from: '0xDDAfbb505ad214D7b80b1f830fcCc89B60fb7A83',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 6,
    toDecimals: 8
  },
  // YFI / USD
  '0x14030d5a0C9e63D9606C6f2c8771Fc95b34b07e0': {
    from: '0xbf65bfcb5da067446CeE6A706ba3Fe2fB1a9fdFd',
    to: '0x0000000000000000000000000000000000000001',
    decimals: 8,
    fromDecimals: 18,
    toDecimals: 8
  }
};
/* harmony default export */ var xdai = (XDAI_CHAINLINK_MAPPING);
;// CONCATENATED MODULE: ./src/constants/chainlink/mappings/index.ts







const CHAINLINK_MAPPING = {
  [sdk_.ChainId.MAINNET]: mappings_mainnet,
  [sdk_.ChainId.KOVAN]: mappings_kovan,
  [sdk_.ChainId.BSC]: mappings_bsc,
  [sdk_.ChainId.HECO]: mappings_heco,
  [sdk_.ChainId.MATIC]: mappings_matic,
  [sdk_.ChainId.XDAI]: xdai
};
;// CONCATENATED MODULE: ./src/constants/chainlink/index.ts



/***/ }),

/***/ 3801:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "H": function() { return /* binding */ cloudinaryLoader; }
/* harmony export */ });
const normalize = src => {
  return src[0] === '/' ? src.slice(1) : src;
};

const cloudinaryLoader = ({
  src
}) => {
  return `https://res.cloudinary.com/dnz2bkszg/image/fetch/f_auto/${normalize(src)}`;
};

/***/ }),

/***/ 8908:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": function() { return /* binding */ Layout; }
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
// EXTERNAL MODULE: ./src/components/Footer/index.tsx + 1 modules
var Footer = __webpack_require__(4509);
// EXTERNAL MODULE: ./src/components/Header/index.tsx + 3 modules
var Header = __webpack_require__(9282);
// EXTERNAL MODULE: ./src/components/Image/index.tsx
var Image = __webpack_require__(5579);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./src/components/Main/index.tsx
var Main = __webpack_require__(6659);
// EXTERNAL MODULE: ./src/components/NavLink/index.tsx
var NavLink = __webpack_require__(3233);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
;// CONCATENATED MODULE: ./public/kashi-logo.png
/* harmony default export */ var kashi_logo = ({"src":"/_next/static/image/public/kashi-logo.62f59b2e457064a93dda7212b580fa26.png","height":465,"width":1819,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAYAAABllJ3tAAAATUlEQVR4nGM8/eLHzD//Gfn23XpWrifIIcLHxa7wj4HxLwMjE+unL1/fMJ599nnyx68/+B+9/bxfkJv7Hi8bsxBQATMDE9P/z5+/vgUAGvYfTBCY2osAAAAASUVORK5CYII="});
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(6731);
// EXTERNAL MODULE: ./src/components/Popups/index.tsx + 2 modules
var Popups = __webpack_require__(1522);
;// CONCATENATED MODULE: ./src/layouts/Kashi/index.tsx












function Layout({
  left = undefined,
  children = undefined,
  right = undefined
}) {
  const router = (0,router_.useRouter)();
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "z-0 flex flex-col items-start w-full h-full overflow-x-hidden overflow-y-auto",
    children: [/*#__PURE__*/jsx_runtime_.jsx(Header/* default */.Z, {}), /*#__PURE__*/jsx_runtime_.jsx(Main/* default */.Z, {
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "container px-0 mx-auto",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: `mb-2 grid grid-cols-12 gap-4`,
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "flex justify-center col-span-12 xl:col-span-3 lg:justify-start",
            children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
              href: "/borrow",
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                className: "flex justify-center xl:justify-start xl:mx-8",
                children: /*#__PURE__*/jsx_runtime_.jsx(Image/* default */.Z, {
                  src: kashi_logo,
                  alt: "Kashi",
                  height: 64,
                  width: 250
                })
              })
            })
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "flex items-end col-span-12 xl:col-span-9",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("nav", {
              className: "flex items-center justify-between w-full",
              children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: "flex",
                children: [/*#__PURE__*/jsx_runtime_.jsx(NavLink/* default */.Z, {
                  href: "/lend",
                  children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                    className: 'pl-4 pr-2 sm:pl-8 sm:pr-4 flex items-center font-medium ' + (router.pathname.startsWith('/lend') ? 'text-high-emphesis' : 'text-secondary hover:text-primary'),
                    children: /*#__PURE__*/jsx_runtime_.jsx("div", {
                      className: "text-base whitespace-nowrap",
                      children: "Lend"
                    })
                  })
                }), /*#__PURE__*/jsx_runtime_.jsx(NavLink/* default */.Z, {
                  href: "/borrow",
                  children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                    className: 'px-2 sm:px-4 flex items-center font-medium ' + (router.pathname.startsWith('/borrow') ? 'text-high-emphesis' : 'text-secondary hover:text-primary'),
                    children: /*#__PURE__*/jsx_runtime_.jsx("div", {
                      className: "text-base whitespace-nowrap",
                      children: "Borrow"
                    })
                  })
                }), /*#__PURE__*/jsx_runtime_.jsx(NavLink/* default */.Z, {
                  href: "/kashi/create",
                  children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                    className: 'px-2 sm:px-4 flex items-center font-medium ' + (router.pathname.startsWith('/kashi/create') ? 'text-high-emphesis' : 'text-secondary hover:text-primary'),
                    children: /*#__PURE__*/jsx_runtime_.jsx("div", {
                      className: "text-base whitespace-nowrap",
                      children: "Create"
                    })
                  })
                })]
              }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "flex pr-2 sm:pr-4",
                children: /*#__PURE__*/jsx_runtime_.jsx(NavLink/* default */.Z, {
                  href: "/balances",
                  children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
                    className: `px-2 sm:px-4 flex justify-end items-center font-medium ${router.pathname === '/balances' ? 'text-high-emphesis' : 'text-secondary hover:text-primary'}`,
                    children: [/*#__PURE__*/jsx_runtime_.jsx("svg", {
                      className: "mr-2 fill-current",
                      width: 24,
                      height: 24,
                      xmlns: "http://www.w3.org/2000/svg",
                      viewBox: "0 0 355.24 205.5",
                      children: /*#__PURE__*/jsx_runtime_.jsx("path", {
                        d: "M350.43,97c-8.7-20-28.9-43.7-56.7-63.5S237.13,2,215.43.2c-1.2-.1-2.4-.2-3.5-.2H76.53c-13,0-23,4-28.4,11.7L4.63,72.3c-6.3,8.8-6.1,21.7.2,36.2,8.7,20,29,43.7,56.7,63.5s56.7,31.5,78.4,33.3c1.7.1,3.3.2,4.9.2h135.5c12.1-.4,21.5-4.3,26.8-11.6l43.4-60.6C356.93,124.3,356.73,111.5,350.43,97ZM209.93,7.4c1.6,0,3.2.1,4.9.2,20.7,1.7,48.2,13,74.6,31.9,4.3,3.1,11.8,9.7,15.7,12.9H188.43l-45-45ZM41.06,40.25c0-1.12-.15-2.24-.15-3.36a1.67,1.67,0,0,1,1.58-1.74,1.62,1.62,0,0,1,1.74,1.61,23.39,23.39,0,0,0,.15,3.11A1.52,1.52,0,0,1,43,41.62,1.68,1.68,0,0,1,41.06,40.25Zm53.15,71.67a1.74,1.74,0,0,1-2.37.13C72.54,95.5,48.5,72,42.33,47a1.77,1.77,0,0,1,1.27-2,1.83,1.83,0,0,1,2,1.24c6,24.39,29.58,47.16,48.41,63.46A1.7,1.7,0,0,1,94.21,111.92ZM173,146.77a1.5,1.5,0,0,1-1.89,1.24c-2.22-.37-4.27-1-6.49-1.49a1.58,1.58,0,0,1-1.11-2.12,1.52,1.52,0,0,1,2.06-1.12l6.17,1.49A1.7,1.7,0,0,1,173,146.77ZM200.51,150c-6.49,1.12-14.4.75-22.94-.62a1.63,1.63,0,0,1-1.42-1.87,1.68,1.68,0,0,1,1.9-1.37c8.22,1.37,15.66,1.75,22,.63a1.67,1.67,0,0,1,1.9,1.36A1.62,1.62,0,0,1,200.51,150Zm-11.78-12.6c-1.6,0-3.1-.1-4.7-.2-20.8-1.7-48.3-13-74.7-31.9s-45.8-41.4-54.2-60.5c-4.9-11.3-5.9-21.4-1.2-28.4l.3-.4c4.1-5.8,11.6-8.4,21.2-8.6h57.5l130,130Zm155.8-8.7-.3.4c-4.2,5.6-11.7,8.1-21.1,8.2h-49.7l-77.9-77.9h117.7c15.8,14.6,24.4,26.8,30.3,40.5C348.63,111.5,349.63,121.8,344.53,128.7Z"
                      })
                    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                      className: "text-base whitespace-nowrap",
                      children: "BentoBox"
                    })]
                  })
                })
              })]
            })
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: `grid grid-cols-12 gap-4 min-h-1/2`,
          children: [left && /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: `hidden xl:block xl:col-span-3`,
            style: {
              maxHeight: '40rem'
            },
            children: left
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: `col-span-12 ${right ? 'lg:col-span-8 xl:col-span-6' : 'xl:col-span-9'}`,
            style: {
              minHeight: '40rem'
            },
            children: children
          }), right && /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "col-span-12 lg:col-span-4 xl:col-span-3",
            style: {
              maxHeight: '40rem'
            },
            children: right
          })]
        })]
      })
    }), /*#__PURE__*/jsx_runtime_.jsx(Popups/* default */.Z, {}), /*#__PURE__*/jsx_runtime_.jsx(Footer/* default */.Z, {})]
  });
}

/***/ })

};
;