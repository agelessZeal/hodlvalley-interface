exports.id = 3302;
exports.ids = [3302];
exports.modules = {

/***/ 3302:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "E": function() { return /* binding */ getExplorerLink; }
/* harmony export */ });
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6766);
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__);
 // Multichain Explorer

const builders = {
  etherscan: (chainName, data, type) => {
    const prefix = `https://${chainName ? `${chainName}.` : ''}etherscan.io`;

    switch (type) {
      case 'transaction':
        return `${prefix}/tx/${data}`;

      default:
        return `${prefix}/${type}/${data}`;
    }
  },
  fantom: (chainName, data, type) => {
    const prefix = 'https://ftmscan.com';

    switch (type) {
      case 'transaction':
        return `${prefix}/tx/${data}`;

      default:
        return `${prefix}/${type}/${data}`;
    }
  },
  xdai: (chainName, data, type) => {
    const prefix = `https://blockscout.com/poa/xdai`;

    switch (type) {
      case 'transaction':
        return `${prefix}/tx/${data}`;

      case 'token':
        return `${prefix}/tokens/${data}`;

      default:
        return `${prefix}/${type}/${data}`;
    }
  },
  bscscan: (chainName, data, type) => {
    const prefix = `https://${chainName ? `${chainName}.` : ''}bscscan.com`;

    switch (type) {
      case 'transaction':
        return `${prefix}/tx/${data}`;

      default:
        return `${prefix}/${type}/${data}`;
    }
  },
  matic: (chainName, data, type) => {
    // const prefix = `https://explorer-${chainName}.maticvigil.com`
    const prefix = 'https://polygonscan.com';

    switch (type) {
      case 'transaction':
        return `${prefix}/tx/${data}`;

      case 'token':
        return `${prefix}/tokens/${data}`;

      default:
        return `${prefix}/${type}/${data}`;
    }
  },
  // token is not yet supported for arbitrum
  arbitrum: (chainName, data, type) => {
    const prefix = `https://mainnet-arb-explorer.netlify.app`;

    switch (type) {
      case 'transaction':
        return `${prefix}/tx/${data}`;

      default:
        return `${prefix}/${type}/${data}`;
    }
  },
  // token is not yet supported for arbitrum
  arbitrumTestnet: (chainName, data, type) => {
    const prefix = `https://explorer.offchainlabs.com/#`;

    switch (type) {
      case 'transaction':
        return `${prefix}/tx/${data}`;

      case 'token':
        return prefix;

      default:
        return `${prefix}/${type}/${data}`;
    }
  },
  moonbase: (chainName, data, type) => {
    const prefix = 'https://moonbeam-explorer.netlify.app';

    switch (type) {
      case 'transaction':
        return `${prefix}/tx/${data}`;

      case 'address':
        return `${prefix}/address/${data}`;

      default:
        return `${prefix}/${type}/${data}`;
    }
  },
  avalanche: (chainName, data, type) => {
    const prefix = `https://cchain.explorer.avax${chainName ? `-${chainName}` : ''}.network`;

    switch (type) {
      case 'transaction':
        return `${prefix}/tx/${data}`;

      default:
        return `${prefix}/${type}/${data}`;
    }
  },
  heco: (chainName = '', data, type) => {
    const prefix = `https://${chainName ? `${chainName}.` : ''}hecoinfo.com`;

    switch (type) {
      case 'transaction':
        return `${prefix}/tx/${data}`;

      default:
        return `${prefix}/${type}/${data}`;
    }
  },
  harmony: (chainName = '', data, type) => {
    const prefix = 'https://beta.explorer.harmony.one/#';

    switch (type) {
      case 'transaction':
        return `${prefix}/tx/${data}`;

      default:
        return `${prefix}/${type}/${data}`;
    }
  },
  harmonyTestnet: (chainName = '', data, type) => {
    const prefix = 'https://explorer.pops.one/#';

    switch (type) {
      case 'transaction':
        return `${prefix}/tx/${data}`;

      default:
        return `${prefix}/${type}/${data}`;
    }
  },
  okex: (chainName = '', data, type) => {
    const prefix = 'https://www.oklink.com/okexchain';

    switch (type) {
      case 'transaction':
        return `${prefix}/tx/${data}`;

      case 'token':
        return `${prefix}/tokenAddr/${data}`;

      default:
        return `${prefix}/${type}/${data}`;
    }
  },
  okexTestnet: (chainName = '', data, type) => {
    const prefix = 'https://www.oklink.com/okexchain-test';

    switch (type) {
      case 'transaction':
        return `${prefix}/tx/${data}`;

      case 'token':
        return `${prefix}/tokenAddr/${data}`;

      default:
        return `${prefix}/${type}/${data}`;
    }
  },
  celo: (chainName, data, type) => {
    const prefix = 'https://explorer.celo.org';

    switch (type) {
      case 'transaction':
        return `${prefix}/tx/${data}`;

      case 'token':
        return `${prefix}/tokens/${data}`;

      default:
        return `${prefix}/${type}/${data}`;
    }
  }
};
const chains = {
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET]: {
    chainName: '',
    builder: builders.etherscan
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.ROPSTEN]: {
    chainName: 'ropsten',
    builder: builders.etherscan
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.RINKEBY]: {
    chainName: 'rinkeby',
    builder: builders.etherscan
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId["GÖRLI"]]: {
    chainName: 'goerli',
    builder: builders.etherscan
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.KOVAN]: {
    chainName: 'kovan',
    builder: builders.etherscan
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC]: {
    chainName: 'mainnet',
    builder: builders.matic
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC_TESTNET]: {
    chainName: 'mumbai',
    builder: builders.matic
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.FANTOM]: {
    chainName: '',
    builder: builders.fantom
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.FANTOM_TESTNET]: {
    chainName: 'testnet',
    builder: builders.fantom
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.XDAI]: {
    chainName: 'xdai',
    builder: builders.xdai
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.BSC]: {
    chainName: '',
    builder: builders.bscscan
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.BSC_TESTNET]: {
    chainName: 'testnet',
    builder: builders.bscscan
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.ARBITRUM]: {
    chainName: '',
    builder: builders.arbitrum
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.ARBITRUM_TESTNET]: {
    chainName: 'arbitrum',
    builder: builders.arbitrumTestnet
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MOONBEAM_TESTNET]: {
    chainName: '',
    builder: builders.moonbase
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.AVALANCHE]: {
    chainName: '',
    builder: builders.avalanche
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.AVALANCHE_TESTNET]: {
    chainName: 'test',
    builder: builders.avalanche
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HECO]: {
    chainName: '',
    builder: builders.heco
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HECO_TESTNET]: {
    chainName: 'testnet',
    builder: builders.heco
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HARMONY]: {
    chainName: '',
    builder: builders.harmony
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HARMONY_TESTNET]: {
    chainName: '',
    builder: builders.harmonyTestnet
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.OKEX]: {
    chainName: '',
    builder: builders.okex
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.OKEX_TESTNET]: {
    chainName: '',
    builder: builders.okexTestnet
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.CELO]: {
    chainName: '',
    builder: builders.celo
  }
};
function getExplorerLink(chainId, data, type) {
  const chain = chains[chainId];
  return chain.builder(chain.chainName, data, type);
}

/***/ })

};
;