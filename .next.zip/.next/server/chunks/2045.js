exports.id = 2045;
exports.ids = [2045];
exports.modules = {

/***/ 2045:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "D": function() { return /* binding */ WrappedTokenInfo; }
/* harmony export */ });
/* harmony import */ var _functions_validate__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2556);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



/**
 * Token instances created from token info on a token list.
 */
class WrappedTokenInfo {
  constructor(tokenInfo, list) {
    _defineProperty(this, "isNative", false);

    _defineProperty(this, "isToken", true);

    _defineProperty(this, "list", void 0);

    _defineProperty(this, "tokenInfo", void 0);

    _defineProperty(this, "_checksummedAddress", null);

    _defineProperty(this, "_tags", null);

    this.tokenInfo = tokenInfo;
    this.list = list;
  }

  get address() {
    if (this._checksummedAddress) return this._checksummedAddress;
    const checksummedAddress = (0,_functions_validate__WEBPACK_IMPORTED_MODULE_0__/* .isAddress */ .UJ)(this.tokenInfo.address);
    if (!checksummedAddress) throw new Error(`Invalid token address: ${this.tokenInfo.address}`);
    return this._checksummedAddress = checksummedAddress;
  }

  get chainId() {
    return this.tokenInfo.chainId;
  }

  get decimals() {
    return this.tokenInfo.decimals;
  }

  get name() {
    return this.tokenInfo.name;
  }

  get symbol() {
    return this.tokenInfo.symbol;
  }

  get logoURI() {
    return this.tokenInfo.logoURI;
  }

  get tags() {
    if (this._tags !== null) return this._tags;
    if (!this.tokenInfo.tags) return this._tags = [];
    const listTags = this.list.tags;
    if (!listTags) return this._tags = [];
    return this._tags = this.tokenInfo.tags.map(tagId => {
      return _objectSpread(_objectSpread({}, listTags[tagId]), {}, {
        id: tagId
      });
    });
  }

  equals(other) {
    return other.chainId === this.chainId && other.isToken && other.address.toLowerCase() === this.address.toLowerCase();
  }

  sortsBefore(other) {
    if (this.equals(other)) throw new Error('Addresses should not be equal');
    return this.address.toLowerCase() < other.address.toLowerCase();
  }

  get wrapped() {
    return this;
  }

}

/***/ })

};
;