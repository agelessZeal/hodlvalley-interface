exports.id = 4640;
exports.ids = [4640];
exports.modules = {

/***/ 4640:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ GnosisManager; }
/* harmony export */ });
/* harmony import */ var _gnosis_pm_safe_apps_web3_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(255);
/* harmony import */ var _gnosis_pm_safe_apps_web3_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_gnosis_pm_safe_apps_web3_react__WEBPACK_IMPORTED_MODULE_0__);

const safeMultisigConnector = new _gnosis_pm_safe_apps_web3_react__WEBPACK_IMPORTED_MODULE_0__.SafeAppConnector();
function GnosisManager() {
  const triedToConnectToSafe = (0,_gnosis_pm_safe_apps_web3_react__WEBPACK_IMPORTED_MODULE_0__.useSafeAppConnection)(safeMultisigConnector);
  return null;
}

/***/ })

};
;