exports.id = 4495;
exports.ids = [4495,7271,4419,6919];
exports.modules = {

/***/ 0:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _hooks_useENS__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1543);
/* harmony import */ var _lingui_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2339);
/* harmony import */ var _lingui_react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_lingui_react__WEBPACK_IMPORTED_MODULE_3__);






const AddressInputPanel = ({
  id,
  value,
  onChange
}) => {
  const {
    i18n
  } = (0,_lingui_react__WEBPACK_IMPORTED_MODULE_3__.useLingui)();
  const {
    address,
    loading
  } = (0,_hooks_useENS__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z)(value);
  const handleInput = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(event => {
    const input = event.target.value;
    const withoutSpaces = input.replace(/\s+/g, '');
    onChange(withoutSpaces);
  }, [onChange]);
  const error = Boolean(value.length > 0 && !loading && !address);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
    className: `flex flex-row bg-dark-800 rounded items-center h-[68px] ${error ? 'border border-red border-opacity-50' : ''}`,
    id: id,
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
      className: "flex justify-between w-full sm:w-2/5 px-5",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
        className: "text-[18px] text-primary",
        children: i18n._(
        /*i18n*/
        i18n._("Send to:"))
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
        className: "text-blue text-sm underline cursor-pointer",
        onClick: () => onChange(null),
        children: i18n._(
        /*i18n*/
        i18n._("Remove"))
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
      className: "flex w-full h-full sm:w-3/5 border-2 border-dark-800 rounded-r",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
        className: "p-3 w-full flex overflow-ellipsis font-bold recipient-address-input bg-dark-900 h-full w-full rounded placeholder-low-emphesis",
        type: "text",
        autoComplete: "off",
        autoCorrect: "off",
        autoCapitalize: "off",
        spellCheck: "false",
        placeholder: "Wallet Address or ENS name",
        pattern: "^(0x[a-fA-F0-9]{40})$",
        onChange: handleInput,
        value: value
      })
    })]
  });
};

/* harmony default export */ __webpack_exports__["Z"] = (AddressInputPanel);

/***/ }),

/***/ 7271:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": function() { return /* binding */ components_CurrencyLogo; },
  "a": function() { return /* binding */ getTokenLogoURL; }
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
// EXTERNAL MODULE: external "@sushiswap/sdk"
var sdk_ = __webpack_require__(6766);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./src/components/Logo/index.tsx
var Logo = __webpack_require__(5914);
// EXTERNAL MODULE: ./src/state/lists/wrappedTokenInfo.ts
var wrappedTokenInfo = __webpack_require__(2045);
;// CONCATENATED MODULE: ./src/constants/maticTokenMapping.ts
const getMaticTokenLogoURL = address => {
  var _address, _address2, _address3, _address4, _address5, _address6, _address7, _address8, _address9, _address10, _address11, _address12, _address13, _address14, _address15, _address16, _address17, _address18, _address19, _address20, _address21, _address22, _address23, _address24, _address25, _address26, _address27, _address28, _address29, _address30, _address31, _address32, _address33, _address34, _address35, _address36, _address37, _address38, _address39, _address40, _address41, _address42, _address43, _address44, _address45, _address46, _address47, _address48, _address49, _address50, _address51, _address52, _address53, _address54, _address55, _address56, _address57, _address58, _address59, _address60, _address61, _address62, _address63, _address64, _address65, _address66, _address67, _address68, _address69, _address70, _address71, _address72, _address73, _address74, _address75, _address76, _address77, _address78, _address79, _address80, _address81, _address82, _address83, _address84;

  let uri;

  if (((_address = address) === null || _address === void 0 ? void 0 : _address.toLowerCase()) === '0x0d500b1d8e8ef31e21c99d1db9a6444d3adf1270') {
    address = '0x7D1AfA7B718fb893dB30A3aBc0Cfc608AaCfeBB0';
  }

  if (((_address2 = address) === null || _address2 === void 0 ? void 0 : _address2.toLowerCase()) === '0x8f3cf7ad23cd3cadbd9735aff958023239c6a063') {
    address = '0x6B175474E89094C44Da98b954EedeAC495271d0F';
  }

  if (((_address3 = address) === null || _address3 === void 0 ? void 0 : _address3.toLowerCase()) === '0xc2132d05d31c914a87c6611c10748aeb04b58e8f') {
    address = '0xdAC17F958D2ee523a2206206994597C13D831ec7';
  }

  if (((_address4 = address) === null || _address4 === void 0 ? void 0 : _address4.toLowerCase()) === '0x2791bca1f2de4661ed88a30c99a7a9449aa84174') {
    address = '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48';
  }

  if (((_address5 = address) === null || _address5 === void 0 ? void 0 : _address5.toLowerCase()) === '0xb33eaad8d922b1083446dc23f610c2567fb5180f') {
    address = '0x1f9840a85d5aF5bf1D1762F925BDADdC4201F984';
  }

  if (((_address6 = address) === null || _address6 === void 0 ? void 0 : _address6.toLowerCase()) === '0xdb3b3b147a030f032633f6c4bebf9a2fb5a882b5') {
    uri = 'https://raw.githubusercontent.com/sameepsi/quickswap-interface/master/assets/easyfi-token.png';
  }

  if (((_address7 = address) === null || _address7 === void 0 ? void 0 : _address7.toLowerCase()) === '0x831753dd7087cac61ab5644b308642cc1c33dc13') {
    uri = 'https://raw.githubusercontent.com/sameepsi/quickswap-interface/master/public/favicon.jpeg';
  }

  if (((_address8 = address) === null || _address8 === void 0 ? void 0 : _address8.toLowerCase()) === '0x1bfd67037b42cf73acf2047067bd4f2c47d9bfd6') {
    address = '0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599';
  }

  if (((_address9 = address) === null || _address9 === void 0 ? void 0 : _address9.toLowerCase()) === '0x385eeac5cb85a38a9a07a70c73e0a3271cfb54a7') {
    uri = 'https://etherscan.io/token/images/AavegotchiGHST_32.png';
  }

  if (((_address10 = address) === null || _address10 === void 0 ? void 0 : _address10.toLowerCase()) === '0x4ebde54ba404be158262ede801744b92b9878c61') {
    uri = 'https://raw.githubusercontent.com/sameepsi/quickswap-interface/master/assets/easyfi-token.png';
  }

  if (((_address11 = address) === null || _address11 === void 0 ? void 0 : _address11.toLowerCase()) === '0xa1c09c8f4f5d03fcc27b456475d53d988e98d7c5') {
    uri = 'https://raw.githubusercontent.com/sameepsi/quickswap-interface/master/assets/easyfi-token.png';
  }

  if (((_address12 = address) === null || _address12 === void 0 ? void 0 : _address12.toLowerCase()) === '0xfc39742fe9420a7af23757fc7e78d1c3ae4a9474') {
    uri = 'https://raw.githubusercontent.com/sameepsi/quickswap-interface/master/assets/easyfi-token.png';
  }

  if (((_address13 = address) === null || _address13 === void 0 ? void 0 : _address13.toLowerCase()) === '0x9f5755d47fb80100e7ee65bf7e136fca85dd9334') {
    uri = 'https://etherscan.io/token/images/om_32.png';
  }

  if (((_address14 = address) === null || _address14 === void 0 ? void 0 : _address14.toLowerCase()) === '0x9719d867a500ef117cc201206b8ab51e794d3f82') {
    uri = 'https://aavegotchi.com/images/matokens/maUSDC.svg';
  }

  if (((_address15 = address) === null || _address15 === void 0 ? void 0 : _address15.toLowerCase()) === '0xE0b22E0037B130A9F56bBb537684E6fA18192341'.toLowerCase()) {
    uri = 'https://aavegotchi.com/images/matokens/maDAI.svg';
  }

  if (((_address16 = address) === null || _address16 === void 0 ? void 0 : _address16.toLowerCase()) === '0x20D3922b4a1A8560E1aC99FBA4faDe0c849e2142'.toLowerCase()) {
    uri = 'https://aavegotchi.com/images/matokens/maWETH.svg';
  }

  if (((_address17 = address) === null || _address17 === void 0 ? void 0 : _address17.toLowerCase()) === '0x823CD4264C1b951C9209aD0DeAea9988fE8429bF'.toLowerCase()) {
    uri = 'https://aavegotchi.com/images/matokens/maAAVE.svg';
  }

  if (((_address18 = address) === null || _address18 === void 0 ? void 0 : _address18.toLowerCase()) === '0x98ea609569bD25119707451eF982b90E3eb719cD'.toLowerCase()) {
    uri = 'https://aavegotchi.com/images/matokens/maLINK.svg';
  }

  if (((_address19 = address) === null || _address19 === void 0 ? void 0 : _address19.toLowerCase()) === '0xDAE5F1590db13E3B40423B5b5c5fbf175515910b'.toLowerCase()) {
    uri = 'https://aavegotchi.com/images/matokens/maUSDT.svg';
  }

  if (((_address20 = address) === null || _address20 === void 0 ? void 0 : _address20.toLowerCase()) === '0xF4b8888427b00d7caf21654408B7CBA2eCf4EbD9'.toLowerCase()) {
    uri = 'https://aavegotchi.com/images/matokens/maTUSD.svg';
  }

  if (((_address21 = address) === null || _address21 === void 0 ? void 0 : _address21.toLowerCase()) === '0xe86E8beb7340659DDDCE61727E500e3A5aD75a90'.toLowerCase()) {
    uri = 'https://s2.gifyu.com/images/zutlogo.jpg';
  }

  if (((_address22 = address) === null || _address22 === void 0 ? void 0 : _address22.toLowerCase()) === '0x104592a158490a9228070e0a8e5343b499e125d0'.toLowerCase()) {
    uri = 'https://avatars.githubusercontent.com/u/56005256?s=200&v=4';
  }

  if (((_address23 = address) === null || _address23 === void 0 ? void 0 : _address23.toLowerCase()) === '0x9C78EE466D6Cb57A4d01Fd887D2b5dFb2D46288f'.toLowerCase()) {
    uri = 'https://etherscan.io/token/images/cometh_32.png';
  }

  if (((_address24 = address) === null || _address24 === void 0 ? void 0 : _address24.toLowerCase()) === '0x127984b5E6d5c59f81DACc9F1C8b3Bdc8494572e'.toLowerCase()) {
    uri = 'https://etherscan.io/token/images/pepedex_32.png?v=2';
  }

  if (((_address25 = address) === null || _address25 === void 0 ? void 0 : _address25.toLowerCase()) === '0x2a93172c8DCCbfBC60a39d56183B7279a2F647b4'.toLowerCase()) {
    uri = 'https://raw.githubusercontent.com/sameepsi/quickswap-default-token-list/master/assets/dg.jpg';
  }

  if (((_address26 = address) === null || _address26 === void 0 ? void 0 : _address26.toLowerCase()) === '0x3e121107F6F22DA4911079845a470757aF4e1A1b'.toLowerCase()) {
    uri = 'https://avatars.githubusercontent.com/u/56005256?s=200&v=4';
  }

  if (((_address27 = address) === null || _address27 === void 0 ? void 0 : _address27.toLowerCase()) === '0x104592a158490a9228070E0A8e5343B499e125D0'.toLowerCase()) {
    uri = 'https://raw.githubusercontent.com/trustwallet/assets/master/blockchains/ethereum/assets/0x853d955aCEf822Db058eb8505911ED77F175b99e/logo.png';
  }

  if (((_address28 = address) === null || _address28 === void 0 ? void 0 : _address28.toLowerCase()) === '0xab0b2ddB9C7e440fAc8E140A89c0dbCBf2d7Bbff'.toLowerCase()) {
    uri = 'https://raw.githubusercontent.com/harvestfi/assets/main/farm-logo.png';
  }

  if (((_address29 = address) === null || _address29 === void 0 ? void 0 : _address29.toLowerCase()) === '0x034b2090b579228482520c589dbD397c53Fc51cC'.toLowerCase()) {
    uri = 'https://s3-us-west-2.amazonaws.com/acf-uploads/apyvisionlogo200circle.png';
  }

  if (((_address30 = address) === null || _address30 === void 0 ? void 0 : _address30.toLowerCase()) === '0x7FBc10850caE055B27039aF31bD258430e714c62'.toLowerCase()) {
    uri = 'https://assets.coingecko.com/coins/images/2707/small/UnibrightLogo_colorful_500x500_preview.png?1547036916';
  }

  if (((_address31 = address) === null || _address31 === void 0 ? void 0 : _address31.toLowerCase()) === '0x0e59D50adD2d90f5111aca875baE0a72D95B4762'.toLowerCase()) {
    uri = 'https://dark-build.app/logo192.png';
  }

  if (((_address32 = address) === null || _address32 === void 0 ? void 0 : _address32.toLowerCase()) === '0x3809dcDd5dDe24B37AbE64A5a339784c3323c44F'.toLowerCase()) {
    uri = 'https://i.imgur.com/vZnU36G.png';
  }

  if (((_address33 = address) === null || _address33 === void 0 ? void 0 : _address33.toLowerCase()) === '0x23D29D30e35C5e8D321e1dc9A8a61BFD846D4C5C'.toLowerCase()) {
    uri = 'https://hex.com/favicon.png';
  }

  if (((_address34 = address) === null || _address34 === void 0 ? void 0 : _address34.toLowerCase()) === '0x07738Eb4ce8932CA961c815Cb12C9d4ab5Bd0Da4'.toLowerCase()) {
    uri = 'https://etherlegends.com/ELET.png';
  }

  if (((_address35 = address) === null || _address35 === void 0 ? void 0 : _address35.toLowerCase()) === '0x8d1566569d5b695d44a9a234540f68D393cDC40D'.toLowerCase()) {
    uri = 'https://i.imgur.com/IIUglm9.png?1';
  }

  if (((_address36 = address) === null || _address36 === void 0 ? void 0 : _address36.toLowerCase()) === '0x66768ad00746aC4d68ded9f64886d55d5243f5Ec'.toLowerCase()) {
    uri = 'https://rebalancetoken.io/images/logo/logo.png';
  }

  if (((_address37 = address) === null || _address37 === void 0 ? void 0 : _address37.toLowerCase()) === '0x8c8bdBe9CeE455732525086264a4Bf9Cf821C498'.toLowerCase()) {
    uri = 'https://aavegotchi.com/images/matokens/maUNI.svg';
  }

  if (((_address38 = address) === null || _address38 === void 0 ? void 0 : _address38.toLowerCase()) === '0xe20f7d1f0eC39C4d5DB01f53554F2EF54c71f613'.toLowerCase()) {
    uri = 'https://aavegotchi.com/images/matokens/maYFI.svg';
  }

  if (((_address39 = address) === null || _address39 === void 0 ? void 0 : _address39.toLowerCase()) === '0x840195888Db4D6A99ED9F73FcD3B225Bb3cB1A79'.toLowerCase()) {
    uri = 'https://raw.githubusercontent.com/sameepsi/quickswap-default-token-list/master/assets/sx.jpg';
  }

  if (((_address40 = address) === null || _address40 === void 0 ? void 0 : _address40.toLowerCase()) === '0xe6fc6c7cb6d2c31b359a49a33ef08ab87f4de7ce') {
    uri = 'https://assets.coingecko.com/coins/images/7697/small/N7aEdYrY_400x400.png?1561587437';
  }

  if (((_address41 = address) === null || _address41 === void 0 ? void 0 : _address41.toLowerCase()) === '0x53e0bca35ec356bd5dddfebbd1fc0fd03fabad39') {
    address = '0x514910771AF9Ca656af840dff83E8264EcF986CA';
  }

  if (((_address42 = address) === null || _address42 === void 0 ? void 0 : _address42.toLowerCase()) === '0x71b821aa52a49f32eed535fca6eb5aa130085978') {
    address = '0xB6eD7644C69416d67B522e20bC294A9a9B405B31';
  }

  if (((_address43 = address) === null || _address43 === void 0 ? void 0 : _address43.toLowerCase()) === '0xa1c57f48f0deb89f569dfbe6e2b7f46d33606fd4') {
    address = '0x0F5D2fB29fb7d3CFeE444a200298f468908cC942';
  }

  if (((_address44 = address) === null || _address44 === void 0 ? void 0 : _address44.toLowerCase()) === '0x8505b9d2254a7ae468c0e9dd10ccea3a837aef5c') {
    address = '0xc00e94Cb662C3520282E6f5717214004A7f26888';
  }

  if (((_address45 = address) === null || _address45 === void 0 ? void 0 : _address45.toLowerCase()) === '0x313d009888329c9d1cf4f75ca3f32566335bd604') {
    address = '0x80fB784B7eD66730e8b1DBd9820aFD29931aab03';
  }

  if (((_address46 = address) === null || _address46 === void 0 ? void 0 : _address46.toLowerCase()) === '0xda537104d6a5edd53c6fbba9a898708e465260b6') {
    address = '0x0bc529c00C6401aEF6D220BE8C6Ea1667F6Ad93e';
  }

  if (((_address47 = address) === null || _address47 === void 0 ? void 0 : _address47.toLowerCase()) === '0x7ceb23fd6bc0add59e62ac25578270cff1b9f619') {
    address = '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2';
  }

  if (((_address48 = address) === null || _address48 === void 0 ? void 0 : _address48.toLowerCase()) === '0x53E0bca35eC356BD5ddDFebbD1Fc0fD03FaBad39'.toLowerCase()) {
    uri = 'https://raw.githubusercontent.com/trustwallet/assets/master/blockchains/ethereum/assets/0x514910771AF9Ca656af840dff83E8264EcF986CA/logo.png';
  }

  if (((_address49 = address) === null || _address49 === void 0 ? void 0 : _address49.toLowerCase()) === '0xC3Ec80343D2bae2F8E680FDADDe7C17E71E114ea'.toLowerCase()) {
    uri = 'https://etherscan.io/token/images/mantradao_32.png';
  }

  if (((_address50 = address) === null || _address50 === void 0 ? void 0 : _address50.toLowerCase()) === '0xf28164A485B0B2C90639E47b0f377b4a438a16B1'.toLowerCase()) {
    uri = 'https://raw.githubusercontent.com/sameepsi/quickswap-interface/master/public/favicon.jpeg';
  }

  if (((_address51 = address) === null || _address51 === void 0 ? void 0 : _address51.toLowerCase()) === '0xd85d1e945766fea5eda9103f918bd915fbca63e6'.toLowerCase()) {
    uri = 'https://assets.coingecko.com/coins/images/3263/small/CEL_logo.png?1609598753';
  }

  if (((_address52 = address) === null || _address52 === void 0 ? void 0 : _address52.toLowerCase()) === '0x46F48FbdedAa6F5500993BEDE9539ef85F4BeE8e'.toLowerCase()) {
    uri = 'https://aria.fyi/images/Aria_Logo_256.png';
  }

  if (((_address53 = address) === null || _address53 === void 0 ? void 0 : _address53.toLowerCase()) === '0xeCf8f2FA183b1C4d2A269BF98A54fCe86C812d3e'.toLowerCase()) {
    uri = 'https://i.imgur.com/Z8V1O7H.png';
  }

  if (((_address54 = address) === null || _address54 === void 0 ? void 0 : _address54.toLowerCase()) === '0xa1428174F516F527fafdD146b883bB4428682737'.toLowerCase()) {
    uri = 'https://assets.coingecko.com/coins/images/14040/small/6YPdWn6.png?1613975899';
  }

  if (((_address55 = address) === null || _address55 === void 0 ? void 0 : _address55.toLowerCase()) === '0x42435F467D33e5C4146a4E8893976ef12BBCE762'.toLowerCase()) {
    uri = 'https://i.imgur.com/uVGtugL.png';
  }

  if (((_address56 = address) === null || _address56 === void 0 ? void 0 : _address56.toLowerCase()) === '0x7CdC0421469398e0F3aA8890693d86c840Ac8931'.toLowerCase()) {
    uri = 'https://raw.githubusercontent.com/sameepsi/quickswap-default-token-list/master/assets/azuki.png';
  }

  if (((_address57 = address) === null || _address57 === void 0 ? void 0 : _address57.toLowerCase()) === '0xd28449BB9bB659725aCcAd52947677ccE3719fD7'.toLowerCase()) {
    uri = 'https://darkmatter.finance/i/favicon/512x512.png';
  }

  if (((_address58 = address) === null || _address58 === void 0 ? void 0 : _address58.toLowerCase()) === '0x8a2870fb69A90000D6439b7aDfB01d4bA383A415'.toLowerCase()) {
    uri = 'https://raw.githubusercontent.com/sameepsi/quickswap-default-token-list/master/assets/DEGEN_LOGO.png';
  }

  if (((_address59 = address) === null || _address59 === void 0 ? void 0 : _address59.toLowerCase()) === '0x521CddC0CBa84F14c69C1E99249F781AA73Ee0BC'.toLowerCase()) {
    uri = 'https://assets.coingecko.com/coins/images/13719/small/hh.png?1611137626';
  }

  if (((_address60 = address) === null || _address60 === void 0 ? void 0 : _address60.toLowerCase()) === '0x6968105460f67c3BF751bE7C15f92F5286Fd0CE5'.toLowerCase()) {
    uri = 'https://i.imgur.com/FR12tmm.jpg';
  }

  if (((_address61 = address) === null || _address61 === void 0 ? void 0 : _address61.toLowerCase()) === '0x9c49BA0212Bb5Db371e66b59D1565b7c06E4894e'.toLowerCase()) {
    uri = 'https://etherscan.io/token/images/indexed-cc10_32.png';
  }

  if (((_address62 = address) === null || _address62 === void 0 ? void 0 : _address62.toLowerCase()) === '0x282d8efCe846A88B159800bd4130ad77443Fa1A1'.toLowerCase()) {
    uri = 'https://oceanprotocol.com/static/4ad704a150d436a1f32d495413fc47cd/favicon-white.png';
  }

  if (((_address63 = address) === null || _address63 === void 0 ? void 0 : _address63.toLowerCase()) === '0x232eaB56c4fB3f84c6Fb0a50c087c74b7B43c6Ad'.toLowerCase()) {
    uri = 'https://etherscan.io/token/images/zuzprotocol_32.png';
  }

  if (((_address64 = address) === null || _address64 === void 0 ? void 0 : _address64.toLowerCase()) === '0xFdc26CDA2d2440d0E83CD1DeE8E8bE48405806DC'.toLowerCase()) {
    uri = 'https://raw.githubusercontent.com/trustwallet/assets/master/blockchains/ethereum/assets/0xb683D83a532e2Cb7DFa5275eED3698436371cc9f/logo.png';
  }

  if (((_address65 = address) === null || _address65 === void 0 ? void 0 : _address65.toLowerCase()) === '0xB77e62709e39aD1cbeEBE77cF493745AeC0F453a'.toLowerCase()) {
    uri = 'https://i.imgur.com/eOOhNeh.png';
  }

  if (((_address66 = address) === null || _address66 === void 0 ? void 0 : _address66.toLowerCase()) === '0xB77e62709e39aD1cbeEBE77cF493745AeC0F453a'.toLowerCase()) {
    uri = 'https://etherscan.io/token/images/wisetoken_32.png';
  }

  if (((_address67 = address) === null || _address67 === void 0 ? void 0 : _address67.toLowerCase()) === '0x82B6205002ecd05e97642D38D61e2cFeaC0E18cE'.toLowerCase()) {
    uri = 'https://etherscan.io/token/images/deflect_32.png?=v1';
  }

  if (((_address68 = address) === null || _address68 === void 0 ? void 0 : _address68.toLowerCase()) === '0xf153EfF70DC0bf3b085134928daeEA248d9B30d0'.toLowerCase()) {
    uri = 'https://raw.githubusercontent.com/trustwallet/assets/8cb78aca77b340510958ed98a3cd260d2d7f0420/blockchains/ethereum/assets/0x36b679bd64Ed73DBfd88909cDCB892cB66Bd4CBb/logo.png';
  }

  if (((_address69 = address) === null || _address69 === void 0 ? void 0 : _address69.toLowerCase()) === '0xa0E390e9ceA0D0e8cd40048ced9fA9EA10D71639'.toLowerCase()) {
    uri = 'https://storage.googleapis.com/stacktical-public/dsla.png';
  }

  if (((_address70 = address) === null || _address70 === void 0 ? void 0 : _address70.toLowerCase()) === '0xFeD16c746CB5BFeD009730f9E3e6A673006105c7'.toLowerCase()) {
    uri = 'https://pbs.twimg.com/profile_images/1318783238291292160/R4DxXdRA_400x400.jpg';
  }

  if (((_address71 = address) === null || _address71 === void 0 ? void 0 : _address71.toLowerCase()) === '0x8f18dC399594b451EdA8c5da02d0563c0b2d0f16'.toLowerCase()) {
    uri = 'https://i.imgur.com/UIjlQpC.png';
  }

  if (((_address72 = address) === null || _address72 === void 0 ? void 0 : _address72.toLowerCase()) === '0x033d942A6b495C4071083f4CDe1f17e986FE856c'.toLowerCase()) {
    uri = 'https://i.imgur.com/R0aQlym.png';
  }

  if (((_address73 = address) === null || _address73 === void 0 ? void 0 : _address73.toLowerCase()) === '0xF84BD51eab957c2e7B7D646A3427C5A50848281D'.toLowerCase()) {
    uri = 'https://i.imgur.com/06BkcTT.png';
  }

  if (((_address74 = address) === null || _address74 === void 0 ? void 0 : _address74.toLowerCase()) === '0x23D29D30e35C5e8D321e1dc9A8a61BFD846D4C5C'.toLowerCase()) {
    uri = 'https://hex.com/favicon.png';
  }

  if (((_address75 = address) === null || _address75 === void 0 ? void 0 : _address75.toLowerCase()) === '0x2727Ab1c2D22170ABc9b595177B2D5C6E1Ab7B7B'.toLowerCase()) {
    uri = 'https://i.imgur.com/q3SnElh.png';
  }

  if (((_address76 = address) === null || _address76 === void 0 ? void 0 : _address76.toLowerCase()) === '0xdF7837DE1F2Fa4631D716CF2502f8b230F1dcc32'.toLowerCase()) {
    uri = 'https://pbs.twimg.com/profile_images/933388441475194881/57fOk40N_400x400.jpg';
  }

  if (((_address77 = address) === null || _address77 === void 0 ? void 0 : _address77.toLowerCase()) === '0x7075cAB6bCCA06613e2d071bd918D1a0241379E2'.toLowerCase()) {
    uri = 'https://gains.farm/images/logo256.png';
  }

  if (((_address78 = address) === null || _address78 === void 0 ? void 0 : _address78.toLowerCase()) === '0xf7d9e281c5Cb4C6796284C5b663b3593D2037aF2'.toLowerCase()) {
    uri = 'https://raw.githubusercontent.com/sameepsi/quickswap-default-token-list/master/assets/NFTP.png';
  }

  if (((_address79 = address) === null || _address79 === void 0 ? void 0 : _address79.toLowerCase()) === '0xD6DF932A45C0f255f85145f286eA0b292B21C90B'.toLowerCase()) {
    uri = 'https://etherscan.io/token/images/aave_32.png';
  }

  if (((_address80 = address) === null || _address80 === void 0 ? void 0 : _address80.toLowerCase()) === '0x2bF9b864cdc97b08B6D79ad4663e71B8aB65c45c'.toLowerCase()) {
    uri = 'https://cryptologos.cc/logos/fusion-fsn-logo.png?v=010';
  }

  if (((_address81 = address) === null || _address81 === void 0 ? void 0 : _address81.toLowerCase()) === '0x6aB6d61428fde76768D7b45D8BFeec19c6eF91A8'.toLowerCase()) {
    uri = 'https://raw.githubusercontent.com/anyswap/Brand-assets/master/logo/c-128-white.svg';
  }

  if (((_address82 = address) === null || _address82 === void 0 ? void 0 : _address82.toLowerCase()) === '0xe82808eaA78339b06a691fd92E1Be79671cAd8D3'.toLowerCase()) {
    uri = 'https://i.imgur.com/nQDG9AQ.png';
  }

  if (((_address83 = address) === null || _address83 === void 0 ? void 0 : _address83.toLowerCase()) === '0x7ff2FC33E161E3b1C6511B934F0209D304267857'.toLowerCase()) {
    uri = 'https://www.opucoin.io/wp-content/uploads/2021/04/opu-coiin-icon-border.svg';
  }

  if (((_address84 = address) === null || _address84 === void 0 ? void 0 : _address84.toLowerCase()) === '0x0b3F868E0BE5597D5DB7fEB59E1CADBb0fdDa50a'.toLowerCase()) {
    address = '0x6B3595068778DD592e39A122f4f5a5cF09C90fE2';
  }

  if (!uri) {
    uri = `https://raw.githubusercontent.com/trustwallet/assets/master/blockchains/ethereum/assets/${address}/logo.png`;
  }

  return uri;
};
// EXTERNAL MODULE: ./src/hooks/useHttpLocations.ts + 1 modules
var useHttpLocations = __webpack_require__(3278);
;// CONCATENATED MODULE: ./src/components/CurrencyLogo/index.tsx


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }







const getTokenLogoURL = (address, chainId) => {
  let imageURL;

  if (chainId === sdk_.ChainId.MAINNET) {
    imageURL = `https://raw.githubusercontent.com/trustwallet/assets/master/blockchains/ethereum/assets/${address}/logo.png`;
  } else if (chainId === sdk_.ChainId.BSC) {
    imageURL = `https://v1exchange.pancakeswap.finance/images/coins/${address}.png`;
  } else if (chainId === sdk_.ChainId.MATIC) {
    imageURL = getMaticTokenLogoURL(address);
  }

  return imageURL;
};
const BLOCKCHAIN = {
  [sdk_.ChainId.MAINNET]: 'ethereum',
  [sdk_.ChainId.BSC]: 'binanace',
  [sdk_.ChainId.CELO]: 'celo',
  [sdk_.ChainId.FANTOM]: 'fantom',
  [sdk_.ChainId.HARMONY]: 'harmony',
  [sdk_.ChainId.MATIC]: 'polygon',
  [sdk_.ChainId.XDAI]: 'xdai' // [ChainId.OKEX]: 'okex',

};

function getCurrencySymbol(currency) {
  if (currency.symbol === 'WBTC') {
    return 'btc';
  }

  if (currency.symbol === 'WETH') {
    return 'eth';
  }

  return currency.symbol.toLowerCase();
}

function getCurrencyLogoUrls(currency) {
  const urls = [];
  urls.push(`https://raw.githubusercontent.com/sushiswap/icons/master/token/${getCurrencySymbol(currency)}.jpg`);

  if (currency.chainId in BLOCKCHAIN) {
    urls.push(`https://raw.githubusercontent.com/sushiswap/assets/master/blockchains/${BLOCKCHAIN[currency.chainId]}/assets/${currency.address}/logo.png`);
    urls.push(`https://raw.githubusercontent.com/trustwallet/assets/master/blockchains/${BLOCKCHAIN[currency.chainId]}/assets/${currency.address}/logo.png`);
  }

  return urls;
}

const AvalancheLogo = 'https://raw.githubusercontent.com/sushiswap/icons/master/token/avax.jpg';
const BinanceCoinLogo = 'https://raw.githubusercontent.com/sushiswap/icons/master/token/bnb.jpg';
const EthereumLogo = 'https://raw.githubusercontent.com/sushiswap/icons/master/token/eth.jpg';
const FantomLogo = 'https://raw.githubusercontent.com/sushiswap/icons/master/token/ftm.jpg';
const HarmonyLogo = 'https://raw.githubusercontent.com/sushiswap/icons/master/token/one.jpg';
const HecoLogo = 'https://raw.githubusercontent.com/sushiswap/icons/master/token/heco.jpg';
const MaticLogo = 'https://raw.githubusercontent.com/sushiswap/icons/master/token/polygon.jpg';
const MoonbeamLogo = 'https://raw.githubusercontent.com/sushiswap/icons/master/token/eth.jpg';
const OKExLogo = 'https://raw.githubusercontent.com/sushiswap/icons/master/token/okt.jpg';
const xDaiLogo = 'https://raw.githubusercontent.com/sushiswap/icons/master/token/dai.jpg';
const CeloLogo = 'https://raw.githubusercontent.com/sushiswap/icons/master/token/celo.jpg';
const logo = {
  [sdk_.ChainId.MAINNET]: EthereumLogo,
  [sdk_.ChainId.FANTOM]: FantomLogo,
  [sdk_.ChainId.FANTOM_TESTNET]: FantomLogo,
  [sdk_.ChainId.MATIC]: MaticLogo,
  [sdk_.ChainId.MATIC_TESTNET]: MaticLogo,
  [sdk_.ChainId.XDAI]: xDaiLogo,
  [sdk_.ChainId.BSC]: BinanceCoinLogo,
  [sdk_.ChainId.BSC_TESTNET]: BinanceCoinLogo,
  [sdk_.ChainId.MOONBEAM_TESTNET]: MoonbeamLogo,
  [sdk_.ChainId.AVALANCHE]: AvalancheLogo,
  [sdk_.ChainId.AVALANCHE_TESTNET]: AvalancheLogo,
  [sdk_.ChainId.HECO]: HecoLogo,
  [sdk_.ChainId.HECO_TESTNET]: HecoLogo,
  [sdk_.ChainId.HARMONY]: HarmonyLogo,
  [sdk_.ChainId.HARMONY_TESTNET]: HarmonyLogo,
  [sdk_.ChainId.OKEX]: OKExLogo,
  [sdk_.ChainId.OKEX_TESTNET]: OKExLogo,
  [sdk_.ChainId.ARBITRUM]: EthereumLogo,
  [sdk_.ChainId.ARBITRUM_TESTNET]: EthereumLogo,
  [sdk_.ChainId.CELO]: CeloLogo
};
const unknown = 'https://raw.githubusercontent.com/sushiswap/icons/master/token/unknown.png';

const CurrencyLogo = (_ref) => {
  let {
    currency,
    size = '24px',
    style,
    className = ''
  } = _ref,
      rest = _objectWithoutProperties(_ref, ["currency", "size", "style", "className"]);

  const uriLocations = (0,useHttpLocations/* default */.Z)(currency instanceof wrappedTokenInfo/* WrappedTokenInfo */.D ? currency.logoURI || currency.tokenInfo.logoURI : undefined);
  const srcs = (0,external_react_.useMemo)(() => {
    if (!currency) {
      return [unknown];
    }

    if (currency.isNative || currency.equals(sdk_.WNATIVE[currency.chainId])) {
      return [logo[currency.chainId], unknown];
    }

    if (currency.isToken) {
      const defaultUrls = [...getCurrencyLogoUrls(currency)];

      if (currency instanceof wrappedTokenInfo/* WrappedTokenInfo */.D) {
        return [...uriLocations, ...defaultUrls, unknown];
      }

      return defaultUrls;
    }
  }, [currency, uriLocations]);
  return /*#__PURE__*/jsx_runtime_.jsx(Logo/* default */.Z, _objectSpread({
    srcs: srcs,
    width: size,
    height: size,
    alt: currency === null || currency === void 0 ? void 0 : currency.symbol
  }, rest));
};

/* harmony default export */ var components_CurrencyLogo = (CurrencyLogo);

/***/ }),

/***/ 4419:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": function() { return /* binding */ Loader; }
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9914);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }



const rotate = (0,styled_components__WEBPACK_IMPORTED_MODULE_2__.keyframes)(["from{transform:rotate(0deg);}to{transform:rotate(360deg);}"]);
const StyledSVG = styled_components__WEBPACK_IMPORTED_MODULE_2___default().svg.withConfig({
  displayName: "Loader__StyledSVG",
  componentId: "sc-1dpwm2a-0"
})(["animation:2s ", " linear infinite;height:", ";width:", ";path{stroke:", ";}"], rotate, ({
  size
}) => size, ({
  size
}) => size, ({
  stroke,
  theme
}) => stroke !== null && stroke !== void 0 ? stroke : theme.primary1);
/**
 * Takes in custom size and stroke for circle color, default to primary color as fill,
 * need ...rest for layered styles on top
 */

function Loader(_ref) {
  let {
    size = '16px',
    stroke
  } = _ref,
      rest = _objectWithoutProperties(_ref, ["size", "stroke"]);

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledSVG, _objectSpread(_objectSpread({
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
    size: size,
    stroke: stroke
  }, rest), {}, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
      d: "M12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22C17.5228 22 22 17.5228 22 12C22 9.27455 20.9097 6.80375 19.1414 5",
      strokeWidth: "2.5",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    })
  }));
}

/***/ }),

/***/ 5914:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5579);
/* harmony import */ var _functions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7735);
/* harmony import */ var _functions_cloudinary__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3801);


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }





const BAD_SRCS = {};

/**
 * Renders an image by sequentially trying a list of URIs, and then eventually a fallback triangle alert
 */
const Logo = (_ref) => {
  let {
    srcs,
    width,
    height,
    style,
    alt = '',
    className
  } = _ref,
      rest = _objectWithoutProperties(_ref, ["srcs", "width", "height", "style", "alt", "className"]);

  const {
    1: refresh
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
  const src = srcs.find(src => !BAD_SRCS[src]);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
    className: "rounded",
    style: {
      width,
      height
    },
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Image__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z, _objectSpread({
      src: src || 'https://raw.githubusercontent.com/sushiswap/icons/master/token/unknown.png',
      loader: _functions_cloudinary__WEBPACK_IMPORTED_MODULE_4__/* .cloudinaryLoader */ .H,
      onError: () => {
        if (src) BAD_SRCS[src] = true;
        refresh(i => i + 1);
      },
      width: width,
      height: height,
      alt: alt,
      layout: "fixed",
      className: (0,_functions__WEBPACK_IMPORTED_MODULE_3__/* .classNames */ .AK)('rounded', className),
      style: style
    }, rest))
  });
};

/* harmony default export */ __webpack_exports__["Z"] = (Logo);

/***/ }),

/***/ 6919:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "I": function() { return /* binding */ Input; }
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _functions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7735);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }



const inputRegex = RegExp(`^\\d*(?:\\\\[.])?\\d*$`); // match escaped "." characters via in a non-capturing group

const defaultClassName = 'w-0 p-0 text-2xl bg-transparent';
const Input = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default().memo((_ref) => {
  let {
    value,
    onUserInput,
    placeholder,
    className = defaultClassName
  } = _ref,
      rest = _objectWithoutProperties(_ref, ["value", "onUserInput", "placeholder", "className"]);

  const enforcer = nextUserInput => {
    if (nextUserInput === '' || inputRegex.test((0,_functions__WEBPACK_IMPORTED_MODULE_1__/* .escapeRegExp */ .hr)(nextUserInput))) {
      onUserInput(nextUserInput);
    }
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", _objectSpread(_objectSpread({}, rest), {}, {
    value: value,
    onChange: event => {
      // replace commas with periods, because uniswap exclusively uses period as the decimal separator
      enforcer(event.target.value.replace(/,/g, '.'));
    } // universal input options
    ,
    inputMode: "decimal",
    title: "Token Amount",
    autoComplete: "off",
    autoCorrect: "off" // text-specific options
    ,
    type: "text",
    pattern: "^[0-9]*[.,]?[0-9]*$",
    placeholder: placeholder || '0.0',
    min: 0,
    minLength: 1,
    maxLength: 79,
    spellCheck: "false",
    className: (0,_functions__WEBPACK_IMPORTED_MODULE_1__/* .classNames */ .AK)('relative font-bold outline-none border-none flex-auto overflow-hidden overflow-ellipsis placeholder-low-emphesis focus:placeholder-primary', className)
  }));
});
Input.displayName = 'NumericalInput';
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (Input))); // const inputRegex = RegExp(`^\\d*(?:\\\\[.])?\\d*$`) // match escaped "." characters via in a non-capturing group

/***/ }),

/***/ 3801:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "H": function() { return /* binding */ cloudinaryLoader; }
/* harmony export */ });
const normalize = src => {
  return src[0] === '/' ? src.slice(1) : src;
};

const cloudinaryLoader = ({
  src
}) => {
  return `https://res.cloudinary.com/dnz2bkszg/image/fetch/f_auto/${normalize(src)}`;
};

/***/ }),

/***/ 451:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": function() { return /* binding */ useDebounce; }
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
 // modified from https://usehooks.com/useDebounce/

function useDebounce(value, delay) {
  const {
    0: debouncedValue,
    1: setDebouncedValue
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(value);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    // Update debounced value after delay
    const handler = setTimeout(() => {
      setDebouncedValue(value);
    }, delay); // Cancel the timeout if value changes (also on delay change or unmount)
    // This is how we prevent debounced value from updating if value is changed ...
    // .. within the delay period. Timeout gets cleared and restarted.

    return () => {
      clearTimeout(handler);
    };
  }, [value, delay]);
  return debouncedValue;
}

/***/ }),

/***/ 1543:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": function() { return /* binding */ useENS; }
/* harmony export */ });
/* harmony import */ var _functions_validate__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2556);
/* harmony import */ var _useENSAddress__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9678);
/* harmony import */ var _useENSName__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7816);



/**
 * Given a name or address, does a lookup to resolve to an address and name
 * @param nameOrAddress ENS name or address
 */

function useENS(nameOrAddress) {
  const validated = (0,_functions_validate__WEBPACK_IMPORTED_MODULE_0__/* .isAddress */ .UJ)(nameOrAddress);
  const reverseLookup = (0,_useENSName__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z)(validated ? validated : undefined);
  const lookup = (0,_useENSAddress__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z)(nameOrAddress);
  return {
    loading: reverseLookup.loading || lookup.loading,
    address: validated ? validated : lookup.address,
    name: reverseLookup.ENSName ? reverseLookup.ENSName : !validated && lookup.address ? nameOrAddress || null : null
  };
}

/***/ }),

/***/ 9678:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": function() { return /* binding */ useENSAddress; }
/* harmony export */ });
/* harmony import */ var _useContract__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6699);
/* harmony import */ var _functions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7735);
/* harmony import */ var ethers_lib_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1674);
/* harmony import */ var ethers_lib_utils__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(ethers_lib_utils__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _useDebounce__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(451);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _state_multicall_hooks__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(879);






/**
 * Does a lookup for an ENS name to find its address.
 */

function useENSAddress(ensName) {
  var _resolverAddress$resu, _addr$result$, _addr$result;

  const debouncedName = (0,_useDebounce__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z)(ensName, 200);
  const ensNodeArgument = (0,react__WEBPACK_IMPORTED_MODULE_4__.useMemo)(() => {
    if (!debouncedName) return [undefined];

    try {
      return debouncedName ? [(0,ethers_lib_utils__WEBPACK_IMPORTED_MODULE_2__.namehash)(debouncedName)] : [undefined];
    } catch (error) {
      return [undefined];
    }
  }, [debouncedName]);
  const registrarContract = (0,_useContract__WEBPACK_IMPORTED_MODULE_0__/* .useENSRegistrarContract */ .zb)(false);
  const resolverAddress = (0,_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_5__/* .useSingleCallResult */ .Wk)(registrarContract, 'resolver', ensNodeArgument);
  const resolverAddressResult = (_resolverAddress$resu = resolverAddress.result) === null || _resolverAddress$resu === void 0 ? void 0 : _resolverAddress$resu[0];
  const resolverContract = (0,_useContract__WEBPACK_IMPORTED_MODULE_0__/* .useENSResolverContract */ .uU)(resolverAddressResult && !(0,_functions__WEBPACK_IMPORTED_MODULE_1__/* .isZero */ .Fr)(resolverAddressResult) ? resolverAddressResult : undefined, false);
  const addr = (0,_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_5__/* .useSingleCallResult */ .Wk)(resolverContract, 'addr', ensNodeArgument);
  const changed = debouncedName !== ensName;
  return {
    address: changed ? null : (_addr$result$ = (_addr$result = addr.result) === null || _addr$result === void 0 ? void 0 : _addr$result[0]) !== null && _addr$result$ !== void 0 ? _addr$result$ : null,
    loading: changed || resolverAddress.loading || addr.loading
  };
}

/***/ }),

/***/ 7816:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": function() { return /* binding */ useENSName; }
/* harmony export */ });
/* harmony import */ var ethers_lib_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1674);
/* harmony import */ var ethers_lib_utils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(ethers_lib_utils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _useContract__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6699);
/* harmony import */ var _functions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7735);
/* harmony import */ var _useDebounce__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(451);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _state_multicall_hooks__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(879);






/**
 * Does a reverse lookup for an address to find its ENS name.
 * Note this is not the same as looking up an ENS name to find an address.
 */

function useENSName(address) {
  var _resolverAddress$resu, _name$result$, _name$result;

  const debouncedAddress = (0,_useDebounce__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z)(address, 200);
  const ensNodeArgument = (0,react__WEBPACK_IMPORTED_MODULE_4__.useMemo)(() => {
    if (!debouncedAddress || !(0,ethers_lib_utils__WEBPACK_IMPORTED_MODULE_0__.isAddress)(debouncedAddress)) return [undefined];

    try {
      return debouncedAddress ? [(0,ethers_lib_utils__WEBPACK_IMPORTED_MODULE_0__.namehash)(`${debouncedAddress.toLowerCase().substr(2)}.addr.reverse`)] : [undefined];
    } catch (error) {
      return [undefined];
    }
  }, [debouncedAddress]);
  const registrarContract = (0,_useContract__WEBPACK_IMPORTED_MODULE_1__/* .useENSRegistrarContract */ .zb)(false);
  const resolverAddress = (0,_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_5__/* .useSingleCallResult */ .Wk)(registrarContract, 'resolver', ensNodeArgument);
  const resolverAddressResult = (_resolverAddress$resu = resolverAddress.result) === null || _resolverAddress$resu === void 0 ? void 0 : _resolverAddress$resu[0];
  const resolverContract = (0,_useContract__WEBPACK_IMPORTED_MODULE_1__/* .useENSResolverContract */ .uU)(resolverAddressResult && !(0,_functions__WEBPACK_IMPORTED_MODULE_2__/* .isZero */ .Fr)(resolverAddressResult) ? resolverAddressResult : undefined, false);
  const name = (0,_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_5__/* .useSingleCallResult */ .Wk)(resolverContract, 'name', ensNodeArgument);
  const changed = debouncedAddress !== address;
  return {
    ENSName: changed ? null : (_name$result$ = (_name$result = name.result) === null || _name$result === void 0 ? void 0 : _name$result[0]) !== null && _name$result$ !== void 0 ? _name$result$ : null,
    loading: changed || resolverAddress.loading || name.loading
  };
}

/***/ }),

/***/ 3278:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": function() { return /* binding */ useHttpLocations; }
});

// EXTERNAL MODULE: ./src/functions/convert/index.ts + 3 modules
var convert = __webpack_require__(7025);
// EXTERNAL MODULE: ./src/functions/ens.ts
var functions_ens = __webpack_require__(1302);
// EXTERNAL MODULE: ./src/hooks/useContract.ts + 37 modules
var useContract = __webpack_require__(6699);
// EXTERNAL MODULE: ./src/functions/index.ts
var functions = __webpack_require__(7735);
// EXTERNAL MODULE: external "ethers/lib/utils"
var utils_ = __webpack_require__(1674);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./src/state/multicall/hooks.ts
var hooks = __webpack_require__(879);
;// CONCATENATED MODULE: ./src/hooks/useENSContentHash.ts





/**
 * Does a lookup for an ENS name to find its contenthash.
 */

function useENSContentHash(ensName) {
  var _resolverAddressResul, _contenthash$result$, _contenthash$result;

  const ensNodeArgument = (0,external_react_.useMemo)(() => {
    if (!ensName) return [undefined];

    try {
      return ensName ? [(0,utils_.namehash)(ensName)] : [undefined];
    } catch (error) {
      return [undefined];
    }
  }, [ensName]);
  const registrarContract = (0,useContract/* useENSRegistrarContract */.zb)(false);
  const resolverAddressResult = (0,hooks/* useSingleCallResult */.Wk)(registrarContract, 'resolver', ensNodeArgument);
  const resolverAddress = (_resolverAddressResul = resolverAddressResult.result) === null || _resolverAddressResul === void 0 ? void 0 : _resolverAddressResul[0];
  const resolverContract = (0,useContract/* useENSResolverContract */.uU)(resolverAddress && (0,functions/* isZero */.Fr)(resolverAddress) ? undefined : resolverAddress, false);
  const contenthash = (0,hooks/* useSingleCallResult */.Wk)(resolverContract, 'contenthash', ensNodeArgument);
  return {
    contenthash: (_contenthash$result$ = (_contenthash$result = contenthash.result) === null || _contenthash$result === void 0 ? void 0 : _contenthash$result[0]) !== null && _contenthash$result$ !== void 0 ? _contenthash$result$ : null,
    loading: resolverAddressResult.loading || contenthash.loading
  };
}
;// CONCATENATED MODULE: ./src/hooks/useHttpLocations.ts




function useHttpLocations(uri) {
  const ens = (0,external_react_.useMemo)(() => uri ? (0,functions_ens/* parseENSAddress */.y)(uri) : undefined, [uri]);
  const resolvedContentHash = useENSContentHash(ens === null || ens === void 0 ? void 0 : ens.ensName);
  return (0,external_react_.useMemo)(() => {
    if (ens) {
      return resolvedContentHash.contenthash ? (0,convert/* uriToHttp */.ie)((0,convert/* contenthashToUri */.il)(resolvedContentHash.contenthash)) : [];
    } else {
      return uri ? (0,convert/* uriToHttp */.ie)(uri) : [];
    }
  }, [ens, resolvedContentHash.contenthash, uri]);
}

/***/ }),

/***/ 4174:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": function() { return /* binding */ useParsedQueryString; }
/* harmony export */ });
/* harmony import */ var qs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6850);
/* harmony import */ var qs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(qs__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


function useParsedQueryString() {
  // const { search } = useLocation()
  const search = location.search;
  return (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(() => search && search.length > 1 ? (0,qs__WEBPACK_IMPORTED_MODULE_0__.parse)(search, {
    parseArrays: false,
    ignoreQueryPrefix: true
  }) : {}, [search]);
}

/***/ }),

/***/ 4751:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": function() { return /* binding */ usePrevious; }
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
 // modified from https://usehooks.com/usePrevious/

function usePrevious(value) {
  // The ref object is a generic container whose current property is mutable ...
  // ... and can hold any value, similar to an instance property on a class
  const ref = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(); // Store current value in ref

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    ref.current = value;
  }, [value]); // Only re-run if value changes
  // Return previous value (happens before update in useEffect above)

  return ref.current;
}

/***/ }),

/***/ 5977:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": function() { return /* binding */ TokenWarningModal; }
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _SearchModal_ImportToken__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5805);
/* harmony import */ var _components_Modal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1441);




function TokenWarningModal({
  isOpen,
  tokens,
  onConfirm
}) {
  const handleDismiss = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(() => null, []);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Modal__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z, {
    isOpen: isOpen,
    onDismiss: handleDismiss,
    maxHeight: 90,
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SearchModal_ImportToken__WEBPACK_IMPORTED_MODULE_2__/* .ImportToken */ .W, {
      tokens: tokens,
      handleCurrencySelect: onConfirm
    })
  });
}

/***/ }),

/***/ 4690:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "gN": function() { return /* binding */ Field; },
/* harmony export */   "j": function() { return /* binding */ selectCurrency; },
/* harmony export */   "KS": function() { return /* binding */ switchCurrencies; },
/* harmony export */   "LC": function() { return /* binding */ typeInput; },
/* harmony export */   "mV": function() { return /* binding */ replaceSwapState; },
/* harmony export */   "He": function() { return /* binding */ setRecipient; }
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6139);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

let Field;

(function (Field) {
  Field["INPUT"] = "INPUT";
  Field["OUTPUT"] = "OUTPUT";
})(Field || (Field = {}));

const selectCurrency = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('swap/selectCurrency');
const switchCurrencies = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('swap/switchCurrencies');
const typeInput = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('swap/typeInput');
const replaceSwapState = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('swap/replaceSwapState');
const setRecipient = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)('swap/setRecipient');

/***/ }),

/***/ 4176:
/***/ (function(module) {

"use strict";
module.exports = JSON.parse('{"v":"5.6.10","fr":100,"ip":0,"op":149,"w":500,"h":500,"nm":"219-arrow-8","ddd":0,"assets":[{"id":"comp_0","layers":[]}],"layers":[{"ddd":0,"ind":1,"ty":0,"nm":"Watermark","refId":"comp_0","sr":1,"ks":{"o":{"a":0,"k":100,"ix":11},"r":{"a":0,"k":0,"ix":10},"p":{"a":0,"k":[250,250,0],"ix":2},"a":{"a":0,"k":[250,250,0],"ix":1},"s":{"a":0,"k":[100,100,100],"ix":6}},"ao":0,"w":500,"h":500,"ip":0,"op":2083.33333333333,"st":0,"bm":0},{"ddd":0,"ind":2,"ty":3,"nm":"Color  & Stroke Change","sr":1,"ks":{"o":{"a":0,"k":0,"ix":11},"r":{"a":0,"k":0,"ix":10},"p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0,0],"ix":1},"s":{"a":0,"k":[100,100,100],"ix":6}},"ao":0,"ef":[{"ty":5,"nm":"Primary","np":3,"mn":"ADBE Color Control","ix":1,"en":1,"ef":[{"ty":2,"nm":"Color","mn":"ADBE Color Control-0001","ix":1,"v":{"a":0,"k":[0.89,0.89,0.89],"ix":1}}]},{"ty":5,"nm":"Secondary","np":3,"mn":"ADBE Color Control","ix":2,"en":1,"ef":[{"ty":2,"nm":"Color","mn":"ADBE Color Control-0001","ix":1,"v":{"a":0,"k":[0.89,0.89,0.89],"ix":1}}]},{"ty":5,"nm":"Stroke","np":3,"mn":"ADBE Slider Control","ix":3,"en":1,"ef":[{"ty":0,"nm":"Slider","mn":"ADBE Slider Control-0001","ix":1,"v":{"a":0,"k":140,"ix":1}}]},{"ty":5,"nm":"Scale","np":3,"mn":"ADBE Slider Control","ix":4,"en":1,"ef":[{"ty":0,"nm":"Slider","mn":"ADBE Slider Control-0001","ix":1,"v":{"a":0,"k":100,"ix":1}}]},{"ty":5,"nm":"Axis","np":3,"mn":"ADBE Point Control","ix":5,"en":1,"ef":[{"ty":3,"nm":"Point","mn":"ADBE Point Control-0001","ix":1,"v":{"a":0,"k":[250,250],"ix":1}}]}],"ip":0,"op":500,"st":0,"bm":0},{"ddd":0,"ind":3,"ty":3,"nm":"NULL 3","sr":1,"ks":{"o":{"a":0,"k":0,"ix":11},"r":{"a":0,"k":0,"ix":10},"p":{"a":0,"k":[250,250,0],"ix":2,"x":"var $bm_rt;\\n$bm_rt = thisComp.layer(\'Color  & Stroke Change\').effect(\'Axis\')(\'Point\');"},"a":{"a":0,"k":[60,60,0],"ix":1},"s":{"a":0,"k":[100,100,100],"ix":6,"x":"var $bm_rt;\\nvar temp;\\ntemp = thisComp.layer(\'Color  & Stroke Change\').effect(\'Scale\')(\'Slider\');\\n$bm_rt = [\\n    temp,\\n    temp\\n];"}},"ao":0,"ip":0,"op":500,"st":0,"bm":0},{"ddd":0,"ind":4,"ty":3,"nm":"NULL","parent":3,"sr":1,"ks":{"o":{"a":0,"k":0,"ix":11},"r":{"a":0,"k":0,"ix":10},"p":{"a":0,"k":[60,60,0],"ix":2},"a":{"a":0,"k":[60,60,0],"ix":1},"s":{"a":0,"k":[450,450,100],"ix":6}},"ao":0,"ip":0,"op":500,"st":0,"bm":0},{"ddd":0,"ind":5,"ty":3,"nm":"NULL 2","parent":4,"sr":1,"ks":{"o":{"a":0,"k":0,"ix":11},"r":{"a":0,"k":180,"ix":10},"p":{"a":0,"k":[60,60,0],"ix":2},"a":{"a":0,"k":[60,60,0],"ix":1},"s":{"a":0,"k":[100,100,100],"ix":6}},"ao":0,"ip":0,"op":500,"st":0,"bm":0},{"ddd":0,"ind":6,"ty":4,"nm":"Shape Layer 8","parent":5,"sr":1,"ks":{"o":{"a":0,"k":100,"ix":11},"r":{"a":0,"k":-45,"ix":10},"p":{"a":1,"k":[{"i":{"x":0,"y":1},"o":{"x":0.167,"y":0.167},"t":0,"s":[79.639,100.559,0],"to":[-0.125,-9.917,0],"ti":[0,0,0]},{"i":{"x":0.667,"y":1},"o":{"x":1,"y":0},"t":49,"s":[79.639,36.559,0],"to":[0,0,0],"ti":[-0.117,-9.999,0]},{"i":{"x":0.667,"y":1},"o":{"x":0.333,"y":0},"t":76,"s":[79.639,100.559,0],"to":[-0.062,-1.292,0],"ti":[0,-0.042,0]},{"i":{"x":0.667,"y":1},"o":{"x":0.333,"y":0},"t":91,"s":[79.639,97.059,0],"to":[0,0.042,0],"ti":[0,0,0]},{"i":{"x":0.667,"y":1},"o":{"x":0.333,"y":0},"t":106,"s":[79.639,100.809,0],"to":[0,0,0],"ti":[0,0.042,0]},{"i":{"x":0.667,"y":1},"o":{"x":0.333,"y":0},"t":121,"s":[79.639,97.059,0],"to":[0,-0.042,0],"ti":[-0.053,-2.022,0]},{"t":148,"s":[79.639,100.559,0]}],"ix":2},"a":{"a":0,"k":[-20.549,12.747,0],"ix":1},"s":{"a":0,"k":[100,100,100],"ix":6}},"ao":0,"shapes":[{"ty":"gr","it":[{"ind":0,"ty":"sh","ix":1,"ks":{"a":0,"k":{"i":[[0,0],[0,0],[0,0]],"o":[[0,0],[0,0],[0,0]],"v":[[-20.549,-4.93],[-20.549,12.747],[-2.927,12.747]],"c":false},"ix":2},"nm":"Path 1","mn":"ADBE Vector Shape - Group","hd":false},{"ty":"st","c":{"a":0,"k":[0.070588235294,0.074509803922,0.192156877705,1],"ix":3,"x":"var $bm_rt;\\n$bm_rt = thisComp.layer(\'Color  & Stroke Change\').effect(\'Secondary\')(\'Color\');"},"o":{"a":0,"k":100,"ix":4},"w":{"a":0,"k":5,"ix":5,"x":"var $bm_rt;\\n$bm_rt = $bm_mul(4 / 100, thisComp.layer(\'Color  & Stroke Change\').effect(\'Stroke\')(\'Slider\'));"},"lc":2,"lj":2,"bm":0,"nm":"Stroke 1","mn":"ADBE Vector Graphic - Stroke","hd":false},{"ty":"tr","p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":1},"s":{"a":0,"k":[100,100],"ix":3},"r":{"a":0,"k":0,"ix":6},"o":{"a":0,"k":100,"ix":7},"sk":{"a":0,"k":0,"ix":4},"sa":{"a":0,"k":0,"ix":5},"nm":"Transform"}],"nm":"Shape 1","np":2,"cix":2,"bm":0,"ix":1,"mn":"ADBE Vector Group","hd":false}],"ip":0,"op":500,"st":0,"bm":0},{"ddd":0,"ind":7,"ty":4,"nm":"Shape Layer 7","parent":5,"sr":1,"ks":{"o":{"a":0,"k":100,"ix":11},"r":{"a":0,"k":0,"ix":10},"p":{"a":0,"k":[50.5,47.75,0],"ix":2},"a":{"a":0,"k":[0,0,0],"ix":1},"s":{"a":0,"k":[100,100,100],"ix":6}},"ao":0,"shapes":[{"ty":"gr","it":[{"ind":0,"ty":"sh","ix":1,"ks":{"a":0,"k":{"i":[[0,0],[0,0]],"o":[[0,0],[0,0]],"v":[[28.937,-36.311],[29.041,56.75]],"c":false},"ix":2},"nm":"Path 1","mn":"ADBE Vector Shape - Group","hd":false},{"ty":"rd","nm":"Round Corners 1","r":{"a":0,"k":34,"ix":1},"ix":2,"mn":"ADBE Vector Filter - RC","hd":false},{"ty":"st","c":{"a":0,"k":[0.03137254902,0.662745098039,0.545098039216,1],"ix":3,"x":"var $bm_rt;\\n$bm_rt = thisComp.layer(\'Shape Layer 8\').content(\'Shape 1\').content(\'Stroke 1\').color;"},"o":{"a":0,"k":100,"ix":4},"w":{"a":0,"k":4,"ix":5,"x":"var $bm_rt;\\n$bm_rt = thisComp.layer(\'Shape Layer 8\').content(\'Shape 1\').content(\'Stroke 1\').strokeWidth;"},"lc":2,"lj":2,"bm":0,"nm":"Stroke 2","mn":"ADBE Vector Graphic - Stroke","hd":false},{"ty":"tr","p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":1},"s":{"a":0,"k":[100,100],"ix":3},"r":{"a":0,"k":0,"ix":6},"o":{"a":0,"k":100,"ix":7},"sk":{"a":0,"k":0,"ix":4},"sa":{"a":0,"k":0,"ix":5},"nm":"Transform"}],"nm":"Shape 1","np":3,"cix":2,"bm":0,"ix":1,"mn":"ADBE Vector Group","hd":false},{"ty":"tm","s":{"a":0,"k":9,"ix":1},"e":{"a":1,"k":[{"i":{"x":[0],"y":[1]},"o":{"x":[0.167],"y":[0.167]},"t":0,"s":[93]},{"i":{"x":[0.667],"y":[1]},"o":{"x":[1],"y":[0]},"t":49,"s":[24]},{"i":{"x":[0.667],"y":[1]},"o":{"x":[0.333],"y":[0]},"t":76,"s":[93]},{"i":{"x":[0.667],"y":[1]},"o":{"x":[0.333],"y":[0]},"t":91,"s":[90.769]},{"i":{"x":[0],"y":[1]},"o":{"x":[0.333],"y":[0]},"t":106,"s":[93]},{"i":{"x":[0],"y":[1]},"o":{"x":[1],"y":[0]},"t":121,"s":[92]},{"t":148,"s":[93]}],"ix":2},"o":{"a":0,"k":0,"ix":3},"m":1,"ix":2,"nm":"Trim Paths 1","mn":"ADBE Vector Filter - Trim","hd":false}],"ip":0,"op":500,"st":0,"bm":0},{"ddd":0,"ind":8,"ty":3,"nm":"NULL","parent":4,"sr":1,"ks":{"o":{"a":0,"k":0,"ix":11},"r":{"a":0,"k":0,"ix":10},"p":{"a":0,"k":[60,60,0],"ix":2},"a":{"a":0,"k":[60,60,0],"ix":1},"s":{"a":0,"k":[100,100,100],"ix":6}},"ao":0,"ip":0,"op":500,"st":0,"bm":0},{"ddd":0,"ind":9,"ty":4,"nm":"Shape Layer 6","parent":8,"sr":1,"ks":{"o":{"a":0,"k":100,"ix":11},"r":{"a":0,"k":-45,"ix":10},"p":{"a":1,"k":[{"i":{"x":0,"y":1},"o":{"x":0.167,"y":0.167},"t":0,"s":[79.639,100.559,0],"to":[-0.125,-9.917,0],"ti":[0,0,0]},{"i":{"x":0.667,"y":1},"o":{"x":1,"y":0},"t":49,"s":[79.639,36.559,0],"to":[0,0,0],"ti":[-0.117,-9.999,0]},{"i":{"x":0.667,"y":1},"o":{"x":0.333,"y":0},"t":76,"s":[79.639,100.559,0],"to":[-0.062,-1.292,0],"ti":[0,-0.042,0]},{"i":{"x":0.667,"y":1},"o":{"x":0.333,"y":0},"t":91,"s":[79.639,97.059,0],"to":[0,0.042,0],"ti":[0,0,0]},{"i":{"x":0.667,"y":1},"o":{"x":0.333,"y":0},"t":106,"s":[79.639,100.809,0],"to":[0,0,0],"ti":[0,0.042,0]},{"i":{"x":0.667,"y":1},"o":{"x":0.333,"y":0},"t":121,"s":[79.639,97.059,0],"to":[0,-0.042,0],"ti":[-0.053,-2.022,0]},{"t":148,"s":[79.639,100.559,0]}],"ix":2},"a":{"a":0,"k":[-20.549,12.747,0],"ix":1},"s":{"a":0,"k":[100,100,100],"ix":6}},"ao":0,"shapes":[{"ty":"gr","it":[{"ind":0,"ty":"sh","ix":1,"ks":{"a":0,"k":{"i":[[0,0],[0,0],[0,0]],"o":[[0,0],[0,0],[0,0]],"v":[[-20.549,-4.93],[-20.549,12.747],[-2.927,12.747]],"c":false},"ix":2},"nm":"Path 1","mn":"ADBE Vector Shape - Group","hd":false},{"ty":"st","c":{"a":0,"k":[0.070588235294,0.074509803922,0.192156877705,1],"ix":3,"x":"var $bm_rt;\\n$bm_rt = thisComp.layer(\'Color  & Stroke Change\').effect(\'Primary\')(\'Color\');"},"o":{"a":0,"k":100,"ix":4},"w":{"a":0,"k":5,"ix":5,"x":"var $bm_rt;\\n$bm_rt = $bm_mul(4 / 100, thisComp.layer(\'Color  & Stroke Change\').effect(\'Stroke\')(\'Slider\'));"},"lc":2,"lj":2,"bm":0,"nm":"Stroke 1","mn":"ADBE Vector Graphic - Stroke","hd":false},{"ty":"tr","p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":1},"s":{"a":0,"k":[100,100],"ix":3},"r":{"a":0,"k":0,"ix":6},"o":{"a":0,"k":100,"ix":7},"sk":{"a":0,"k":0,"ix":4},"sa":{"a":0,"k":0,"ix":5},"nm":"Transform"}],"nm":"Shape 1","np":2,"cix":2,"bm":0,"ix":1,"mn":"ADBE Vector Group","hd":false}],"ip":0,"op":500,"st":0,"bm":0},{"ddd":0,"ind":10,"ty":4,"nm":"Shape Layer 5","parent":8,"sr":1,"ks":{"o":{"a":0,"k":100,"ix":11},"r":{"a":0,"k":0,"ix":10},"p":{"a":0,"k":[50.5,47.75,0],"ix":2},"a":{"a":0,"k":[0,0,0],"ix":1},"s":{"a":0,"k":[100,100,100],"ix":6}},"ao":0,"shapes":[{"ty":"gr","it":[{"ind":0,"ty":"sh","ix":1,"ks":{"a":0,"k":{"i":[[0,0],[0,0]],"o":[[0,0],[0,0]],"v":[[28.937,-36.311],[29.041,56.75]],"c":false},"ix":2},"nm":"Path 1","mn":"ADBE Vector Shape - Group","hd":false},{"ty":"rd","nm":"Round Corners 1","r":{"a":0,"k":34,"ix":1},"ix":2,"mn":"ADBE Vector Filter - RC","hd":false},{"ty":"st","c":{"a":0,"k":[0.070588235294,0.074509803922,0.192156877705,1],"ix":3,"x":"var $bm_rt;\\n$bm_rt = thisComp.layer(\'Color  & Stroke Change\').effect(\'Primary\')(\'Color\');"},"o":{"a":0,"k":100,"ix":4},"w":{"a":0,"k":5,"ix":5,"x":"var $bm_rt;\\n$bm_rt = $bm_mul(4 / 100, thisComp.layer(\'Color  & Stroke Change\').effect(\'Stroke\')(\'Slider\'));"},"lc":2,"lj":2,"bm":0,"nm":"Stroke 1","mn":"ADBE Vector Graphic - Stroke","hd":false},{"ty":"tr","p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":1},"s":{"a":0,"k":[100,100],"ix":3},"r":{"a":0,"k":0,"ix":6},"o":{"a":0,"k":100,"ix":7},"sk":{"a":0,"k":0,"ix":4},"sa":{"a":0,"k":0,"ix":5},"nm":"Transform"}],"nm":"Shape 1","np":3,"cix":2,"bm":0,"ix":1,"mn":"ADBE Vector Group","hd":false},{"ty":"tm","s":{"a":0,"k":9,"ix":1},"e":{"a":1,"k":[{"i":{"x":[0],"y":[1]},"o":{"x":[0.167],"y":[0.167]},"t":0,"s":[93]},{"i":{"x":[0.667],"y":[1]},"o":{"x":[1],"y":[0]},"t":49,"s":[24]},{"i":{"x":[0.667],"y":[1]},"o":{"x":[0.333],"y":[0]},"t":76,"s":[93]},{"i":{"x":[0.667],"y":[1]},"o":{"x":[0.333],"y":[0]},"t":91,"s":[90.769]},{"i":{"x":[0],"y":[1]},"o":{"x":[0.333],"y":[0]},"t":106,"s":[93]},{"i":{"x":[0],"y":[1]},"o":{"x":[1],"y":[0]},"t":121,"s":[92]},{"t":148,"s":[93]}],"ix":2},"o":{"a":0,"k":0,"ix":3},"m":1,"ix":2,"nm":"Trim Paths 1","mn":"ADBE Vector Filter - Trim","hd":false}],"ip":0,"op":500,"st":0,"bm":0}],"markers":[{"tm":10,"cm":"2","dr":0},{"tm":64,"cm":"3","dr":0},{"tm":76,"cm":"4","dr":0},{"tm":88,"cm":"5","dr":0}]}');

/***/ })

};
;