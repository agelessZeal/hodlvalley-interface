exports.id = 5787;
exports.ids = [5787];
exports.modules = {

/***/ 5787:
/***/ (function(module) {

/*eslint-disable*/module.exports={messages:{}};

/***/ })

};
;