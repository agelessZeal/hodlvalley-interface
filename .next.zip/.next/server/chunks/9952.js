exports.id = 9952;
exports.ids = [9952];
exports.modules = {

/***/ 9952:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "UK": function() { return /* binding */ ApprovalState; },
  "qL": function() { return /* binding */ useApproveCallback; },
  "re": function() { return /* binding */ useApproveCallbackFromTrade; }
});

// EXTERNAL MODULE: external "@sushiswap/sdk"
var sdk_ = __webpack_require__(6766);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./src/state/transactions/hooks.tsx
var hooks = __webpack_require__(9123);
// EXTERNAL MODULE: ./src/constants/index.ts
var constants = __webpack_require__(8532);
// EXTERNAL MODULE: external "@ethersproject/constants"
var constants_ = __webpack_require__(6148);
// EXTERNAL MODULE: ./src/functions/trade.ts
var trade = __webpack_require__(4113);
// EXTERNAL MODULE: ./src/hooks/useActiveWeb3React.ts
var useActiveWeb3React = __webpack_require__(8269);
// EXTERNAL MODULE: ./src/state/multicall/hooks.ts
var multicall_hooks = __webpack_require__(879);
// EXTERNAL MODULE: ./src/hooks/useContract.ts + 37 modules
var useContract = __webpack_require__(6699);
;// CONCATENATED MODULE: ./src/hooks/useTokenAllowance.ts




function useTokenAllowance(token, owner, spender) {
  const contract = (0,useContract/* useTokenContract */.Ib)(token === null || token === void 0 ? void 0 : token.address, false);
  const inputs = (0,external_react_.useMemo)(() => [owner, spender], [owner, spender]);
  const allowance = (0,multicall_hooks/* useSingleCallResult */.Wk)(contract, 'allowance', inputs).result;
  return (0,external_react_.useMemo)(() => token && allowance ? sdk_.CurrencyAmount.fromRawAmount(token, allowance.toString()) : undefined, [token, allowance]);
}
;// CONCATENATED MODULE: ./src/hooks/useApproveCallback.ts









let ApprovalState; // returns a variable indicating the state of the approval and a function which approves if necessary or early returns

(function (ApprovalState) {
  ApprovalState["UNKNOWN"] = "UNKNOWN";
  ApprovalState["NOT_APPROVED"] = "NOT_APPROVED";
  ApprovalState["PENDING"] = "PENDING";
  ApprovalState["APPROVED"] = "APPROVED";
})(ApprovalState || (ApprovalState = {}));

function useApproveCallback(amountToApprove, spender) {
  var _amountToApprove$curr;

  const {
    account
  } = (0,useActiveWeb3React/* useActiveWeb3React */.a)();
  const token = amountToApprove !== null && amountToApprove !== void 0 && (_amountToApprove$curr = amountToApprove.currency) !== null && _amountToApprove$curr !== void 0 && _amountToApprove$curr.isToken ? amountToApprove.currency : undefined;
  const currentAllowance = useTokenAllowance(token, account !== null && account !== void 0 ? account : undefined, spender);
  const pendingApproval = (0,hooks/* useHasPendingApproval */.wB)(token === null || token === void 0 ? void 0 : token.address, spender); // check the current approval status

  const approvalState = (0,external_react_.useMemo)(() => {
    if (!amountToApprove || !spender) return ApprovalState.UNKNOWN;
    if (amountToApprove.currency.isNative) return ApprovalState.APPROVED; // we might not have enough data to know whether or not we need to approve

    if (!currentAllowance) return ApprovalState.UNKNOWN; // amountToApprove will be defined if currentAllowance is

    return currentAllowance.lessThan(amountToApprove) ? pendingApproval ? ApprovalState.PENDING : ApprovalState.NOT_APPROVED : ApprovalState.APPROVED;
  }, [amountToApprove, currentAllowance, pendingApproval, spender]);
  const tokenContract = (0,useContract/* useTokenContract */.Ib)(token === null || token === void 0 ? void 0 : token.address);
  const addTransaction = (0,hooks/* useTransactionAdder */.h7)();
  const approve = (0,external_react_.useCallback)(async () => {
    if (approvalState !== ApprovalState.NOT_APPROVED) {
      console.error('approve was called unnecessarily');
      return;
    }

    if (!token) {
      console.error('no token');
      return;
    }

    if (!tokenContract) {
      console.error('tokenContract is null');
      return;
    }

    if (!amountToApprove) {
      console.error('missing amount to approve');
      return;
    }

    if (!spender) {
      console.error('no spender');
      return;
    }

    let useExact = false;
    const estimatedGas = await tokenContract.estimateGas.approve(spender, constants_.MaxUint256).catch(() => {
      // general fallback for tokens who restrict approval amounts
      useExact = true;
      return tokenContract.estimateGas.approve(spender, amountToApprove.quotient.toString());
    });
    return tokenContract.approve(spender, useExact ? amountToApprove.quotient.toString() : constants_.MaxUint256, {
      gasLimit: (0,trade/* calculateGasMargin */.yC)(estimatedGas)
    }).then(response => {
      addTransaction(response, {
        summary: 'Approve ' + amountToApprove.currency.symbol,
        approval: {
          tokenAddress: token.address,
          spender: spender
        }
      });
    }).catch(error => {
      console.debug('Failed to approve token', error);
      throw error;
    });
  }, [approvalState, token, tokenContract, amountToApprove, spender, addTransaction]);
  return [approvalState, approve];
} // wraps useApproveCallback in the context of a swap

function useApproveCallbackFromTrade(trade, allowedSlippage, doArcher = false) {
  const {
    chainId
  } = (0,useActiveWeb3React/* useActiveWeb3React */.a)();
  const amountToApprove = (0,external_react_.useMemo)(() => trade && trade.inputAmount.currency.isToken ? trade.maximumAmountIn(allowedSlippage) : undefined, [trade, allowedSlippage]);
  return useApproveCallback(amountToApprove, chainId ? trade instanceof sdk_.Trade ? !doArcher ? sdk_.ROUTER_ADDRESS[chainId] : constants/* ARCHER_ROUTER_ADDRESS */.k_[chainId] : undefined : undefined);
}

/***/ })

};
;